package server.communication;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.github.springtestdbunit.annotation.DatabaseSetup;
import com.github.springtestdbunit.annotation.DbUnitConfiguration;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.test.web.servlet.MockMvc;
import server.database.Database;
import server.objects.asset.Asset;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * JUnit5 tests for the communication.assetEndpoint package.
 *
 * @author Daniel Taylor, N10492623
 */
@SpringBootTest
@AutoConfigureMockMvc
@ContextConfiguration
@DbUnitConfiguration(databaseConnection = {"dataSourceTests"})
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
        DirtiesContextTestExecutionListener.class,
        TransactionalTestExecutionListener.class,
        DbUnitTestExecutionListener.class})
public class AssetsEndpointTests {
    /**
     * Make sure that the database has been created before attempting to run any tests.
     *
     * @author Daniel Taylor, N10492623
     */
    @BeforeAll
    static void initialiseTestingDatabase() {
        Database.createNewDatabase(true);
    }

    @Autowired
    private MockMvc mockMvc;

    /**
     * Tests if the /assets get endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadAllAssetsSuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/assets")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /assets/{assetName} get endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadIndividualAssetSuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/assets/{assetName}", "Widgets")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /assets/{assetName} get endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadIndividualAssetUnsuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/assets/{assetName}", " ")).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /assets/priceHistory/{assetName} get endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadAssetPriceHistorySuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/assets/priceHistory/{assetName}", "Keyboard")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /assets/priceHistory/{assetName} get endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadAssetPriceHistoryUnsuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/assets/priceHistory/{assetName}", " ")).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /assets post endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testCreateAssetSuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        Asset testedAsset = new Asset("Asset", "This will work", null);

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(post("/assets").contentType("application/json").content(jsonMapper.writeValueAsString(testedAsset))).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /assets post endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testCreateAssetUnsuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        Asset testedAsset = new Asset(" ", "This won't work", null);

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(post("/assets").contentType("application/json").content(jsonMapper.writeValueAsString(testedAsset))).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /assets/edit/{assetname} put endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testEditAssetSuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        Asset testedAsset = new Asset("EditSuccessful", "This will work", null);

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(put("/assets/edit/{assetname}", "Unneeded Edit").contentType("application/json").content(jsonMapper.writeValueAsString(testedAsset))).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /assets/edit/{assetname} put endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testEditAssetUnsuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        Asset testedAsset = new Asset(" ", "This won't work", null);

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(put("/assets/edit/{assetname}", "NotInDb").contentType("application/json").content(jsonMapper.writeValueAsString(testedAsset))).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /assets/{assetName} delete endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testDeleteAssetSuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(delete("/assets/{assetName}", "Unneeded Delete")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /assets/{assetName} delete endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testDeleteAssetUnsuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(delete("/assets/{assetName}", "NotInDb")).andDo(print()).andExpect(status().isUnprocessableEntity());
    }
}

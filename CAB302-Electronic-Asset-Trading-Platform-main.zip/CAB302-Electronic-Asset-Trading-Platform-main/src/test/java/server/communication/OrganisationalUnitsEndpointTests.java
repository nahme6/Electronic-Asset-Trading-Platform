package server.communication;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.github.springtestdbunit.annotation.DatabaseSetup;
import com.github.springtestdbunit.annotation.DbUnitConfiguration;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.test.web.servlet.MockMvc;
import server.database.Database;
import server.objects.organisation.OrganisationalUnit;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * JUnit5 tests for the communication.organisationalUnitEndpoint package.
 *
 * @author Daniel Taylor, N10492623
 */
@SpringBootTest
@AutoConfigureMockMvc
@ContextConfiguration
@DbUnitConfiguration(databaseConnection = {"dataSourceTests"})
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
        DirtiesContextTestExecutionListener.class,
        TransactionalTestExecutionListener.class,
        DbUnitTestExecutionListener.class})
public class OrganisationalUnitsEndpointTests {
    /**
     * Make sure that the database has been created before attempting to run any tests.
     *
     * @author Daniel Taylor, N10492623
     */
    @BeforeAll
    static void initialiseTestingDatabase() {
        Database.createNewDatabase(true);
    }

    @Autowired
    private MockMvc mockMvc;

    /**
     * Tests if the /organisationalUnits get endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadAllOrgUnitsSuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/organisationalUnits")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /organisationalUnits/{orgName} get endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadIndividualOrgUnitSuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/organisationalUnits/{orgName}", "212th")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /organisationalUnits/{orgName} get endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadIndividualOrgUnitUnsuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/organisationalUnits/{orgName}", " ")).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /organisationalUnits/inventory/{orgName} get endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadOrgUnitInventorySuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/organisationalUnits/inventory/{orgName}", "IT")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /organisationalUnits/inventory/{orgName} get endpoint returns a HTTP Status Code of 200 even if the
     * organisational unit has an empty inventory.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadOrgUnitInventorySuccessfulEmptyInventory() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/organisationalUnits/inventory/{orgName}", "Marketing")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /organisationalUnits/inventory/{orgName} get endpoint returns a HTTP Status Code of 422 if a
     * non-existent orgName is supplied.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadOrgUnitInventoryUnsuccessfulNonExistentOrgName() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/organisationalUnits/inventory/{orgName}", "IDon'tExist")).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /organisationalUnits/inventory/{orgName} get endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadOrgUnitInventoryUnsuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/organisationalUnits/inventory/{orgName}", " ")).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /organisationalUnits post endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testCreateOrgUnitSuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        OrganisationalUnit testedOrgUnit = new OrganisationalUnit("OrgUnit", 99, null);

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(post("/organisationalUnits").contentType("application/json").content(jsonMapper.writeValueAsString(testedOrgUnit))).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /organisationalUnits post endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testCreateOrgUnitUnsuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        OrganisationalUnit testedOrgUnit = new OrganisationalUnit(" ", 99, null);

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(post("/organisationalUnits").contentType("application/json").content(jsonMapper.writeValueAsString(testedOrgUnit))).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /organisationalUnits/edit/{orgName} put endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testEditOrgUnitSuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        OrganisationalUnit testedOrgUnit = new OrganisationalUnit("EditSuccessful", 99, null);

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(put("/organisationalUnits/edit/{orgName}", "Unneeded Edit").contentType("application/json").content(jsonMapper.writeValueAsString(testedOrgUnit))).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /organisationalUnits/edit/{orgName} put endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testEditOrgUnitUnsuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        OrganisationalUnit testedOrgUnit = new OrganisationalUnit(" ", 99, null);

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(put("/organisationalUnits/edit/{orgName}", "NotInDb").contentType("application/json").content(jsonMapper.writeValueAsString(testedOrgUnit))).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /organisationalUnits/{orgName} delete endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testDeleteOrgUnitSuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(delete("/organisationalUnits/{orgName}", "Unneeded Delete")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /organisationalUnits/{orgName} delete endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testDeleteOrgUnitUnsuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(delete("/organisationalUnits/{orgName}", "NotInDb")).andDo(print()).andExpect(status().isUnprocessableEntity());
    }
}

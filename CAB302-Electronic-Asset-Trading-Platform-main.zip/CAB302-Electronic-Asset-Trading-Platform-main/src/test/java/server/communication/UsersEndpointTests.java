package server.communication;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.github.springtestdbunit.annotation.DatabaseSetup;
import com.github.springtestdbunit.annotation.DbUnitConfiguration;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.test.web.servlet.MockMvc;
import server.database.Database;
import server.objects.user.AccountType;
import server.objects.user.PasswordChangeRequest;
import server.objects.user.User;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * JUnit5 tests for the communication.userEndpoint package.
 *
 * @author Daniel Taylor, N10492623
 */
@SpringBootTest
@AutoConfigureMockMvc
@ContextConfiguration
@DbUnitConfiguration(databaseConnection = {"dataSourceTests"})
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
        DirtiesContextTestExecutionListener.class,
        TransactionalTestExecutionListener.class,
        DbUnitTestExecutionListener.class})
public class UsersEndpointTests {
    /**
     * Make sure that the database has been created before attempting to run any tests.
     *
     * @author Daniel Taylor, N10492623
     */
    @BeforeAll
    static void initialiseTestingDatabase() {
        Database.createNewDatabase(true);
    }

    @Autowired
    private MockMvc mockMvc;

    /**
     * Tests if the /users get endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadAllUsersSuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/users")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /users/{email} get endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadIndividualUserSuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/users/{email}", "captainrex@republic.com")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /users/{email} get endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadIndividualUserUnsuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/users/{email}", " ")).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /users post endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testCreateUserSuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        User testedUser = new User("302pleaseend@gmail.com", "123", null, "Daniel",
                "Taylor", AccountType.Admin, "212th");

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(post("/users").contentType("application/json").content(jsonMapper.writeValueAsString(testedUser))).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /users post endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testCreateUserUnsuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        User testedUser = new User(" ", "123", null, "Daniel",
                "Taylor", AccountType.Admin, "212th");

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(post("/users").contentType("application/json").content(jsonMapper.writeValueAsString(testedUser))).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /users/login post endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testLoginUserSuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        User testedUser = new User("captainrex@republic.com", "alphadog", null, null,
                null, null, null);

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(post("/users/login").contentType("application/json").content(jsonMapper.writeValueAsString(testedUser))).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /users/login post endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testLoginUserUnsuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        User testedUser = new User("captainrex@republic.com", "wrongpassword", null, null,
                null, null, null);
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(post("/users/login").contentType("application/json").content(jsonMapper.writeValueAsString(testedUser))).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /users/edit/{email} put endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testEditUserSuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        User testedUser = new User("captainrex@republic.com", "alphadog", null, "Chris",
                "Sterkenburg", null, "212th");

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(put("/users/edit/{email}", "captainrex@republic.com").contentType("application/json").content(jsonMapper.writeValueAsString(testedUser))).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /users/edit/{email} put endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testEditUserUnsuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        User testedUser = new User("captainrex@republic.com", "alphadog", null, "Chris",
                "Sterkenburg", null, "212th");

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(put("/users/edit/{email}", "NotInDb").contentType("application/json").content(jsonMapper.writeValueAsString(testedUser))).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /users/edit/{email} put endpoint returns a HTTP Status Code of 422 if an exception is thrown
     * when the user does not exist.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testEditUserUnsuccessfulNonExistentUser() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        User testedUser = new User("captainrex@republic.com", "alphadog", null, "Chris",
                "Sterkenburg", null, "212th");

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(put("/users/edit/{email}", "IDontExist@gmail.com").contentType("application/json").content(jsonMapper.writeValueAsString(testedUser))).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /users/edit/password/{email} put endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testEditPasswordSuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        PasswordChangeRequest testedPasswordChange = new PasswordChangeRequest("alphadog", "newPassword");

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(put("/users/edit/password/{email}", "captainrex@republic.com").contentType("application/json").content(jsonMapper.writeValueAsString(testedPasswordChange))).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /users/edit/password/{email} put endpoint returns a HTTP Status Code of 422 if an exception is thrown
     * when the user does not exist.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testEditPasswordUnsuccessfulNonExistentUser() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        PasswordChangeRequest testedPasswordChange = new PasswordChangeRequest("wrongPassword", "newPassword");

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(put("/users/edit/password/{email}", "IDontExist@gmail.com").contentType("application/json").content(jsonMapper.writeValueAsString(testedPasswordChange))).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /users/edit/password/{email} put endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testEditPasswordUnsuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        PasswordChangeRequest testedPasswordChange = new PasswordChangeRequest("wrongPassword", "newPassword");

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(put("/users/edit/password/{email}", "captainrex@republic.com").contentType("application/json").content(jsonMapper.writeValueAsString(testedPasswordChange))).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /users/{email} delete endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testDeleteUserSuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(delete("/users/{email}", "captainrex@republic.com")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /users/{email} delete endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testDeleteUserUnsuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(delete("/users/{email}", "NotInDb")).andDo(print()).andExpect(status().isUnprocessableEntity());
    }
}

package server.communication;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.github.springtestdbunit.annotation.DatabaseSetup;
import com.github.springtestdbunit.annotation.DbUnitConfiguration;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.test.web.servlet.MockMvc;
import server.database.Database;
import server.objects.trade.OrderType;
import server.objects.trade.Trade;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * JUnit5 tests for the communication.tradeEndpoint package.
 *
 * @author Daniel Taylor, N10492623
 */
@SpringBootTest
@AutoConfigureMockMvc
@ContextConfiguration
@DbUnitConfiguration(databaseConnection = {"dataSourceTests"})
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
        DirtiesContextTestExecutionListener.class,
        TransactionalTestExecutionListener.class,
        DbUnitTestExecutionListener.class})
public class TradesEndpointTests {
    /**
     * Make sure that the database has been created before attempting to run any tests.
     *
     * @author Daniel Taylor, N10492623
     */
    @BeforeAll
    static void initialiseTestingDatabase() {
        Database.createNewDatabase(true);
    }

    @Autowired
    private MockMvc mockMvc;

    /**
     * Tests if the /trades/isResolved/{isResolved} get endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadAllTradesSuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/trades/isResolved/{isResolved}", "false")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /trades/tradeListings/{orgName}/{isResolved} get endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadTradesByOrgNameSuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/trades/tradeListings/{orgName}/{isResolved}", "IT", "false")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /trades/tradeListings/{orgName}/{isResolved} get endpoint returns a HTTP Status Code of 422 if an exception is thrown
     * when the organisational unit does not exist.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadTradesByOrgNameUnsuccessfulNonExistentOrgName() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/trades/tradeListings/{orgName}/{isResolved}", "IDon'tExist", "false")).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /trades/tradeListings/{orgName}/{isResolved} get endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadTradesByOrgNameUnsuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/trades/tradeListings/{orgName}/{isResolved}", " ", "false")).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /trades/{tradeID} get endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadIndividualTradeSuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/trades/{tradeID}", "1")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /trades/{tradeID} get endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testReadIndividualTradeUnsuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(get("/trades/{tradeID}", "-1")).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /trades post endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testCreateTradeSuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        Trade testedTrade = new Trade(null, "Widgets", OrderType.BUY, 5,
                5, null, null, "IT", null);

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(post("/trades").contentType("application/json").content(jsonMapper.writeValueAsString(testedTrade))).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /trades post endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testCreateTradeUnsuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        Trade testedTrade = new Trade(null, "Widgets", OrderType.BUY, 999,
                999, null, null, "IT", null);


        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(post("/trades").contentType("application/json").content(jsonMapper.writeValueAsString(testedTrade))).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /trades/edit/{tradeID} put endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testEditTradeSuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        Trade testedTrade = new Trade(null, null, null, 1,
                3, null, null, null, null);

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(put("/trades/edit/{tradeID}", "5").contentType("application/json").content(jsonMapper.writeValueAsString(testedTrade))).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /trades/edit/{tradeID} put endpoint returns a HTTP Status Code of 422 if an exception is thrown when
     * the tradeID does not exist.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testEditTradeUnsuccessfulNonExistentTrade() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        Trade testedTrade = new Trade(null, null, null, 1,
                3, null, null, null, null);

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(put("/trades/edit/{tradeID}", "7567").contentType("application/json").content(jsonMapper.writeValueAsString(testedTrade))).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /trades/edit/{tradeID} put endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testEditTradeUnsuccessful() throws Exception {
        // Define a mapper for formatting objects as JSON strings
        ObjectMapper jsonMapper = new ObjectMapper();

        // Define an object to test the endpoint with
        Trade testedTrade = new Trade(null, null, null, 1,
                3, null, null, null, null);

        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(put("/trades/edit/{tradeID}", "1").contentType("application/json").content(jsonMapper.writeValueAsString(testedTrade))).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /trades/resolve/{orgName}/{tradeID} put endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testResolveTradeSuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(put("/trades/resolve/{orgName}/{tradeID}", "501st", "5")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /trades/resolve/{orgName}/{tradeID} put endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testResolveTradeUnsuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(put("/trades/resolve/{orgName}/{tradeID}", "501st", "1")).andDo(print()).andExpect(status().isUnprocessableEntity());
    }

    /**
     * Tests if the /trades/{tradeID} delete endpoint returns a HTTP Status Code of 200 if everything works as expected.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testDeleteTradeSuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(delete("/trades/{tradeID}", "5")).andDo(print()).andExpect(status().isOk());
    }

    /**
     * Tests if the /trades/{tradeID} delete endpoint returns a HTTP Status Code of 422 if an exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/communication/endpointsSampleData.xml")
    public void testDeleteTradeUnsuccessful() throws Exception {
        // Check the endpoint's status, and print for use in debugging
        this.mockMvc.perform(delete("/trades/{tradeID}", "1")).andDo(print()).andExpect(status().isUnprocessableEntity());
    }
}

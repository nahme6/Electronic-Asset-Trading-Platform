package server.managers;

import com.github.springtestdbunit.annotation.DbUnitConfiguration;
import com.github.springtestdbunit.assertion.DatabaseAssertionMode;
import server.database.Database;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.github.springtestdbunit.annotation.DatabaseSetup;
import com.github.springtestdbunit.annotation.ExpectedDatabase;
import server.exceptions.illegalAssetNameException;
import server.exceptions.illegalQuantityException;
import server.exceptions.illegalOrgNameException;
import server.exceptions.wouldRiskDebtException;
import server.exceptions.trades.*;
import server.exceptions.illegalCreditsException;
import server.objects.trade.OrderType;
import server.objects.trade.Trade;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static java.lang.Boolean.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit5 tests for the managers.TradesManager class.
 *
 * @author Daniel Taylor, N10492623
 */
@SpringBootTest
@ContextConfiguration
@DbUnitConfiguration(databaseConnection = {"dataSourceTests"})
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
        DirtiesContextTestExecutionListener.class,
        TransactionalTestExecutionListener.class,
        DbUnitTestExecutionListener.class})
public class TradesManagerTests {
    /**
     * Make sure that the database has been created before attempting to run any tests.
     *
     * @author Daniel Taylor, N10492623
     */
    @BeforeAll
    static void initialiseTestingDatabase() {
        Database.createNewDatabase(true);
    }

    /* Tests - placeTrade() */

    /**
     * Tests if placeTrade() can be called with appropriate parameters to list a trade successfully.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataExtraTrade.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSuccessfulList() {
        // In its current form, it is unknown whether this test will pass or fail. An attempt has been made to
        // fix issues relating to its reliance on the current date.
        Assertions.assertNotEquals(-1, TradesManager.placeTrade("Widgets", OrderType.SELL, 20, 5, "Management"));
    }

    /**
     * Tests if placeTrade() throws an illegalAssetNameException when the assetName parameter is null. Also checks
     * that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testListTradeNonStringAssetName() {
        assertThrows(illegalAssetNameException.class, () -> TradesManager.placeTrade(null, OrderType.SELL,
                20, 100, "Management"));
    }

    /**
     * Tests if placeTrade() throws an illegalAssetNameException when the assetName parameter is empty. Also checks
     * that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testListTradeEmptyAssetName() {
        assertThrows(illegalAssetNameException.class, () -> TradesManager.placeTrade("", OrderType.SELL,
                20, 100, "Management"));
    }

    /**
     * Tests if placeTrade() throws an illegalAssetNameException when the assetName parameter is over 50 characters in length.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testListTradeLengthyAssetName() {
        // Create a string that exceeds the database's constraint
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(51);
        String tooLong = tooLongBuilder.toString();

        // Use the string as a parameter in the method
        assertThrows(illegalAssetNameException.class, () -> TradesManager.placeTrade(tooLong, OrderType.SELL,
                20, 100, "Management"));
    }

    /**
     * Tests if placeTrade() throws an illegalAssetNameException when the assetName parameter does not exist in the assets table
     * of the database. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataForeignKeyMustExist.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataForeignKeyMustExist.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testListTradeNonExistentAssetName() {
        assertThrows(illegalAssetNameException.class, () -> TradesManager.placeTrade("Widgets", OrderType.SELL,
                20, 100, "Finance"));
    }

    /**
     * Tests if placeTrade() throws an illegalOrderTypeException when the orderType parameter is null
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testListTradeInvalidOrderType() {
        assertThrows(illegalOrderTypeException.class, () -> TradesManager.placeTrade("Widgets", null,
                20, 100, "Management"));
    }

    /**
     * Tests if placeTrade() throws an illegalCreditsException when the creditPricePerUnit parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testListTradeNonIntegerCreditPrice() {
        assertThrows(illegalCreditsException.class, () -> TradesManager.placeTrade("Widgets", OrderType.SELL,
                null, 100, "Management"));
    }

    /**
     * Tests if placeTrade() throws an illegalCreditsException when the creditPricePerUnit parameter is below
     * the minimum boundary of 1. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testListTradeLowerBoundaryCreditPrice() {
        assertThrows(illegalCreditsException.class, () -> TradesManager.placeTrade("Widgets", OrderType.SELL,
                -42, 100, "Management"));
    }

    /**
     * Tests if placeTrade() throws an illegalQuantityException when the quantity parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testListTradeNonIntegerQuantity() {
        assertThrows(illegalQuantityException.class, () -> TradesManager.placeTrade("Widgets", OrderType.SELL,
                20, null, "Management"));
    }

    /**
     * Tests if placeTrade() throws an illegalQuantityException when the quantity parameter is below
     * the minimum boundary of 1. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testListTradeLowerBoundaryQuantity() {
        assertThrows(illegalQuantityException.class, () -> TradesManager.placeTrade("Widgets", OrderType.SELL,
                20, -42, "Management"));
    }

    /**
     * Tests if placeTrade() throws an wouldRiskDebtException when the quantity parameter would put the organisational
     * unit at risk of falling into credit debt. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataForeignKeyMustExist.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataForeignKeyMustExist.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testListTradeWouldCauseDebtQuantity() {
        assertThrows(wouldRiskDebtException.class, () -> TradesManager.placeTrade("CPU Hours", OrderType.BUY,
                999, 100, "Finance"));
    }

    /**
     * Tests if placeTrade() throws an wouldRiskDebtException when the quantity parameter would put the organisational
     * unit at risk of falling into asset debt. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataForeignKeyMustExist.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataForeignKeyMustExist.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testListTradeWouldCauseDebtQuantity2() {
        assertThrows(wouldRiskDebtException.class, () -> TradesManager.placeTrade("CPU Hours", OrderType.SELL,
                5, 100, "Finance"));
    }

    /**
     * Tests if placeTrade() throws an illegalOrgNameException when the organisationalUnitName parameter is
     * null. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testListTradeNonStringOrganisationalUnitName() {
        assertThrows(illegalOrgNameException.class, () -> TradesManager.placeTrade("Widgets", OrderType.SELL,
                20, 100, null));
    }

    /**
     * Tests if placeTrade() throws an illegalOrgNameException when the organisationalUnitName parameter is
     * empty. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testListTradeEmptyOrganisationalUnitName() {
        assertThrows(illegalOrgNameException.class, () -> TradesManager.placeTrade("Widgets", OrderType.SELL,
                20, 100, ""));
    }

    /**
     * Tests if placeTrade() throws an illegalOrgNameException when the organisationalUnitName parameter is
     * over 50 characters in length. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testListTradeLengthyOrganisationalUnitName() {
        // Create a string that exceeds the database's constraint
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(51);
        String tooLong = tooLongBuilder.toString();

        // Use the string as a parameter in the method
        assertThrows(illegalOrgNameException.class, () -> TradesManager.placeTrade("Widgets", OrderType.SELL,
                20, 100, tooLong));
    }

    /**
     * Tests if placeTrade() throws an illegalOrgNameException when the orgName parameter does not exist in the organisations table
     * of the database. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataForeignKeyMustExist.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataForeignKeyMustExist.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testListTradeNonExistentOrgName() {
        assertThrows(illegalOrgNameException.class, () -> TradesManager.placeTrade("CPU Hours", OrderType.SELL,
                20, 100, "Management"));
    }

    /* Tests - cancelTrade() */

    /**
     * Tests if cancelTrade() can be called with appropriate parameters to cancel a listed trade successfully.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataExtraTrade.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSuccessfulCancel() {
        TradesManager.cancelTrade(6);
    }

    /**
     * Tests if cancelTrade() throws an illegalTradeIDException when the tradeID parameter is null. Also checks
     * that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataExtraTrade.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataExtraTrade.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCancelTradeNonIntegerTradeID() {
        assertThrows(illegalTradeIDException.class, () -> TradesManager.cancelTrade(null));
    }

    /**
     * Tests if cancelTrade() throws a nonExistentTradeException when the tradeID parameter is not found in the database.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataExtraTrade.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataExtraTrade.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCancelTradeNonExistentTrade() {
        assertThrows(nonExistentTradeException.class, () -> TradesManager.cancelTrade(7));
    }

    /**
     * Tests if cancelTrade() throws a illegalManipulateResolvedTradeException when the tradeID parameter represents a
     * trade that has already been resolved. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataExtraTrade.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataExtraTrade.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCancelTradeResolvedTrade() {
        assertThrows(illegalManipulateResolvedTradeException.class, () -> TradesManager.cancelTrade(2));
    }

    /* Tests - getTradeInfo() */

    /**
     * Tests if getTradeInfo() can be called with appropriate parameters to retrieve a trade successfully.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    public void testSuccessfulGet() {
        Trade expectedTrade = new Trade(1, "CPU Hours", OrderType.BUY, 10, 50,
                LocalDate.parse("2021-04-24"), LocalDate.parse("2021-04-26"), "Finance", TRUE);
        assertEquals(expectedTrade, TradesManager.getTradeInfo(1));
    }

    /**
     * Tests if getTradeInfo() throws an illegalTradeIDException when the tradeID parameter is null.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    public void testGetTradeNonIntegerTradeID() {
        assertThrows(illegalTradeIDException.class, () -> TradesManager.getTradeInfo(null));
    }

    /**
     * Tests if getTradeInfo() returns null when the tradeID parameter is not found in the database.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    public void testGetTradeNonExistentTrade() {
        assertNull(TradesManager.getTradeInfo(9000));
    }

    /* Tests - editTradeInfo() */

    /**
     * Tests if editTradeInfo() can be called with appropriate parameters to edit a trade successfully.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataEdited.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSuccessfulEdit() {
        TradesManager.editTradeInfo(5, 25, 99);
    }

    /**
     * Tests if editTradeInfo() throws an illegalTradeIDException when the tradeID parameter is null. Also checks
     * that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditTradeNonIntegerTradeID() {
        assertThrows(illegalTradeIDException.class, () -> TradesManager.editTradeInfo(null, 25, 500));
    }

    /**
     * Tests if editTradeInfo() throws a illegalTradeIDException when the tradeID parameter is below the minimum bound.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditTradeLowerBoundaryTrade() {
        assertThrows(illegalTradeIDException.class, () -> TradesManager.editTradeInfo(-42, 25, 500));
    }

    /**
     * Tests if editTradeInfo() throws a nonExistentTradeException when the tradeID parameter is not found in the database.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditTradeNonExistentTrade() {
        assertThrows(nonExistentTradeException.class, () -> TradesManager.editTradeInfo(42, 25, 500));
    }

    /**
     * Tests if editTradeInfo() throws a illegalManipulateResolvedTradeException when the tradeID parameter represents a
     * trade that has already been resolved. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditTradeResolvedTrade() {
        assertThrows(illegalManipulateResolvedTradeException.class, () -> TradesManager.editTradeInfo(1, 25, 500));
    }

    /**
     * Tests if editTradeInfo() throws an illegalCreditsException when the creditPricePerUnit parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditTradeNonIntegerCreditPrice() {
        assertThrows(illegalCreditsException.class, () -> TradesManager.editTradeInfo(5, null, 500));
    }

    /**
     * Tests if editTradeInfo() throws an illegalCreditsException when the creditPricePerUnit parameter is below
     * the minimum boundary of 1. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditTradeLowerBoundaryCreditPrice() {
        assertThrows(illegalCreditsException.class, () -> TradesManager.editTradeInfo(5, -42, 500));
    }

    /**
     * Tests if editTradeInfo() throws an illegalQuantityException when the quantity parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditTradeNonIntegerQuantity() {
        assertThrows(illegalQuantityException.class, () -> TradesManager.editTradeInfo(5, 25, null));
    }

    /**
     * Tests if editTradeInfo() throws an illegalQuantityException when the quantity parameter is below
     * the minimum boundary of 1. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditTradeLowerBoundaryQuantity() {
        assertThrows(illegalQuantityException.class, () -> TradesManager.editTradeInfo(5, 25, -42));
    }

    /**
     * Tests if editTradeInfo() throws an wouldRiskDebtException when the quantity parameter would put the organisational
     * unit at risk of falling into credit debt. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataForeignKeyMustExist.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataForeignKeyMustExist.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditTradeWouldCauseDebtQuantity() {
        assertThrows(wouldRiskDebtException.class, () -> TradesManager.editTradeInfo(1, 999, 50));
    }

    /**
     * Tests if editTradeInfo() throws an wouldRiskDebtException when the quantity parameter would put the organisational
     * unit at risk of falling into asset debt. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataForeignKeyMustExist.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataForeignKeyMustExist.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditTradeWouldCauseDebtQuantity2() {
        assertThrows(wouldRiskDebtException.class, () -> TradesManager.editTradeInfo(2, 999, 77));
    }

    /* Tests - getTradesList() */

    /**
     * Tests if getTradesList() can be called with appropriate parameters to retrieve a list of unresolved trades successfully.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup(value = "/dbunit/trades/tradesSampleDataDefaultState.xml")
    public void testSuccessfulGetListUnresolved() {
        List<Trade> expectedList = new ArrayList<>();

        Trade expectedTrade1 = new Trade(4, "Widgets", OrderType.SELL, 10, 10,
                LocalDate.parse("27/04/2021", DateTimeFormatter.ofPattern("d/MM/yyyy")), null, "Finance", FALSE);
        Trade expectedTrade2 = new Trade(5, "Widgets", OrderType.SELL, 3, 15,
                LocalDate.parse("28/04/2021", DateTimeFormatter.ofPattern("d/MM/yyyy")), null, "Management", FALSE);

        expectedList.add(expectedTrade1);
        expectedList.add(expectedTrade2);

        assertEquals(expectedList, TradesManager.getTradesList(FALSE));
    }

    /**
     * Tests if getTradesList() can be called with appropriate parameters to retrieve a list of resolved trades successfully.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup(value = "/dbunit/trades/tradesSampleDataDefaultState.xml")
    public void testSuccessfulGetListResolved() {
        List<Trade> expectedList = new ArrayList<>();

        Trade expectedTrade1 = new Trade(1, "CPU Hours", OrderType.BUY, 10, 50,
                LocalDate.parse("24/04/2021", DateTimeFormatter.ofPattern("d/MM/yyyy")), LocalDate.parse("26/04/2021", DateTimeFormatter.ofPattern("d/MM/yyyy")),
                "Finance", TRUE);
        Trade expectedTrade2 = new Trade(2, "Widgets", OrderType.BUY, 1, 5,
                LocalDate.parse("25/04/2021", DateTimeFormatter.ofPattern("d/MM/yyyy")), LocalDate.parse("27/04/2021", DateTimeFormatter.ofPattern("d/MM/yyyy")),
                "Information Technology", TRUE);
        Trade expectedTrade3 = new Trade(3, "CPU Hours", OrderType.BUY, 15, 20,
                LocalDate.parse("26/04/2021", DateTimeFormatter.ofPattern("d/MM/yyyy")), LocalDate.parse("28/04/2021", DateTimeFormatter.ofPattern("d/MM/yyyy")),
                "Human Resources", TRUE);

        expectedList.add(expectedTrade1);
        expectedList.add(expectedTrade2);
        expectedList.add(expectedTrade3);

        assertEquals(expectedList, TradesManager.getTradesList(TRUE));
    }


    /**
     * Tests if getTradesList() can be called with appropriate parameters to return an empty list when no
     * results exist in the database.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup(value = "/dbunit/trades/tradesSampleDataResolveSingle.xml")
    public void testSuccessfulGetListReturnsEmptyList() {
        List<Trade> expectedList = new ArrayList<>();

        assertEquals(expectedList, TradesManager.getTradesList(TRUE));
    }

    /**
     * Tests if getTradesList() throws an illegalResolvedStatusException when the resolvedStatus parameter is null.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup(value = "/dbunit/trades/tradesSampleDataDefaultState.xml")
    public void testGetTradeListNonBooleanResolvedStatus() {
        assertThrows(illegalResolvedStatusException.class, () -> TradesManager.getTradesList(null));
    }

    /* Tests - resolveTrade() */

    /**
     * Tests if resolveTrade() can be called with appropriate parameters to resolve a listed trade successfully.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataResolvedSingleHelper.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSuccessfulResolve() {
        TradesManager.resolveTrade(4);
    }

    /**
     * Tests if resolveTrade() throws an illegalTradeIDException when the tradeID parameter is null. Also checks
     * that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testResolveTradeNonIntegerTradeID() {
        assertThrows(illegalTradeIDException.class, () -> TradesManager.resolveTrade(null));
    }

    /**
     * Tests if resolveTrade() throws a nonExistentTradeException when the tradeID parameter is not found in the database.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testResolveTradeNonExistentTrade() {
        assertThrows(nonExistentTradeException.class, () -> TradesManager.resolveTrade(7));
    }

    /**
     * Tests if resolveTrade() throws a illegalManipulateResolvedTradeException when the tradeID parameter represents a
     * trade that has already been resolved. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testResolveTradeResolvedTrade() {
        assertThrows(illegalManipulateResolvedTradeException.class, () -> TradesManager.resolveTrade(2));
    }

    /* Tests - resolveSingleTrade() */

    /**
     * Tests if resolveSingleTrade() can be called with appropriate parameters to resolve listed trades successfully.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataResolveSingle.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataResolvedSingle.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSuccessfulResolveSingle() {
        TradesManager.resolveSingleTrade(1, "Management");
        TradesManager.resolveSingleTrade(2, "Management");
    }

    /**
     * Tests if resolveSingleTrade() throws an illegalTradeIDException when the tradeID parameter is null. Also checks
     * that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataResolveSingle.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataResolveSingle.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testResolveSingleTradeNonIntegerTradeID() {
        assertThrows(illegalTradeIDException.class, () -> TradesManager.resolveSingleTrade(null, "Management"));
    }

    /**
     * Tests if resolveSingleTrade() throws a illegalTradeIDException when the tradeID parameter is below the minimum bound.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataResolveSingle.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataResolveSingle.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testResolveSingleTradeLowerBoundaryTrade() {
        assertThrows(illegalTradeIDException.class, () -> TradesManager.resolveSingleTrade(-42, "Management"));
    }

    /**
     * Tests if resolveSingleTrade() throws a nonExistentTradeException when the tradeID parameter is not found in the database.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataResolveSingle.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataResolveSingle.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testResolveSingleTradeNonExistentTrade() {
        assertThrows(nonExistentTradeException.class, () -> TradesManager.resolveSingleTrade(42, "Management"));
    }

    /**
     * Tests if resolveSingleTrade() throws a illegalManipulateResolvedTradeException when the tradeID parameter represents a
     * trade that has already been resolved. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataResolvedSingle.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataResolvedSingle.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testResolveSingleTradeResolvedTrade() {
        assertThrows(illegalManipulateResolvedTradeException.class, () -> TradesManager.resolveSingleTrade(1, "Management"));
    }

    /**
     * Tests if resolveSingleTrade() throws an illegalOrgNameException when the organisationalUnitName parameter is
     * null. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataResolveSingle.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataResolveSingle.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testResolveSingleTradeNonStringOrganisationalUnitName() {
        assertThrows(illegalOrgNameException.class, () -> TradesManager.resolveSingleTrade(1, null));
    }

    /**
     * Tests if resolveSingleTrade() throws an illegalOrgNameException when the orgName parameter does not exist in the organisations table
     * of the database. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataResolveSingle.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataResolveSingle.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testResolveSingleTradeNonExistentOrgName() {
        assertThrows(illegalOrgNameException.class, () -> TradesManager.resolveSingleTrade(1, "I'm not real!"));
    }

    /* Tests - resolveTrades() */

    /**
     * Tests if resolveTrades() can be called to resolve outstanding trades successfully where sellTrade.getQuantity() == buyTrade.getQuantity().
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultStateResolvesEqualQuantity.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataResolvedEqualQuantity.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSuccessfulMassResolveEqualQuantity() {
        assertEquals(2, TradesManager.resolveTrades(0));
    }

    /**
     * Tests if resolveTrades() can be called to resolve outstanding trades successfully where sellTrade.getQuantity() >= buyTrade.getQuantity().
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultStateResolvesSellTradeHigherQuantity.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataResolvedSellTradeHigherQuantity.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSuccessfulMassResolveSellTradeHigherQuantity() {
        assertEquals(2, TradesManager.resolveTrades(0));
    }

    /**
     * Tests if resolveTrades() can be called to resolve outstanding trades successfully where buyTrade.getQuantity() >= sellTrade.getQuantity().
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultStateResolvesBuyTradeHigherQuantity.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataResolvedBuyTradeHigherQuantity.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSuccessfulMassResolveBuyTradeHigherQuantity() {
        assertEquals(2, TradesManager.resolveTrades(0));
    }

    /**
     * Tests if resolveTrades() throws an illegalCounterException when the currentCount parameter is below 0.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/trades/tradesSampleDataDefaultStateResolvesEqualQuantity.xml")
    @ExpectedDatabase(value = "/dbunit/trades/tradesSampleDataDefaultStateResolvesEqualQuantity.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testMassResolveInvalidCurrentCount() {
        assertThrows(illegalCounterException.class, () -> TradesManager.resolveTrades(-42));
    }
}

package server.managers;

import com.github.springtestdbunit.annotation.DbUnitConfiguration;
import com.github.springtestdbunit.assertion.DatabaseAssertionMode;
import server.database.Database;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.github.springtestdbunit.annotation.DatabaseSetup;
import com.github.springtestdbunit.annotation.ExpectedDatabase;

import server.exceptions.assets.*;
import server.exceptions.illegalAssetNameException;
import server.objects.asset.Asset;
import server.objects.asset.AssetPriceHistory;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * JUnit5 tests for the managers.AssetsManager class.
 *
 * @author Nicole Slabbert, N10476130
 * @author Daniel Taylor, N10492623
 */
@SpringBootTest
@ContextConfiguration
@DbUnitConfiguration(databaseConnection = {"dataSourceTests"})
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
        DirtiesContextTestExecutionListener.class,
        TransactionalTestExecutionListener.class,
        DbUnitTestExecutionListener.class})
public class AssetsManagerTests {
    /**
     * Make sure that the database has been created before attempting to run any tests.
     *
     * @author Daniel Taylor, N10492623
     */
    @BeforeAll
    static void initialiseTestingDatabase() {
        Database.createNewDatabase(true);
    }

    /* Tests - createAsset() */

    /**
     * Tests if createAsset() can be called with appropriate parameters and added to database.
     *
     * @author Nicole Slabbert, N10476130
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataExtraAsset.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateAssetSuccessful() {
        String assetName = "Keyboard";
        String assetDescription = "Wireless Touch Keyboard with comfortably spaced keyboard and a customisable touchpad";

        AssetsManager.createAsset(assetName, assetDescription);
    }


    /**
     * Tests if createAsset() throws an illegalAssetNameException when the assetName is not unique.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Nicole Slabbert, N10476130
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateAssetDuplicateName() {
        String assetName = "Widgets";
        String assetDescription = "Widgets for use for multiple purposes";

        assertThrows(illegalAssetNameException.class, () -> AssetsManager.createAsset(assetName, assetDescription));
    }

    /**
     * Tests if createAsset() throws an illegalAssetNameException when the assetName is too long for database constraints.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Nicole Slabbert, N10476130
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateAssetLengthyName() {
        // Create a string that exceeds the database's constraint
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(51);
        String tooLong = tooLongBuilder.toString();

        String assetDescription = "Widgets for use for multiple purposes";

        assertThrows(illegalAssetNameException.class, () -> AssetsManager.createAsset(tooLong, assetDescription));
    }

    /**
     * Tests if createAsset() throws an illegalAssetNameException when the assetName is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Nicole Slabbert, N10476130
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateAssetNullName() {
        String assetDescription = "Wireless Touch Keyboard with comfortably spaced keyboard and a customisable touchpad";

        assertThrows(illegalAssetNameException.class, () -> AssetsManager.createAsset(null, assetDescription));
    }

    /**
     * Tests if createAsset() throws an illegalAssetDescriptionException when the assetDescription is too long for database constraints.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Nicole Slabbert, N10476130
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateAssetLengthyDescription() {
        String assetName = "Keyboard";

        // Create a string that exceeds the database's constraint
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(501);
        String tooLong = tooLongBuilder.toString();

        assertThrows(illegalAssetDescriptionException.class, () -> AssetsManager.createAsset(assetName, tooLong));
    }

    /**
     * Tests if createAsset() throws an illegalAssetDescriptionException when the assetDescription is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Nicole Slabbert, N10476130
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateAssetNullDescription() {
        String assetName = "Keyboard";

        assertThrows(illegalAssetDescriptionException.class, () -> AssetsManager.createAsset(assetName, null));
    }

    /* Tests - deleteAsset() */

    /**
     * Tests if deleteAsset() can be called with the appropriate parameter to remove an asset and from the database.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataForeignKeyDeleted.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteAssetSuccessful() {
        AssetsManager.deleteAsset("Brain Cells");
    }

    /**
     * Tests if deleteAsset() throws an illegalAssetNameException when the assetName is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataForeignKeyDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteAssetNullName() {
        assertThrows(illegalAssetNameException.class, () -> AssetsManager.deleteAsset(null));
    }

    /**
     * Tests if getAssetInfo() throws an illegalAssetNameException when the assetName is not found in the database.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataForeignKeyDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteAssetNonExistentName() {
        assertThrows(illegalAssetNameException.class, () -> AssetsManager.deleteAsset("Will to live"));
    }

    /**
     * Tests if deleteAsset() throws an illegalAssetNameException when the assetName is used in an unresolved trade.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataForeignKeyDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteAssetNameUsedInUnresolvedTrade() {
        assertThrows(illegalAssetNameException.class, () -> AssetsManager.deleteAsset("Widgets"));
    }

    /**
     * Tests if deleteAsset() throws an illegalAssetNameException when the assetName is used in an resolved trade.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataForeignKeyDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteAssetNameUsedInResolvedTrade() {
        assertThrows(illegalAssetNameException.class, () -> AssetsManager.deleteAsset("CPU Hours"));
    }

    /**
     * Tests if deleteAsset() throws an illegalAssetNameException when the assetName is used in an organisational unit's inventory.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataForeignKeyDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteAssetNameUsedInInventory() {
        assertThrows(illegalAssetNameException.class, () -> AssetsManager.deleteAsset("Mouse"));
    }

    /* Tests - getAssetInfo() */

    /**
     * Tests if getAssetInfo() can be called with the appropriate parameter to retrieve an asset and it's associated information.
     *
     * @author Nicole Slabbert, N10476130
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    public void testGetAssetInfoSuccessful() {
        String assetName = "CPU Hours";
        String assetDescription = "Powerful CPU Hours driven by high power machines to use for complex computation";

        Asset expectedAsset = new Asset(assetName, assetDescription, null);

        assertEquals(expectedAsset, AssetsManager.getAssetInfo(assetName));
    }

    /**
     * Tests if getAssetInfo() throws an illegalAssetNameException when the assetName is null.
     *
     * @author Nicole Slabbert, N10476130
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    public void testGetAssetInfoNullName() {
        assertThrows(illegalAssetNameException.class, () -> AssetsManager.getAssetInfo(null));
    }

    /**
     * Tests if getAssetInfo() returns null when the assetName is not found in the database.
     *
     * @author Nicole Slabbert, N10476130
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    public void testGetAssetInfoNonExistentName() {
        assertNull(AssetsManager.getAssetInfo("Keyboard"));
    }

    /* Tests - getAssetPriceHistory() */

    /**
     * Tests if getAssetPriceHistory() can be called with the appropriate parameter to retrieve an asset and it's associated information.
     *
     * @author Nicole Slabbert, N10476130
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataPriceHistory.xml")
    public void testGetAssetPriceHistorySuccessful() {
        String assetName = "CPU Hours";

        List<AssetPriceHistory> expectedPriceHistory = new ArrayList<>();
        expectedPriceHistory.add(new AssetPriceHistory(LocalDate.of(2021, 4, 26), 10));
        expectedPriceHistory.add(new AssetPriceHistory(LocalDate.of(2021, 4, 28), 15));

        assertEquals(expectedPriceHistory, AssetsManager.getAssetPriceHistory(assetName));
    }

    /**
     * Tests if getAssetPriceHistory() throws an illegalAssetNameException when the assetName is null.
     *
     * @author Nicole Slabbert, N10476130
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataPriceHistory.xml")
    public void testGetAssetPriceHistoryNullName() {
        assertThrows(illegalAssetNameException.class, () -> AssetsManager.getAssetPriceHistory(null));
    }

    /**
     * Tests if getAssetPriceHistory() returns null when the assetName is not found in the database.
     *
     * @author Nicole Slabbert, N10476130
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataPriceHistory.xml")
    public void testGetAssetPriceHistoryNonExistentName() {
        assertNull(AssetsManager.getAssetPriceHistory("Keyboard"));
    }

    /* Tests - editAssetInfo() */

    /**
     * Tests if editAssetInfo() can be called with appropriate parameters to edit an asset successfully in the assets table.
     *
     * @author Nicole Slabbert, N10476130
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataEditedName.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditAssetInfoSuccessful() {
        AssetsManager.editAssetInfo("CPU Hours", "Extended CPU Hours", "Powerful CPU Hours driven by high power machines");
    }

    /**
     * Tests if editAssetInfo() throws an illegalOldAssetNameException when the old assetName is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Nicole Slabbert, N10476130
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditAssetInfoNullOldName() {
        assertThrows(illegalOldAssetNameException.class, () -> AssetsManager.editAssetInfo(null, "Extended CPU Hours", "Powerful CPU Hours driven by high power machines"));
    }

    /**
     * Tests if editAssetInfo() throws an illegalOldAssetNameException when the old assetName does not exist.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Nicole Slabbert, N10476130
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditAssetInfoNonExistentOldName() {
        assertThrows(illegalOldAssetNameException.class, () -> AssetsManager.editAssetInfo("Keyboard", "Keys", "Type some stuff and it magically appears"));
    }

    /**
     * Tests if editAssetInfo() throws an illegalNewAssetNameException when the new assetName is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Nicole Slabbert, N10476130
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditAssetInfoNullNewName() {
        assertThrows(illegalNewAssetNameException.class, () -> AssetsManager.editAssetInfo("CPU Hours", null, "Powerful CPU Hours driven by high power machines"));
    }

    /**
     * Tests if editAssetInfo() throws an illegalNewAssetNameException when the new assetName already exists in reference to another asset.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Nicole Slabbert, N10476130
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditAssetInfoDuplicateNewName() {
        assertThrows(illegalNewAssetNameException.class, () -> AssetsManager.editAssetInfo("CPU Hours", "Widgets", "Powerful CPU Hours driven by high power machines"));
    }

    /**
     * Tests if editAssetInfo() throws an illegalNewAssetNameException when the new assetName is too long for database constraints.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Nicole Slabbert, N10476130
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditAssetInfoLengthyNewName() {
        // Create a string that exceeds the database's constraint
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(51);
        String tooLong = tooLongBuilder.toString();

        assertThrows(illegalNewAssetNameException.class, () -> AssetsManager.editAssetInfo("CPU Hours", tooLong, "Powerful CPU Hours driven by high power machines"));
    }

    /**
     * Tests if editAssetInfo() throws an illegalAssetDescriptionException when the new assetDescription is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Nicole Slabbert, N10476130
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditAssetInfoNullDescription() {
        assertThrows(illegalAssetDescriptionException.class, () -> AssetsManager.editAssetInfo("CPU Hours", "CPU Hours", null));
    }

    /**
     * Tests if editAssetInfo() throws an illegalAssetDescriptionException when the assetDescription is too long for database constraints.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Nicole Slabbert, N10476130
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/assets/assetsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditAssetInfoLengthyDescription() {
        // Create a string that exceeds the database's constraint
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(501);
        String tooLong = tooLongBuilder.toString();

        assertThrows(illegalAssetDescriptionException.class, () -> AssetsManager.editAssetInfo("CPU Hours", "CPU Hours", tooLong));
    }

    /* Tests - getAssetsList() */

    /**
     * Tests if getAssetsList() can successfully retrieve all assets successfully.
     *
     * @author Chris Sterkenburg, N10478728
     * @author Nicole Slabbert, N10476130
     */
    @Test
    @DatabaseSetup("/dbunit/assets/assetsSampleDataDefaultState.xml")
    public void testGetAssetListSuccessful() {
        List<Asset> expectedList = new ArrayList<>();

        Asset cpuHours = new Asset("CPU Hours", "Powerful CPU Hours driven by high power machines to use for complex computation", null);
        Asset widgets = new Asset("Widgets", "Widgets for use for multiple purposes", null);

        expectedList.add(cpuHours);
        expectedList.add(widgets);

        assertEquals(expectedList, AssetsManager.getAssetsList());
    }
}
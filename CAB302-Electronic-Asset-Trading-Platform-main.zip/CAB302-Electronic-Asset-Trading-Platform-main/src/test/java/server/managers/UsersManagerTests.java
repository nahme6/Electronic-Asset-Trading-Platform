package server.managers;

import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.github.springtestdbunit.annotation.DatabaseSetup;
import com.github.springtestdbunit.annotation.DbUnitConfiguration;
import com.github.springtestdbunit.annotation.ExpectedDatabase;
import com.github.springtestdbunit.assertion.DatabaseAssertionMode;
import server.database.Database;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import server.exceptions.illegalOrgNameException;
import server.exceptions.users.*;
import server.objects.user.AccountType;
import server.objects.user.User;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit 5 tests for the managers.UsersManager class.:
 *
 * @author Navid Ahmed, N10470433
 */
@SpringBootTest
@ContextConfiguration
@DbUnitConfiguration(databaseConnection = {"dataSourceTests"})
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
        DirtiesContextTestExecutionListener.class,
        TransactionalTestExecutionListener.class,
        DbUnitTestExecutionListener.class})
public class UsersManagerTests {
    static String defaultEmail = "itadministration@genericdomain.com";

    private String email;
    private String password;
    private String firstName;
    private String lastName;
    private AccountType employeeAccountType;
    private String orgName;

    /**
     * Make sure that the database has been created before attempting to run any tests.
     *
     * @author Daniel Taylor, N10492623
     */
    @BeforeAll
    static void initialiseTestingDatabase() {
        Database.createNewDatabase(true);
    }

    /**
     * Creates a new instance of user parameters
     */
    @BeforeEach
    public void setupUserTests() {
        email = "nahme6@gmail.com";
        firstName = "Navid";
        lastName = "Ahmed";
        password = "password1234";
        employeeAccountType = AccountType.Employee;
        orgName = "Finance";
    }

    /* Tests for createUser()
       Note that these tests use dummy data that is missing columns to ignore their values in comparison, as per
       https://github.com/springtestdbunit/spring-test-dbunit/issues/115. We can fix this later if this doesn't work.
    /* ------------------------------------------------------------------------------------------------------------------------------------- */

    /**
     * Tests if createUser() can be called with appropriate parameters to list a user successfully.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataCreateUserEditedState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUser() {
        UsersManager.createUser(email, password, firstName, lastName, employeeAccountType, orgName);
    }

    /* Tests for email parameter
    /* --------------------------------------------------------------- */

    /**
     * Tests if createUser() throws an illegalEmailException when the email parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserNullEmail() {
        assertThrows(illegalEmailException.class, () -> UsersManager.createUser(null, password, firstName, lastName, employeeAccountType, orgName));
    }

    /**
     * Tests if createUser() throws an illegalEmailException when the email parameter is an empty string.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserEmptyEmail() {
        assertThrows(illegalEmailException.class, () -> UsersManager.createUser("", password, firstName, lastName, employeeAccountType, orgName));
    }

    /**
     * Tests if createUser() throws an illegalEmailException when the email parameter is an invalid email format.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserInvalidEmail() {
        String invalidEmail = "nahme6";
        assertThrows(illegalEmailException.class, () ->
                UsersManager.createUser(invalidEmail, password, firstName, lastName, employeeAccountType, orgName));
    }

    /**
     * Tests if createUser() throws an illegalEmailException when the email parameter is over 320 characters in length.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserLengthyEmail() {
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(321);
        String tooLong = tooLongBuilder.toString();

        assertThrows(illegalEmailException.class, () ->
                UsersManager.createUser(tooLong, password, firstName, lastName, employeeAccountType, orgName));
    }

    /**
     * Tests if createUser() throws an illegalEmailException when the email parameter is not unique.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserUniqueEmail() {
        String alreadyUsedEmail = "stevenhawking@stringtheory.com";

        assertThrows(illegalEmailException.class, () ->
                UsersManager.createUser(alreadyUsedEmail, password, firstName, lastName, employeeAccountType, orgName));
    }

    /* Tests for password parameter
    /* --------------------------------------------------------------- */

    /**
     * Tests if createUser() throws an illegalPasswordException when the password parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserNullPassword() {
        assertThrows(illegalPasswordException.class, () -> UsersManager.createUser(email, null, firstName, lastName, employeeAccountType, orgName));
    }

    /**
     * Tests if createUser() throws an illegalPasswordException when the password parameter is an empty string.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserEmptyPassword() {
        assertThrows(illegalPasswordException.class, () -> UsersManager.createUser(email, "", firstName, lastName, employeeAccountType, orgName));
    }

    /* Tests for firstName parameter
    /* --------------------------------------------------------------- */

    /**
     * Tests if createUser() throws an illegalFirstnameException when the firstName parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserNullFirstName() {
        assertThrows(illegalFirstNameException.class, () -> UsersManager.createUser(email, password, null, lastName, employeeAccountType, orgName));
    }

    /**
     * Tests if createUser() throws an illegalFirstNameException when the firstName parameter is an empty string.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserEmptyFirstName() {
        assertThrows(illegalFirstNameException.class, () -> UsersManager.createUser(email, password, "", lastName, employeeAccountType, orgName));
    }

    /**
     * Tests if createUser() throws an illegalFirstNameException when the firstName parameter is over 50 characters in length.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserLengthyFirstName() {
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(51);
        String tooLong = tooLongBuilder.toString();

        assertThrows(illegalFirstNameException.class, () ->
                UsersManager.createUser(email, password, tooLong, lastName, employeeAccountType, orgName));
    }

    /* Tests for lastName parameter
    /* --------------------------------------------------------------- */

    /**
     * Tests if createUser() throws an illegalLastNameException when the lastName parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserInvalidLastName() {
        assertThrows(illegalLastNameException.class, () -> UsersManager.createUser(email, password, firstName, null, employeeAccountType, orgName));
    }

    /**
     * Tests if createUser() throws an illegalLastNameException when the lastName parameter is an empty string.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserEmptyLastName() {
        assertThrows(illegalLastNameException.class, () -> UsersManager.createUser(email, password, firstName, "", employeeAccountType, orgName));
    }

    /**
     * Tests if createUser() throws an illegalLastNameException when the lastName parameter is over 50 characters in length.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserLengthyLastName() {
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(51);
        String tooLong = tooLongBuilder.toString();

        assertThrows(illegalLastNameException.class, () ->
                UsersManager.createUser(email, password, firstName, tooLong, employeeAccountType, orgName));
    }

    /* Tests for accountType parameter
    /* --------------------------------------------------------------- */

    /**
     * Tests if createUser() throws an illegalAccountTypeException when the accountType parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserNullAccountType() {
        assertThrows(illegalAccountTypeException.class, () -> UsersManager.createUser(email, password, firstName, lastName, null, orgName));
    }

    /* Tests for orgName parameter
    /* --------------------------------------------------------------- */

    /**
     * Tests if createUser() throws an illegalOrgNameException when the orgName parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserNullOrgName() {
        assertThrows(illegalOrgNameException.class, () -> UsersManager.createUser(email, password, firstName, lastName, employeeAccountType, null));
    }

    /**
     * Tests if createUser() throws an illegalOrgNameException when the orgName parameter is an empty string.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserEmptyOrgName() {
        assertThrows(illegalOrgNameException.class, () -> UsersManager.createUser(email, password, firstName, lastName, employeeAccountType, ""));
    }

    /**
     * Tests if createUser() throws an illegalOrgNameException when the orgName parameter is over 50 characters in length.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateNewUserLengthyOrg() {
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(51);
        String tooLong = tooLongBuilder.toString();

        assertThrows(illegalOrgNameException.class, () ->
                UsersManager.createUser(email, password, firstName, lastName, employeeAccountType, tooLong));
    }

    /**
     * Tests if createUser() throws an illegalOrgNameException when the orgName parameter does not exist in the
     * organisations table of the database. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataForeignKeyMustExist.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataForeignKeyMustExist.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateUserNonExistentOrgName() {
        assertThrows(illegalOrgNameException.class, () -> UsersManager.createUser(email, password, firstName, lastName, employeeAccountType, "501st"));
    }

    /* Tests for deleteUser()
    /* ------------------------------------------------------------------------------------------------------------------------------------- */

    /**
     * Tests if deleteUser() can be called with appropriate parameters to delete a user successfully.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataEditedState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteUser() {
        UsersManager.deleteUser(email);
    }

    /* Tests for email parameter
    /* --------------------------------------------------------------- */

    /**
     * Tests if deleteUser() throws an illegalEmailException when the email parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataEditedState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataEditedState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteUserNullEmail() {
        assertThrows(illegalEmailException.class, () -> UsersManager.deleteUser(null));
    }

    /**
     * Tests if deleteUser() throws an illegalEmailException when the email parameter is an empty string.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataEditedState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataEditedState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteUserEmptyEmail() {
        assertThrows(illegalEmailException.class, () -> UsersManager.deleteUser(""));
    }

    /**
     * Tests if deleteUser() throws an illegalEmailException when the email parameter is the default account's email.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataEditedState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataEditedState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteUserDefaultEmail() {
        assertThrows(illegalEmailException.class, () -> UsersManager.deleteUser(defaultEmail));
    }

    /* Tests for getUserInfo()
    /* ------------------------------------------------------------------------------------------------------------------------------------- */

    /**
     * Tests if getUserInfo() can be called with appropriate parameters to get a user successfully.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataEditedState.xml")
    public void testGetUserInfo() {
        User expectedUser = new User("dantheman@men.com", "383f7345b4b715d3c0572bac829eb3e4be29ed346c3326746700e8daa31e1bba",
                "totallyrandomsalt", "Dan", "Taylor", AccountType.Admin, "Tech Support");
        assertEquals(expectedUser, UsersManager.getUserInfo("dantheman@men.com"));
    }

    /* Tests for email parameter
    /* --------------------------------------------------------------- */

    /**
     * Tests if getUserInfo() throws an illegalEmailException when the email parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataEditedState.xml")
    public void testGetUserInfoNullEmail() {
        assertThrows(illegalEmailException.class, () -> UsersManager.getUserInfo(null));
    }

    /**
     * Tests if getUserInfo() returns null when the email parameter is not found in the database.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataEditedState.xml")
    public void testGetUserInfoNonExistentUser() {
        assertNull(UsersManager.getUserInfo("blahblah@testwillfail.com"));
    }

    /* Tests for editUserInfo()
    /* ------------------------------------------------------------------------------------------------------------------------------------- */

    /**
     * Tests if editUserInfo() can be called with appropriate parameters to edit a user successfully.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataEditedState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataEditUserState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserInfo() {
        UsersManager.editUserInfo("stevenhawking@stringtheory.com", "stevenhawking@bigbang.com", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "Steve", "Hawks", AccountType.Admin, "Tech Support");
    }

    /* Tests for currentEmail parameter
    /* --------------------------------------------------------------- */

    /**
     * Tests if editUserInfo() throws an illegalEmailException when the currentEmail parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataEditedState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataEditedState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserInfoNullEmail() {
        assertThrows(illegalEmailException.class, () -> UsersManager.editUserInfo("null",
                "stevenhawking@bigbang.com", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "Steve", "Hawks", AccountType.Admin, "Tech Support"));
    }

    /**
     * Tests if editUserInfo() throws an illegalEmailException when the email parameter is the default account's email.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataEditedState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataEditedState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserDefaultEmail() {
        assertThrows(illegalEmailException.class, () -> UsersManager.editUserInfo("itadministration@genericdomain.com",
                "stevenhawking@bigbang.com", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "Steve", "Hawks", AccountType.Admin, "Tech Support"));
    }

    /**
     * Tests if editUserInfo() throws a nonExistentUserException when the email parameter is not found in the database.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataEditedState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataEditedState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserNonExistentUser() {
        assertThrows(nonExistentUserException.class, () -> UsersManager.editUserInfo("blahblah@testwillfail.com",
                "stevenhawking@bigbang.com", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "Steve", "Hawks", AccountType.Admin, "Tech Support"));
    }

    /* Tests for newEmail parameter
    /* --------------------------------------------------------------- */

    /**
     * Tests if editUserInfo() throws an illegalEmailException when the newEmail parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserNullEmail() {
        assertThrows(illegalEmailException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                null, "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "Steve", "Hawks", AccountType.Admin, "Tech Support"));
    }

    /**
     * Tests if editUserInfo() throws an illegalEmailException when the newEmail parameter is an empty string.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserEmptyEmail() {
        assertThrows(illegalEmailException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                "", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "Steve", "Hawks", AccountType.Admin, "Tech Support"));
    }

    /**
     * Tests if editUserInfo() throws an illegalEmailException when the newEmail parameter is an invalid email format.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserInvalidEmail() {
        assertThrows(illegalEmailException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                "nahme6", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "Steve", "Hawks", AccountType.Admin, "Tech Support"));
    }

    /**
     * Tests if editUserInfo() throws an illegalEmailException when the newEmail parameter is over 320 characters in length.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserLengthyEmail() {
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(321);
        String tooLong = tooLongBuilder.toString();

        assertThrows(illegalEmailException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                tooLong, "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "Steve", "Hawks", AccountType.Admin, "Tech Support"));
    }

    /**
     * Tests if editUserInfo() throws an illegalEmailException when the newEmail parameter is not unique.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserUniqueEmail() {
        assertThrows(illegalEmailException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                "dantheman@men.com", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "Steve", "Hawks", AccountType.Admin, "Tech Support"));
    }

    /* Tests for password parameter
    /* --------------------------------------------------------------- */

    /**
     * Tests if editUserInfo() throws an illegalPasswordException when the password parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserNullPassword() {
        assertThrows(illegalPasswordException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                "stevenhawking@bigbang.com", null, "Steve", "Hawks", AccountType.Admin, "Tech Support"));
    }

    /**
     * Tests if editUserInfo() throws an illegalPasswordException when the password parameter is an empty string.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserEmptyPassword() {
        assertThrows(illegalPasswordException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                "stevenhawking@bigbang.com", "", "Steve", "Hawks", AccountType.Admin, "Tech Support"));
    }

    /**
     * Tests if editUserInfo() throws an illegalPasswordException when the password parameter is over 128 characters in length.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserLengthyPassword() {
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(129);
        String tooLong = tooLongBuilder.toString();

        assertThrows(illegalPasswordException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                "stevenhawking@bigbang.com", tooLong, "Steve", "Hawks", AccountType.Admin, "Tech Support"));
    }

    /* Tests for firstName parameter
    /* --------------------------------------------------------------- */

    /**
     * Tests if editUserInfo() throws an illegalFirstNameException when the firstName parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserNullFirstName() {
        assertThrows(illegalFirstNameException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                "stevenhawking@bigbang.com", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                null, "Hawks", AccountType.Admin, "Tech Support"));
    }

    /**
     * Tests if editUserInfo() throws an illegalFirstNameException when the firstName parameter is an empty string.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserEmptyFirstName() {
        assertThrows(illegalFirstNameException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                "stevenhawking@bigbang.com", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "", "Hawks", AccountType.Admin, "Tech Support"));
    }

    /**
     * Tests if editUserInfo() throws an illegalFirstNameException when the firstName parameter is over 50 characters in length.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserLengthyFirstName() {
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(51);
        String tooLong = tooLongBuilder.toString();

        assertThrows(illegalFirstNameException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                "stevenhawking@bigbang.com", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                tooLong, "Hawks", AccountType.Admin, "Tech Support"));
    }

    /* Tests for lastName parameter
    /* --------------------------------------------------------------- */

    /**
     * Tests if editUserInfo() throws an illegalLastNameException when the lastName parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserInvalidLastname() {
        assertThrows(illegalLastNameException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                "stevenhawking@bigbang.com", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "Steve", null, AccountType.Admin, "Tech Support"));
    }

    /**
     * Tests if editUserInfo() throws an illegalLastNameException when the lastName parameter is an empty string.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserEmptyLastname() {
        assertThrows(illegalLastNameException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                "stevenhawking@bigbang.com", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "Steve", "", AccountType.Admin, "Tech Support"));
    }

    /**
     * Tests if editUserInfo() throws an illegalLastNameException when the lastName parameter is over 50 characters in length.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserLengthyLastname() {
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(51);
        String tooLong = tooLongBuilder.toString();

        assertThrows(illegalLastNameException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                "stevenhawking@bigbang.com", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "Steve", tooLong, AccountType.Admin, "Tech Support"));
    }

    /* Tests for accountType parameter
    /* --------------------------------------------------------------- */

    /**
     * Tests if editUserInfo() throws an illegalAccountTypeException when the accountType parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserNullAccountType() {
        assertThrows(illegalAccountTypeException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                "stevenhawking@bigbang.com", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "Steve", "Hawks", null, "Tech Support"));
    }

    /* Tests for orgName parameter
    /* --------------------------------------------------------------- */

    /**
     * Tests if editUserInfo() throws an illegalOrgNameException when the orgName parameter is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserNullOrgName() {
        assertThrows(illegalOrgNameException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                "stevenhawking@bigbang.com", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "Steve", "Hawks", AccountType.Admin, null));
    }

    /**
     * Tests if editUserInfo() throws an illegalOrgNameException when the orgName parameter is an empty string.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserEmptyOrgName() {
        assertThrows(illegalOrgNameException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                "stevenhawking@bigbang.com", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "Steve", "Hawks", AccountType.Admin, ""));
    }

    /**
     * Tests if editUserInfo() throws an illegalOrgNameException when the orgName parameter is over 50 characters in length.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserLengthyOrgName() {
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(51);
        String tooLong = tooLongBuilder.toString();

        assertThrows(illegalOrgNameException.class, () -> UsersManager.editUserInfo("stevenhawking@stringtheory.com",
                "stevenhawking@bigbang.com", "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381",
                "Steve", "Hawks", AccountType.Admin, tooLong));
    }

    /**
     * Tests if editUserInfo() throws an illegalOrgNameException when the orgName parameter does not exist in the
     * organisations table of the database. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataForeignKeyMustExist.xml")
    @ExpectedDatabase(value = "/dbunit/users/usersSampleDataForeignKeyMustExist.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditUserNonExistentOrgName() {
        assertThrows(illegalOrgNameException.class, () -> UsersManager.editUserInfo("dantheman@men.com", "tired@qut.edu.au",
                "8045203851712f0cb0c774e66ab646d8f94ee6b80cffc72d975355368f963381", "Daniel", "Tayls", AccountType.Employee, "501st"));
    }

    /* Tests for getUsersList()
    /* ------------------------------------------------------------------------------------------------------------------------------------- */

    /**
     * Tests if getUsersList() can be called with appropriate parameters to get the user list successfully.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataDefaultState.xml")
    public void testGetUsersList() {
        List<User> expectedUserList = new ArrayList<>();

        User user1 = new User("chrissterk@muso.com", "51e00dbb375b7a68b0cb0cd5837c83ce0b859b5d975a1eabe00cf0e9ddd46f45",
                "totallyrandomsalt", "Chris", "Sterk", AccountType.Admin, "Tech Support");
        User user2 = new User("dantheman@men.com", "383f7345b4b715d3c0572bac829eb3e4be29ed346c3326746700e8daa31e1bba",
                "totallyrandomsalt", "Dan", "Taylor", AccountType.Admin, "Tech Support");
        User user3 = new User("ronaldmcdonald@burgerking.com", "88d289fff436462d2274c18df6f9cf5cf4800905996dea2f732f881b53a42276",
                "totallyrandomsalt", "Ronald", "McDonald", AccountType.Employee, "Payroll");
        User user4 = new User("stevenhawking@stringtheory.com", "03ace4530ca59f77530ccaad255175c13dc2e1ed98a25283a4d117b220a20d8d",
                "totallyrandomsalt", "Steven", "Hawking", AccountType.Employee, "Marketing");

        expectedUserList.add(user1);
        expectedUserList.add(user2);
        expectedUserList.add(user3);
        expectedUserList.add(user4);

        assertEquals(expectedUserList, UsersManager.getUsersList());
    }

    /* Tests for hashPassword()
    /* ------------------------------------------------------------------------------------------------------------------------------------- */

    /**
     * Tests if hashPassword() can be called with appropriate parameters to hash a user's password successfully.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    public void testHashPasswordSuccessful() {
        assertEquals("b9c950640e1b3740e98acb93e669c65766f6670dd1609ba91ff41052ba48c6f3", UsersManager.hashPassword(password));
    }

    /* Tests for password parameter
    /* --------------------------------------------------------------- */

    /**
     * Tests if hashPassword() throws an illegalPasswordException when the password parameter is null.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    public void testHashPasswordNullPassword() {
        assertThrows(illegalPasswordException.class, () -> UsersManager.hashPassword(null));
    }

    /**
     * Tests if hashPassword() throws an illegalPasswordException when the password parameter is an empty string.
     *
     * @author Navid Ahmed, N10470433
     */
    @Test
    public void testHashPasswordEmptyPassword() {
        assertThrows(illegalPasswordException.class, () -> UsersManager.hashPassword(" "));
    }

    /**
     * Tests if loginUser() can be called with appropriate parameters to generate a JWT token successfully.
     *
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataEditedState.xml")
    public void testLoginUserSuccessful() {
        String result = UsersManager.loginUser("dantheman@men.com", "alphadog");
        assertEquals("java.lang.String", result.getClass().getName());
    }

    /**
     * Tests if loginUser() throws an illegalEmailException when the email parameter is null.
     *
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataEditedState.xml")
    public void testLoginUserNullEmail() {
        assertThrows(illegalEmailException.class, () -> UsersManager.loginUser(null, "passworddoesn'tmatterforthis"));
    }

    /**
     * Tests if loginUser() throws an illegalEmailException when the email parameter is not found in the database.
     *
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataEditedState.xml")
    public void testLoginUserNonExistentUser() {
        assertThrows(illegalEmailException.class, () -> UsersManager.loginUser("notanemail@pleaseletmesleep.com", "cry"));
    }

    /**
     * Tests if loginUser() throws an illegalPasswordException when the password parameter is null.
     *
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataEditedState.xml")
    public void testLoginUserNullPassword() {
        assertThrows(illegalPasswordException.class, () -> UsersManager.loginUser("dantheman@men.com", null));
    }

    /**
     * Tests if loginUser() throws an illegalPasswordException when the password parameter is incorrect.
     *
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/users/usersSampleDataEditedState.xml")
    public void testLoginUserIncorrectPassword() {
        assertThrows(illegalPasswordException.class, () -> UsersManager.loginUser("dantheman@men.com", "passwordisWRONG"));
    }
}
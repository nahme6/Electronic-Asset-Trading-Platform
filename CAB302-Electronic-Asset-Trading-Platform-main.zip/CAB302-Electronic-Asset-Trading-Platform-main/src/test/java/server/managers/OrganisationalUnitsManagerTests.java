package server.managers;

import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.github.springtestdbunit.annotation.DatabaseSetup;
import com.github.springtestdbunit.annotation.DbUnitConfiguration;
import com.github.springtestdbunit.annotation.ExpectedDatabase;
import com.github.springtestdbunit.assertion.DatabaseAssertionMode;
import server.database.Database;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import server.exceptions.illegalAssetNameException;
import server.exceptions.illegalQuantityException;
import server.exceptions.organisationalUnit.illegalNewOrgNameException;
import server.exceptions.organisationalUnit.illegalOldOrgNameException;
import server.exceptions.illegalOrgNameException;
import server.exceptions.wouldRiskDebtException;
import server.exceptions.illegalCreditsException;
import server.objects.organisation.OrganisationalUnit;

import java.util.HashMap;
import java.util.ArrayList;

/**
 * JUnit5 tests for the OrganisationalUnit class.
 *
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */

@SpringBootTest
@ContextConfiguration
@DbUnitConfiguration(databaseConnection = {"dataSourceTests"})
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
        DirtiesContextTestExecutionListener.class,
        TransactionalTestExecutionListener.class,
        DbUnitTestExecutionListener.class})
public class OrganisationalUnitsManagerTests {
    /**
     * Make sure that the database has been created before attempting to run any tests.
     *
     * @author Daniel Taylor, N10492623
     */
    @BeforeAll
    static void initialiseTestingDatabase() {
        Database.createNewDatabase(true);
    }

    /* Tests - createOrg() */

    /**
     * Tests if createOrg() can be called with appropriate parameters and added to database.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataExtraOrg.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateOrgSuccessful() {
        String orgName = "Human Resources";
        int creditBalance = 100;

        OrganisationalUnitsManager.createOrg(orgName, creditBalance);
    }

    /**
     * Tests if createOrg() throws an illegalOrgNameException when the orgName is not unique.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateOrgDuplicateName() {
        String orgName = "Finance";
        int creditBalance = 100;

        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.createOrg(orgName, creditBalance));
    }

    /**
     * Tests if createOrg() throws an illegalOrgNameException when the orgName is too long.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateOrgLengthyName() {
        // Create a string that exceeds the database's constraint
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(51);
        String tooLong = tooLongBuilder.toString();

        int creditBalance = 100;

        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.createOrg(tooLong, creditBalance));
    }

    /**
     * Tests if createOrg() throws an illegalOrgNameException when the orgName is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testCreateOrgNullName() {
        int creditBalance = 100;

        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.createOrg(null, creditBalance));
    }

    /**
     * Tests if createOrg() throws an illegalCreditsException when the creditBalance is below the minimum boundary of 0.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void createOrgTestInvalidCreditBalance2() {
        String orgName = "Finance";
        int creditBalance = -1;

        assertThrows(illegalCreditsException.class, () -> OrganisationalUnitsManager.createOrg(orgName, creditBalance));
    }


    /* Tests - deleteOrg() */

    /**
     * Tests if deleteOrg() can be called with the appropriate parameter to remove an organisational unit and from the database.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDeleted.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteOrgSuccessful() {
        OrganisationalUnitsManager.deleteOrg("212th");
    }

    /**
     * Tests if deleteOrg() throws an illegalOrgNameException when the orgName is the default organisational unit.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteOrgDefaultName() {
        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.deleteOrg("IT Administration"));
    }

    /**
     * Tests if deleteOrg() throws an illegalOrgNameException when the orgName is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteOrgNullName() {
        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.deleteOrg(null));
    }

    /**
     * Tests if deleteOrg() throws an illegalOrgNameException when the orgName does not exist in the database.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteOrgNonExistentName() {
        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.deleteOrg("104th"));
    }

    /**
     * Tests if deleteOrg() throws an illegalOrgNameException when the orgName is used in an unresolved trade.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteOrgUsedInUnresolvedTrade() {
        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.deleteOrg("Marketing"));
    }

    /**
     * Tests if deleteOrg() throws an illegalOrgNameException when the orgName is used in a resolved trade.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteOrgUsedInResolvedTrade() {
        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.deleteOrg("Finance"));
    }

    /**
     * Tests if deleteOrg() throws an illegalOrgNameException when the orgName has an inventory.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteOrgUsedInInventory() {
        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.deleteOrg("Payroll"));
    }

    /**
     * Tests if deleteOrg() throws an illegalOrgNameException when the orgName has a user in it.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testDeleteOrgUsedInUser() {
        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.deleteOrg("501st"));
    }

    /* Tests - getOrgInfo() */

    /**
     * Tests if getOrgInfo() can be called with appropriate parameter to retrieve an organisational unit with an inventory.
     *
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    public void testGetOrgInfoInventorySuccessful() {
        String orgName = "Payroll";
        int creditBalance = 50;
        HashMap<String, Integer> inventory = new HashMap<>();

        inventory.put("CPU Hours", 300);

        OrganisationalUnit expectedOrg = new OrganisationalUnit(orgName, creditBalance, inventory);

        assertEquals(expectedOrg, OrganisationalUnitsManager.getOrgInfo("Payroll"));
    }

    /**
     * Tests if getOrgInfo() can be called with appropriate parameter to retrieve an organisational unit with no inventory.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    public void testGetOrgInfoNoInventorySuccessful() {
        String orgName = "Marketing";
        int creditBalance = 150;
        HashMap<String, Integer> orgInventory = new HashMap<>();

        OrganisationalUnit expectedOrg = new OrganisationalUnit(orgName, creditBalance, orgInventory);

        assertEquals(expectedOrg, OrganisationalUnitsManager.getOrgInfo("Marketing"));
    }

    /**
     * Tests if getOrgInfo() throws an illegalOrgNameException when the OrgName is null.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    public void testGetOrgInfoNullName() {
        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.getOrgInfo(null));
    }

    /**
     * Tests if getOrgInfo() returns null when the OrgName is not found in the database.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    public void testGetOrgInfoNonExistentName() {
        assertNull(OrganisationalUnitsManager.getOrgInfo("Facilities"));
    }

    /* Tests - editOrgName() */

    /**
     * Tests if editOrgName() can be called with appropriate parameters to edit an organisational unit's name successfully.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataNoCascade.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataNameEdited.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditOrgNameSuccessful() {
        OrganisationalUnitsManager.editOrgName("IT", "Tech Support");
    }

    /**
     * Tests if editOrgName() throws an illegalOldOrgNameException when the old orgName is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditOrgNameNullOldName() {
        assertThrows(illegalOldOrgNameException.class, () -> OrganisationalUnitsManager.editOrgName(null, "Tech Support"));
    }

    /**
     * Tests if editOrgName() throws an illegalOrgNameException when the old orgName does not exist.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditOrgNameNonExistentOldName() {
        assertThrows(illegalOldOrgNameException.class, () -> OrganisationalUnitsManager.editOrgName("BAZINGA", "Tech Support"));
    }

    /**
     * Tests if editOrgName() throws an illegalOrgNameException when the old orgName is the default organisational unit.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditOrgNameDefaultOldName() {
        assertThrows(illegalOldOrgNameException.class, () -> OrganisationalUnitsManager.editOrgName("IT Administration", "Tech Support"));
    }

    /**
     * Tests if editOrgName() throws an illegalNewOrgNameException when the new orgName is too long.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditOrgNameLengthyNewName() {
        // Create a string that exceeds the database's constraint
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(51);
        String tooLong = tooLongBuilder.toString();

        assertThrows(illegalNewOrgNameException.class, () -> OrganisationalUnitsManager.editOrgName("IT", tooLong));
    }

    /**
     * Tests if editOrgName() throws an illegalNewOrgNameException when the new orgName is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditOrgNameNullNewName() {
        assertThrows(illegalNewOrgNameException.class, () -> OrganisationalUnitsManager.editOrgName("IT", null));
    }

    /**
     * Tests if editOrgName() throws an illegalNewOrgNameException when the new orgName already exists.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testEditOrgNameDuplicateNewName() {
        assertThrows(illegalNewOrgNameException.class, () -> OrganisationalUnitsManager.editOrgName("IT", "Payroll"));
    }

    /* Tests - setCredits() */

    /**
     * Tests if setCredits() can be called with appropriate parameters to edit an organisational unit's credits successfully.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataCreditsEdited.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSetCreditsSuccessful() {
        OrganisationalUnitsManager.setCredits("Payroll", 100);
    }

    /**
     * Tests if setCredits() throws an illegalOrgNameException when the orgName does not exist.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSetCreditsNonExistentName() {
        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.setCredits("Human Resources", 100));
    }

    /**
     * Tests if setCredits() throws an illegalOrgNameException when the orgName is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSetCreditsNullName() {
        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.setCredits(null, 100));
    }

    /**
     * Tests if setCredits() throws an illegalCreditsException when the creditBalance is below the minimum boundary of 0.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSetCreditsLowerBoundaryCredits() {
        assertThrows(illegalCreditsException.class, () -> OrganisationalUnitsManager.setCredits("Payroll", -1));
    }

    /**
     * Tests if setCredits() throws an illegalCreditsException when the creditBalance is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSetCreditsNullCredits() {
        assertThrows(illegalCreditsException.class, () -> OrganisationalUnitsManager.setCredits("Payroll", null));
    }

    /**
     * Tests if setCredits() throws an wouldRiskDebtException when the creditBalance would put the organisational unit at risk
     * of falling into debt. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSetCreditsWouldCauseDebt() {
        assertThrows(wouldRiskDebtException.class, () -> OrganisationalUnitsManager.setCredits("IT", 1));
    }

    /* Tests - setInventory() */

    /**
     * Tests if setInventory() can be called with appropriate parameters to edit an organisational unit's inventory successfully.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryEdited.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSetInventorySuccessful() {
        HashMap<String, Integer> inventory = new HashMap<>();
        inventory.put("CPU Hours", 66);

        OrganisationalUnitsManager.setInventory("IT", inventory);
    }

    /**
     * Tests if setInventory() throws an illegalOrgNameException when the orgName is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSetInventoryNullOrgName() {
        HashMap<String, Integer> inventory = new HashMap<>();
        inventory.put("Widgets", 66);

        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.setInventory(null, inventory));
    }

    /**
     * Tests if setInventory() throws an illegalOrgNameException when the orgName does not exist.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSetInventoryNonExistentOrgName() {
        HashMap<String, Integer> inventory = new HashMap<>();
        inventory.put("Widgets", 66);

        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.setInventory("Boss Man", inventory));
    }

    /**
     * Tests if setInventory() throws an illegalAssetNameException when an assetName in the inventory is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSetInventoryNullAssetName() {
        HashMap<String, Integer> inventory = new HashMap<>();
        inventory.put(null, 66);

        assertThrows(illegalAssetNameException.class, () -> OrganisationalUnitsManager.setInventory("IT", inventory));
    }

    /**
     * Tests if setInventory() throws an illegalAssetNameException when an assetName in the inventory is too long.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSetInventoryLengthyAssetName() {
        HashMap<String, Integer> inventory = new HashMap<>();

        // Create a string that exceeds the database's constraint
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(51);
        String tooLong = tooLongBuilder.toString();

        inventory.put(tooLong, 66);

        assertThrows(illegalAssetNameException.class, () -> OrganisationalUnitsManager.setInventory("IT", inventory));
    }

    /**
     * Tests if setInventory() throws an illegalAssetNameException when an assetName in the inventory does not exist in the
     * assets table of the database. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyMustExist.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyMustExist.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSetInventoryNonExistentAssetName() {
        HashMap<String, Integer> inventory = new HashMap<>();
        inventory.put("Kappas", 66);

        assertThrows(illegalAssetNameException.class, () -> OrganisationalUnitsManager.setInventory("Finance", inventory));
    }

    /**
     * Tests if setInventory() throws an illegalQuantityException when a quantity in the inventory is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSetInventoryNullQuantity() {
        HashMap<String, Integer> inventory = new HashMap<>();
        inventory.put("Widgets", null);

        assertThrows(illegalQuantityException.class, () -> OrganisationalUnitsManager.setInventory("IT", inventory));
    }

    /**
     * Tests if setInventory() throws an illegalQuantityException when the quantity is below the minimum boundary of 1.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSetInventoryLowerBoundaryQuantity() {
        HashMap<String, Integer> inventory = new HashMap<>();
        inventory.put("Widgets", -47);

        assertThrows(illegalQuantityException.class, () -> OrganisationalUnitsManager.setInventory("IT", inventory));
    }

    /**
     * Tests if setInventory() throws an wouldRiskDebtException when the quantity would put the organisational unit at risk
     * of falling into debt. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testSetInventoryWouldCauseDebt() {
        HashMap<String, Integer> inventory = new HashMap<>();
        inventory.put("Keyboard", 1);

        assertThrows(wouldRiskDebtException.class, () -> OrganisationalUnitsManager.setInventory("IT", inventory));
    }

    /* Tests - getOrgsList() */

    /**
     * Tests getOrgsList() returns all current organisational units stored in the database.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    public void testGetOrgsListSuccessful() {
        ArrayList<OrganisationalUnit> expectedList = new ArrayList<>();

        String orgName1 = "Payroll";
        int creditBalance1 = 50;
        HashMap<String, Integer> inventory1 = new HashMap<>();
        inventory1.put("CPU Hours", 300);

        OrganisationalUnit payrollOrg = new OrganisationalUnit(orgName1, creditBalance1, inventory1);

        String orgName2 = "IT";
        int creditBalance2 = 200;
        HashMap<String, Integer> inventory2 = new HashMap<>();
        inventory2.put("CPU Hours", 50);

        OrganisationalUnit ITOrg = new OrganisationalUnit(orgName2, creditBalance2, inventory2);

        expectedList.add(new OrganisationalUnit("Finance", 100, new HashMap<>()));
        expectedList.add(ITOrg);
        expectedList.add(new OrganisationalUnit("Marketing", 150, new HashMap<>()));
        expectedList.add(payrollOrg);

        assertEquals(expectedList, OrganisationalUnitsManager.getOrgsList());
    }

    /* Tests - addCredits() */

    /**
     * Tests addCredits() adds the correct amount of credits to the specified organisational unit.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataCreditsEdited.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testAddCreditsSuccessful() {
        String orgName1 = "Payroll";
        int creditsToAdd = 50;

        OrganisationalUnitsManager.addCredits(orgName1, creditsToAdd);
    }

    /**
     * Tests if addCredits() throws an illegalOrgNameException when the orgName does not exist.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testAddCreditsNonExistentOrgName() {
        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.addCredits("104th", 50));
    }

    /**
     * Tests if addCredits() throws an illegalCreditException when the creditToAdd is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testAddCreditsNullCredits() {
        String orgName1 = "Payroll";

        assertThrows(illegalCreditsException.class, () -> OrganisationalUnitsManager.addCredits(orgName1, null));
    }

    /**
     * Tests if addCredits() throws an illegalCreditException when the creditToAdd is a below the minimum boundary of 1.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testAddCreditsLowerBoundaryCredits() {
        String orgName1 = "Payroll";
        int creditsToAdd = -50;

        assertThrows(illegalCreditsException.class, () -> OrganisationalUnitsManager.addCredits(orgName1, creditsToAdd));
    }

    /* Tests - removeCredits() */

    /**
     * Tests that removeCredits() removes the specified amount of credits.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataCreditsEdited.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testRemoveCreditsSuccessful() {
        String orgName1 = "Payroll";

        int creditsToRemove = 50;
        OrganisationalUnitsManager.removeCredits(orgName1, creditsToRemove);
    }

    /**
     * Tests if removeCredits() throws an illegalOrgNameException when the orgName does not exist.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testRemoveCreditsNonExistentOrgName() {
        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.removeCredits("104th", 50));
    }

    /**
     * Tests if removeCredits() throws an illegalCreditException when the creditToRemove is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testRemoveCreditsNullCredits() {
        String orgName1 = "Payroll";

        assertThrows(illegalCreditsException.class, () -> OrganisationalUnitsManager.removeCredits(orgName1, null));
    }

    /**
     * Tests if removeCredits() throws an illegalCreditException when the creditToRemove is a below the minimum boundary of 1.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testRemoveCreditsLowerBoundaryCredits() {
        String orgName1 = "Payroll";
        int creditsToRemove = -50;

        assertThrows(illegalCreditsException.class, () -> OrganisationalUnitsManager.removeCredits(orgName1, creditsToRemove));
    }

    /**
     * Tests if removeCredits() throws an wouldRiskDebtException when the creditToRemove would put the organisational unit
     * into debt. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testRemoveCreditsWouldCauseDebt() {
        assertThrows(wouldRiskDebtException.class, () -> OrganisationalUnitsManager.removeCredits("IT", 201));
    }

    /* Tests - addToInventory() */

    /**
     * Tests that addToInventory() adds the specified quantity.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryEdited.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testAddToInventorySuccessful() {
        String orgName = "IT";
        String assetName = "CPU Hours";
        int quantityToAdd = 16;

        OrganisationalUnitsManager.addToInventory(orgName, assetName, quantityToAdd);
    }

    /**
     * Tests that addToInventory() throws an illegalOrgNameException when the orgName is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testAddToInventoryNullOrgName() {
        String assetName = "CPU Hours";
        int quantityToAdd = 16;

        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.addToInventory(null, assetName, quantityToAdd));
    }

    /**
     * Tests that addToInventory() throws an illegalOrgNameException when the orgName does not exist.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testAddToInventoryNonExistentOrgName() {
        String assetName = "CPU Hours";
        int quantityToAdd = 16;

        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.addToInventory("Pogchamp", assetName, quantityToAdd));
    }

    /**
     * Tests that addToInventory() throws an illegalAssetNameException when the assetName is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testAddToInventoryNullAssetName() {
        String orgName = "IT";
        int quantityToAdd = 16;

        assertThrows(illegalAssetNameException.class, () -> OrganisationalUnitsManager.addToInventory(orgName, null, quantityToAdd));
    }

    /**
     * Tests that addToInventory() throws an illegalAssetNameException when the assetName is too long.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testAddToInventoryLengthyAssetName() {
        String orgName = "IT";
        int quantityToAdd = 16;

        // Create a string that exceeds the database's constraint
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(51);
        String tooLong = tooLongBuilder.toString();

        assertThrows(illegalAssetNameException.class, () -> OrganisationalUnitsManager.addToInventory(orgName, tooLong, quantityToAdd));
    }

    /**
     * Tests if addToInventory() throws an illegalAssetNameException when an assetName does not exist in the
     * assets table of the database. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyMustExist.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyMustExist.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testAddToInventoryNonExistentAssetName() {
        String orgName = "Finance";
        String assetName = "Kappas";
        int quantityToAdd = 66;

        assertThrows(illegalAssetNameException.class, () -> OrganisationalUnitsManager.addToInventory(orgName, assetName, quantityToAdd));
    }

    /**
     * Tests that addToInventory() throws an illegalQuantityException when the quantityToAdd is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testAddToInventoryNullQuantity() {
        String orgName = "IT";
        String assetName = "CPU Hours";

        assertThrows(illegalQuantityException.class, () -> OrganisationalUnitsManager.addToInventory(orgName, assetName, null));
    }

    /**
     * Tests that addToInventory() throws an illegalQuantityException when the quantityToAdd is below the minimum bound of 1.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testAddToInventoryLowerBoundaryQuantity() {
        String orgName = "IT";
        String assetName = "CPU Hours";
        int quantityToAdd = -47;

        assertThrows(illegalQuantityException.class, () -> OrganisationalUnitsManager.addToInventory(orgName, assetName, quantityToAdd));
    }

    /* Tests - removeFromInventory() */

    /**
     * Tests that removeFromInventory() removes the specified quantity.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryEdited.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testRemoveFromInventorySuccessful() {
        String orgName = "IT";
        String assetName = "CPU Hours";

        int quantityToRemove = 16;
        OrganisationalUnitsManager.removeFromInventory(orgName, assetName, quantityToRemove);
    }

    /**
     * Tests that removeFromInventory() removes the specified quantity.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryEdited.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryRemovedRow.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testRemoveFromInventoryRemoveRowSuccessful() {
        String orgName = "IT";
        String assetName = "CPU Hours";

        int quantityToRemove = 66;
        OrganisationalUnitsManager.removeFromInventory(orgName, assetName, quantityToRemove);
    }


    /**
     * Tests that removeFromInventory() throws an illegalOrgNameException when the orgName is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryEdited.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryEdited.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testRemoveFromInventoryNullOrgName() {
        String assetName = "CPU Hours";
        int quantityToRemove = 16;

        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.removeFromInventory(null, assetName, quantityToRemove));
    }

    /**
     * Tests that removeFromInventory() throws an illegalOrgNameException when the orgName does not exist.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryEdited.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryEdited.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testRemoveFromInventoryNonExistentOrgName() {
        String assetName = "CPU Hours";
        int quantityToRemove = 16;

        assertThrows(illegalOrgNameException.class, () -> OrganisationalUnitsManager.removeFromInventory("Pogchamp", assetName, quantityToRemove));
    }

    /**
     * Tests that removeFromInventory() throws an illegalAssetNameException when the assetName is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryEdited.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryEdited.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testRemoveFromInventoryNullAssetName() {
        String orgName = "IT";
        int quantityToRemove = 16;

        assertThrows(illegalAssetNameException.class, () -> OrganisationalUnitsManager.removeFromInventory(orgName, null, quantityToRemove));
    }

    /**
     * Tests that removeFromInventory() throws an illegalAssetNameException when the assetName is too long.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryEdited.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryEdited.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testRemoveFromInventoryLengthyAssetName() {
        String orgName = "IT";
        int quantityToRemove = 16;

        // Create a string that exceeds the database's constraint
        StringBuilder tooLongBuilder = new StringBuilder("tooLong");
        tooLongBuilder.setLength(51);
        String tooLong = tooLongBuilder.toString();

        assertThrows(illegalAssetNameException.class, () -> OrganisationalUnitsManager.addToInventory(orgName, tooLong, quantityToRemove));
    }

    /**
     * Tests that removeFromInventory() throws an illegalQuantityException when the quantityToRemove is null.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryEdited.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryEdited.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void testRemoveFromInventoryNullQuantity() {
        String orgName = "IT";
        String assetName = "CPU Hours";

        assertThrows(illegalQuantityException.class, () -> OrganisationalUnitsManager.removeFromInventory(orgName, assetName, null));
    }

    /**
     * Tests that removeFromInventory() throws an illegalQuantityException when the quantityToRemove is below the minimum bound of 1.
     * Also checks that the database is not changed when the exception is thrown.
     *
     * @author Chris Sterkenburg, N10478728
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryEdited.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataInventoryEdited.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void removeFromInventoryTest4() {
        String orgName = "Human Resources";
        String assetName = "CPU Hours";
        int quantityToRemove = -47;

        assertThrows(illegalQuantityException.class, () -> OrganisationalUnitsManager.removeFromInventory(orgName, assetName, quantityToRemove));
    }

    /**
     * Tests that removeFromInventory() throws an wouldRiskDebtException when the quantityToRemove would put the organisational unit at risk
     * of falling into debt. Also checks that the database is not changed when the exception is thrown.
     *
     * @author Daniel Taylor, N10492623
     */
    @Test
    @DatabaseSetup("/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml")
    @ExpectedDatabase(value = "/dbunit/organisationalUnits/organisationalUnitsSampleDataForeignKeyDefaultState.xml", assertionMode = DatabaseAssertionMode.NON_STRICT_UNORDERED)
    public void removeFromInventoryWouldCauseDebt() {
        String orgName = "IT";
        String assetName = "Keyboard";
        int quantityToRemove = 103;

        assertThrows(wouldRiskDebtException.class, () -> OrganisationalUnitsManager.removeFromInventory(orgName, assetName, quantityToRemove));
    }
}

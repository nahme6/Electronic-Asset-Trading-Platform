package server.communication.organisationEndpoint;

import org.springframework.web.bind.annotation.*;
import server.objects.organisation.OrganisationalUnit;

import java.util.List;

/**
 * Back-end Java class that maps values from OrganisationService to the RestController allowing access from the client.
 *
 * @author Nicole Slabbert, N10476130
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@RestController
@CrossOrigin
public final class OrganisationsResource {
    // Read Methods:

    /**
     * Method for getting a list of OrganisationalUnit objects.
     *
     * @return Returns a list of OrganisationalUnit objects as a JSON to the end point
     * @author Chris Sterkenburg, N10478728
     */
    @GetMapping("/organisationalUnits")
    public List<OrganisationalUnit> readAllOrganisationalUnits() {
        return OrganisationsService.readAllOrganisationalUnits();
    }

    /**
     * Method for getting a list of OrganisationalUnit inventories.
     *
     * @param orgName name of the organisational unit
     * @return Returns a list of an OrganisationalUnit's inventory as a JSON to the end point
     * @author Chris Sterkenburg, N10478728
     */
    @GetMapping("/organisationalUnits/inventory/{orgName}")
    public List<String> readIndividualOrganisationalUnitInventory(@PathVariable String orgName) {
        return OrganisationsService.readIndividualOrganisationalUnitInventory(orgName);
    }

    /**
     * Method for getting the information pertaining to the specified orgName.
     *
     * @param orgName name of the organisational unit
     * @return Returns an OrganisationalUnit object as a JSON to the end point
     * @author Chris Sterkenburg, N10478728
     */
    @GetMapping("/organisationalUnits/{orgName}")
    public OrganisationalUnit readIndividualOrganisationalUnit(@PathVariable String orgName) {
        return OrganisationsService.readIndividualOrganisationalUnit(orgName);
    }

    // Create Methods:

    /**
     * Method for posting a JSON OrganisationalUnit object into the database.
     *
     * @param organisationalUnit JSON object containing the parameters of an OrganisationalUnit object.
     * @author Chris Sterkenburg, N10478728
     */
    @PostMapping("/organisationalUnits")
    public void createOrganisationalUnit(@RequestBody OrganisationalUnit organisationalUnit) {
        OrganisationsService.createOrganisationalUnit(organisationalUnit);
    }

    // Edit Methods:

    /**
     * Method for putting a JSON OrganisationalUnit object into the database.
     *
     * @param orgName            name of the organisational unit
     * @param organisationalUnit JSON object containing OrganisationalUnit object parameters
     * @author Chris Sterkenburg, N10478728
     */
    @PutMapping("/organisationalUnits/edit/{orgName}")
    public void editOrganisationalUnit(@PathVariable String orgName, @RequestBody OrganisationalUnit organisationalUnit) {
        OrganisationsService.editOrganisationalUnit(orgName, organisationalUnit);
    }

    // Delete Methods:

    /**
     * Method for deleting the information pertaining to the specified organisational unit.
     *
     * @param orgName name of the organisational unit
     * @author Chris Sterkenburg, N10478728
     */
    @DeleteMapping("/organisationalUnits/{orgName}")
    public void deleteOrganisationalUnit(@PathVariable String orgName) {
        OrganisationsService.deleteOrganisationalUnit(orgName);
    }
}

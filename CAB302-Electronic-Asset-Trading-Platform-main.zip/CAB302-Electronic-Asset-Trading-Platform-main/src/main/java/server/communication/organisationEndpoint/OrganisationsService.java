package server.communication.organisationEndpoint;

import org.springframework.stereotype.Service;
import server.exceptions.illegalOrgNameException;
import server.exceptions.organisationalUnit.illegalOldOrgNameException;
import server.managers.OrganisationalUnitsManager;
import server.objects.organisation.OrganisationalUnit;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Back-end Java class that calls the appropriate methods from the OrganisationalUnitsManager class where requested
 * by the client with their results defined in the service layer.
 *
 * @author Nicole Slabbert, N10476130
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@Service
public final class OrganisationsService {
    // Read Methods:

    /**
     * Method for reading all Organisational Units stored in the database.
     *
     * @return Returns a list of all Organisational Units
     * @author Chris Sterkenburg, N10478728
     */
    public static List<OrganisationalUnit> readAllOrganisationalUnits() {
        List<OrganisationalUnit> readOrgs = OrganisationalUnitsManager.getOrgsList();

        // Check if readOrgs is empty, if so return an empty list
        if (readOrgs.isEmpty()) return new ArrayList<>();

        return readOrgs;
    }

    /**
     * Method for reading the inventory of an organisational unit stored in the database.
     *
     * @param orgName name of the organisational unit
     * @return Returns a list containing the inventory
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static List<String> readIndividualOrganisationalUnitInventory(String orgName) {
        List<String> returnedList = new ArrayList<>();

        OrganisationalUnit retrievedOrg = OrganisationalUnitsManager.getOrgInfo(orgName);

        // Validate that the retrievedOrg exists
        if (retrievedOrg == null) {
            throw new illegalOrgNameException("The orgName parameter does not exist in the organisational_unit table.");
        }

        // Handle empty inventories appropriately
        HashMap<String, Integer> inventory = retrievedOrg.getInventory();
        if (inventory.equals(new HashMap<>())) {
            return returnedList;
        }

        // Add the values from the inventory to the returned list
        inventory.forEach((k, v) -> returnedList.add(k));
        return returnedList;
    }

    /**
     * Method for reading an individual organisational unit currently stored in the database.
     *
     * @param orgName name of the organisational unit
     * @return Returns the organisational unit
     * @author Chris Sterkenburg, N10478728
     */
    public static OrganisationalUnit readIndividualOrganisationalUnit(String orgName) {
        // Return OrganisationalUnit object, null otherwise
        return OrganisationalUnitsManager.getOrgInfo(orgName);
    }

    // Create Methods:

    /**
     * Method for creating a new organisational unit and adding into the database.
     *
     * @param organisationalUnit OrganisationalUnit object used to populate the data fields for insertion into the database
     * @author Chris Sterkenburg, N10478728
     */
    public static void createOrganisationalUnit(OrganisationalUnit organisationalUnit) {
        OrganisationalUnitsManager.createOrg(organisationalUnit.getOrgName(), organisationalUnit.getCreditBalance());
        OrganisationalUnitsManager.setInventory(organisationalUnit.getOrgName(), organisationalUnit.getInventory());
    }

    // Edit Methods:

    /**
     * Method for updating an organisational unit's parameters in the database.
     *
     * @param orgName            Name of organisational unit
     * @param organisationalUnit Organisational Unit used to populate the data fields for insertion into the database
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static void editOrganisationalUnit(String orgName, OrganisationalUnit organisationalUnit) {
        // Retrieve the org's current state from the database
        OrganisationalUnit retrievedOrg = OrganisationalUnitsManager.getOrgInfo(orgName);

        // Validate that the retrievedOrg exists
        if (retrievedOrg == null) {
            throw new illegalOldOrgNameException("The oldOrgName parameter does not exist in the organisational_unit table.");
        }

        // Define variables to hold parameters for calling of manager methods.
        Integer newCreditBalance = organisationalUnit.getCreditBalance();
        HashMap<String, Integer> newInventory = organisationalUnit.getInventory();
        String newOrgName = organisationalUnit.getOrgName();

        // Check for and replace null values with the value stored in the database
        if (newCreditBalance == null) newCreditBalance = retrievedOrg.getCreditBalance();
        if (newInventory == null) newInventory = retrievedOrg.getInventory();
        if (newOrgName == null) newOrgName = retrievedOrg.getOrgName();

        OrganisationalUnitsManager.setCredits(orgName, newCreditBalance);
        OrganisationalUnitsManager.setInventory(orgName, newInventory);
        OrganisationalUnitsManager.editOrgName(orgName, newOrgName);
    }

    // Delete Methods:

    /**
     * Method for deleting an organisational unit from the database.
     *
     * @param orgName name of the organisational unit
     * @author Chris Sterkenburg, N10478728
     */
    public static void deleteOrganisationalUnit(String orgName) {
        OrganisationalUnitsManager.deleteOrg(orgName);
    }
}

package server.communication.userEndpoint;

import org.springframework.web.bind.annotation.*;
import server.objects.user.PasswordChangeRequest;
import server.objects.user.User;

import java.util.List;

/**
 * Back-end Java class that maps values from UsersService to the RestController allowing access from the client.
 *
 * @author Nicole Slabbert, N10476130
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@RestController
@CrossOrigin
public final class UsersResource {
    // Read Methods:

    /**
     * Method for getting a list of all User objects.
     *
     * @return Returns a list of User objects as a JSON to the end point
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @GetMapping("/users")
    public List<User> readAllUsers() {
        return UsersService.readAllUsers();
    }

    /**
     * Method for getting a User Object pertaining to the specified user.
     *
     * @param email email of the user
     * @return Returns the User object as a JSON to the end point
     * @author Chris Sterkenburg, N10478728
     */
    @GetMapping("/users/{email}")
    public User readIndividualUser(@PathVariable String email) {
        return UsersService.readIndividualUser(email);
    }

    // Create Methods:

    /**
     * Method for posting a JSON User object into the database.
     *
     * @param user JSON object containing the parameters of an User object
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @PostMapping("/users")
    public void createUser(@RequestBody User user) {
        UsersService.createUser(user);
    }

    /**
     * Method for generating a JWT web token for the specified user.
     *
     * @param user JSON object containing User object parameters
     * @return Returns JWT web token
     * @author Chris Sterkenburg, N10478728
     */
    @PostMapping("/users/login")
    public String loginUser(@RequestBody User user) {
        return UsersService.loginUser(user);
    }


    // Edit Methods:

    /**
     * Method for putting a JSON User object into the database.
     *
     * @param email email of the user
     * @param user  JSON object containing the parameters of an User object
     * @author Chris Sterkenburg, N10478728
     */
    @PutMapping("/users/edit/{email}")
    public void editUser(@PathVariable String email, @RequestBody User user) {
        UsersService.editUser(email, user);
    }

    /**
     * Method for putting a JSON PasswordChangeRequest object into the database.
     *
     * @param email                 email of the user
     * @param passwordChangeRequest JSON object containing an oldPassword parameter and a newPassword parameter.
     * @author Chris Sterkenburg, N10478728
     */
    @PutMapping("/users/edit/password/{email}")
    public void editPassword(@PathVariable String email, @RequestBody PasswordChangeRequest passwordChangeRequest) {
        UsersService.editPassword(email, passwordChangeRequest.getOldPassword(), passwordChangeRequest.getNewPassword());
    }

    // Delete Methods:

    /**
     * Method for deleting a User object pertaining to the specified user.
     *
     * @param email email of the user
     * @author Chris Sterkenburg, N10478728
     */
    @DeleteMapping("/users/{email}")
    public void deleteUser(@PathVariable String email) {
        UsersService.deleteUser(email);
    }
}

package server.communication.userEndpoint;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import server.exceptions.users.illegalPasswordException;
import server.exceptions.users.nonExistentUserException;
import server.managers.UsersManager;
import server.objects.user.AccountType;
import server.objects.user.User;

import java.util.ArrayList;
import java.util.List;

import static server.database.ValidationHelpers.passwordUnhasedValid;

/**
 * Back-end Java class that calls the appropriate methods from the UsersManager class methods where requested by the client
 * with their results defined in the service layer.
 *
 * @author Nicole Slabbert, N10476130
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@Service
public final class UsersService {
    // Read Methods:

    /**
     * Method for reading all users currently stored in the database.
     *
     * @return Returns a list of users
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static List<User> readAllUsers() {
        List<User> readUsers = UsersManager.getUsersList();

        // Check if readUsers is null, otherwise return readUsers
        if (readUsers == null) return new ArrayList<>();

        return readUsers;
    }

    /**
     * Method for reading an individual user currently stored in the database.
     *
     * @param email email of the user
     * @return Returns the user
     * @author Chris Sterkenburg, N10478728
     */
    public static User readIndividualUser(String email) {
        // Return User object, null otherwise
        return UsersManager.getUserInfo(email);
    }

    // Create Methods:

    /**
     * Method for creating a new user and adding into the database.
     *
     * @param user User object used to populate the data fields for insertion into the database
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Transactional
    public static void createUser(User user) {
        UsersManager.createUser(user.getEmail(), user.getPassword(), user.getFirstName(),
                user.getLastName(), user.getAccountType(), user.getOrgName());
    }

    /**
     * Method for logging in a user with the provided details.
     *
     * @param user User object used to populate the data fields required for JWT login
     * @return Returns JWT web token
     * @author Chris Sterkenburg, N10478728
     */
    public static String loginUser(User user) {
        return UsersManager.loginUser(user.getEmail(), user.getPassword());
    }

    // Edit Methods:

    /**
     * Method for updating a user's parameters in the database.
     *
     * @param email email of the user
     * @param user  User object used to populate the data fields for insertion into the database
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static void editUser(String email, User user) {
        // Retrieve the user's current state from the database
        User retrievedUser = UsersManager.getUserInfo(email);

        // Validate that the retrievedUser exists
        if (retrievedUser == null) {
            throw new nonExistentUserException("The oldEmail parameter does not exist in the user_accounts table.");
        }

        // Define variables to hold parameters for calling of editUserInfo
        String newEmail = user.getEmail();
        String unchangedPassword = retrievedUser.getPassword();
        String newFirstName = user.getFirstName();
        String newLastName = user.getLastName();
        AccountType newAccountType = user.getAccountType();
        String newOrgName = user.getOrgName();

        // Check for and replace null values with the value stored in the database
        if (newEmail == null) newEmail = retrievedUser.getEmail();
        if (newFirstName == null) newFirstName = retrievedUser.getFirstName();
        if (newLastName == null) newLastName = retrievedUser.getLastName();
        if (newAccountType == null) newAccountType = retrievedUser.getAccountType();
        if (newOrgName == null) newOrgName = retrievedUser.getOrgName();

        UsersManager.editUserInfo(email, newEmail, unchangedPassword, newFirstName, newLastName, newAccountType, newOrgName);
    }

    /**
     * Method for updating a user's password in the database.
     *
     * @param email       email of the user
     * @param oldPassword old (unencrypted) password to be replaced
     * @param newPassword new (unencrypted) password to be inserted
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static void editPassword(String email, String oldPassword, String newPassword) {
        // Retrieve the user's current state from the database
        User retrievedUser = UsersManager.getUserInfo(email);

        // Validate that the retrievedUser exists
        if (retrievedUser == null) {
            throw new nonExistentUserException("The email parameter does not exist in the user_accounts table.");
        }

        // Validate values
        passwordUnhasedValid(oldPassword);
        passwordUnhasedValid(newPassword);

        // Encrypt oldPassword
        String oldPasswordHashed = UsersManager.hashPassword(retrievedUser.getSalt() + oldPassword);

        // Compare the oldPasswordHashed to the password in the database to check for authorisation
        if (!oldPasswordHashed.equals(retrievedUser.getPassword()))
            throw new illegalPasswordException("The oldPassword parameter does not match the expected value.");

        // Encrypt newPassword
        String newPasswordHashed = UsersManager.hashPassword(retrievedUser.getSalt() + newPassword);

        // Store newPassword in the database
        UsersManager.editUserInfo(email, email, newPasswordHashed, retrievedUser.getFirstName(), retrievedUser.getLastName(),
                retrievedUser.getAccountType(), retrievedUser.getOrgName());
    }

    // Delete Methods:

    /**
     * Method for deleting a user from the database.
     *
     * @param email email of the user
     * @author Chris Sterkenburg, N10478728
     */
    public static void deleteUser(String email) {
        UsersManager.deleteUser(email);
    }
}

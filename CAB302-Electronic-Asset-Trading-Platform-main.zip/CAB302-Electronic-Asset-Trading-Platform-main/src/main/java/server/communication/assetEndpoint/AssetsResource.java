package server.communication.assetEndpoint;

import org.springframework.web.bind.annotation.*;
import server.objects.asset.Asset;
import server.objects.asset.AssetPriceHistory;

import java.util.List;

/**
 * Back-end Java class that maps values from AssetsService to the RestController allowing access from the client.
 *
 * @author Nicole Slabbert, N10476130
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@RestController
@CrossOrigin
public final class AssetsResource {
    // Read Methods:

    /**
     * Method for getting a list of Asset objects.
     *
     * @return Returns a list of Asset objects as a JSON to the end point
     * @author Chris Sterkenburg, N10478728
     */
    @GetMapping("/assets")
    public List<Asset> readAllAssets() {
        return AssetsService.readAllAssets();
    }

    /**
     * Method for getting the information pertaining to the specified asset.
     *
     * @param assetName name of the asset
     * @return Returns an Asset object as a JSON to the end point
     * @author Chris Sterkenburg, N10478728
     */
    @GetMapping("/assets/{assetName}")
    public Asset readIndividualAsset(@PathVariable String assetName) {
        return AssetsService.readIndividualAsset(assetName);
    }

    /**
     * Method for getting the price history pertaining to the specified asset.
     *
     * @param assetName name of the asset
     * @return Returns a list containing the price history as a JSON to the end point
     * @author Chris Sterkenburg, N10478728
     */
    @GetMapping("/assets/priceHistory/{assetName}")
    public List<AssetPriceHistory> readPriceHistory(@PathVariable String assetName) {
        return AssetsService.readPriceHistory(assetName);
    }

    // Create Methods:

    /**
     * Method for posting a JSON Asset object into the database.
     *
     * @param asset JSON object containing the parameters of an Asset object
     * @author Chris Sterkenburg, N10478728
     */
    @PostMapping("/assets")
    public void createAsset(@RequestBody Asset asset) {
        AssetsService.createAsset(asset);
    }

    // Edit Methods:

    /**
     * Method for putting a JSON Asset object into the database.
     *
     * @param assetName name of the asset
     * @param asset     JSON object containing the parameters of an Asset object
     * @author Chris Sterkenburg, N10478728
     */
    @PutMapping("/assets/edit/{assetName}")
    public void editAsset(@PathVariable String assetName, @RequestBody Asset asset) {
        AssetsService.editAsset(assetName, asset);
    }

    // Delete Methods:

    /**
     * Method for deleting the information pertaining to the specified asset.
     *
     * @param assetName name of the asset
     * @author Chris Sterkenburg, N10478728
     */
    @DeleteMapping("/assets/{assetName}")
    public void deleteAsset(@PathVariable String assetName) {
        AssetsService.deleteAsset(assetName);
    }
}

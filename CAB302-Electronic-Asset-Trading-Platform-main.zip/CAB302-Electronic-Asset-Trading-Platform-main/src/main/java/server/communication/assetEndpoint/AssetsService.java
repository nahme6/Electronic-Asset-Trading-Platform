package server.communication.assetEndpoint;

import org.springframework.stereotype.Service;
import server.exceptions.assets.illegalOldAssetNameException;
import server.managers.AssetsManager;
import server.objects.asset.Asset;
import server.objects.asset.AssetPriceHistory;

import java.util.ArrayList;
import java.util.List;

/**
 * Back-end Java class that calls the appropriate methods from the AssetManager class where requested by the client
 * with their results defined in the service layer.
 *
 * @author Nicole Slabbert, N10476130
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@Service
public final class AssetsService {
    // Read Methods:

    /**
     * Method for reading all assets currently stored in the database.
     *
     * @return Returns a list of assets
     * @author Chris Sterkenburg, N10478728
     */
    public static List<Asset> readAllAssets() {
        List<Asset> readAssets = AssetsManager.getAssetsList();

        // Check if readAssets is empty, otherwise return readAssets
        if (readAssets.isEmpty()) return new ArrayList<>();

        return readAssets;
    }

    /**
     * Method for reading an individual asset currently stored in the database.
     *
     * @param assetName name of the asset
     * @return Returns the asset
     * @author Chris Sterkenburg, N10478728
     */
    public static Asset readIndividualAsset(String assetName) {
        // Return OrganisationalUnit object, null otherwise
        return AssetsManager.getAssetInfo(assetName);
    }

    /**
     * Method for reading the price history of an asset stored in the database.
     *
     * @param assetName name of the asset
     * @return Returns a list containing the price history
     */
    public static List<AssetPriceHistory> readPriceHistory(String assetName) {
        // Return OrganisationalUnit object, null otherwise
        return AssetsManager.getAssetPriceHistory(assetName);
    }

    // Create Methods:

    /**
     * Method for creating a new asset and adding it into the database.
     *
     * @param asset Asset object used to populate the data fields for insertion into the database
     * @author Chris Sterkenburg, N10478728
     */
    public static void createAsset(Asset asset) {
        AssetsManager.createAsset(asset.getAssetName(), asset.getAssetDescription());
    }

    // Edit Methods

    /**
     * Method for updating an asset's parameters in the database.
     *
     * @param assetName name of the asset
     * @param asset     Asset object used to populate the data fields for insertion into the database
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static void editAsset(String assetName, Asset asset) {
        // Retrieve the asset's current state from the database
        Asset retrievedAsset = AssetsManager.getAssetInfo(assetName);

        // Validate that the retrievedAsset exists
        if (retrievedAsset == null) {
            throw new illegalOldAssetNameException("The oldAssetName parameter does not exist in the assets table.");
        }

        // Define variables to hold parameters for calling of editAssetInfo
        String newAssetName = asset.getAssetName();
        String newAssetDescription = asset.getAssetDescription();

        // Check for and replace null values with the value stored in the database
        if (newAssetName == null) newAssetName = retrievedAsset.getAssetName();
        if (newAssetDescription == null) newAssetDescription = retrievedAsset.getAssetDescription();

        AssetsManager.editAssetInfo(assetName, newAssetName, newAssetDescription);
    }

    // Delete Methods:

    /**
     * Method for deleting an asset from the database.
     *
     * @param assetName name of the asset
     * @author Chris Sterkenburg, N10478728
     */
    public static void deleteAsset(String assetName) {
        AssetsManager.deleteAsset(assetName);
    }
}

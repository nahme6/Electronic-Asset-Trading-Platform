package server.communication.tradeEndpoint;

import org.springframework.web.bind.annotation.*;
import server.objects.trade.Trade;

import java.util.List;

/**
 * Back-end Java class that maps values from TradesService to the RestController allowing access from the client.
 *
 * @author Nicole Slabbert, N10476130
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@RestController
@CrossOrigin
public final class TradesResource {
    // Read Methods:

    /**
     * Method for getting a list of Trade objects pertaining to the specified organisational unit and resolved state.
     *
     * @param orgName    name of the organisational unit
     * @param isResolved boolean value for resolved state
     * @return Returns a list of Trade objects as a JSON to the end point
     * @author Chris Sterkenburg, N10478728
     */
    @GetMapping("/trades/tradeListings/{orgName}/{isResolved}")
    public List<Trade> readTradesByOrgName(@PathVariable String orgName, @PathVariable Boolean isResolved) {
        return TradesService.readTradesByOrgName(orgName, isResolved);
    }

    /**
     * Method for getting a list of Trade objects based on their resolved state.
     *
     * @param isResolved boolean value for resolved state
     * @return Returns a list of Trade objects as a JSON to the end point
     * @author Chris Sterkenburg, N10478728
     */
    @GetMapping("/trades/isResolved/{isResolved}")
    public List<Trade> readAllTrades(@PathVariable Boolean isResolved) {
        return TradesService.readAllTrades(isResolved);
    }

    /**
     * Method for getting a Trade Object pertaining to the specified tradeID.
     *
     * @param tradeID id of the trade
     * @return Returns the Trade object as a JSON to the end point
     * @author Chris Sterkenburg, N10478728
     */
    @GetMapping("/trades/{tradeID}")
    public Trade readIndividualTrade(@PathVariable Integer tradeID) {
        return TradesService.readIndividualTrade(tradeID);
    }

    // Create Methods:

    /**
     * Method for posting a JSON Trade object into the database.
     *
     * @param trade JSON object containing the parameters of a Trade object
     * @author Chris Sterkenburg, N10478728
     */
    @PostMapping("/trades")
    public void createTrade(@RequestBody Trade trade) {
        TradesService.createTrade(trade);
    }

    // Edit Methods:

    /**
     * Method for putting a JSON Trade object into the database.
     *
     * @param tradeID id of the trade
     * @param trade   JSON object containing Trade object parameters
     * @author Chris Sterkenburg, N10478728
     */
    @PutMapping("/trades/edit/{tradeID}")
    public void editTrade(@PathVariable Integer tradeID, @RequestBody Trade trade) {
        TradesService.editTrade(tradeID, trade);
    }

    /**
     * Method for resolving a Trade Object pertaining to the specified tradeID.
     *
     * @param orgName name of organisation buying the trade
     * @param tradeID id of the trade
     * @author Chris Sterkenburg, N10478728
     */
    @PutMapping("/trades/resolve/{orgName}/{tradeID}")
    public void resolveTrade(@PathVariable String orgName, @PathVariable Integer tradeID) {
        TradesService.resolveTrade(orgName, tradeID);
    }

    // Delete Methods:

    /**
     * Method for cancelling a Trade object pertaining to the specified tradeID.
     *
     * @param tradeID id of the trade
     * @author Chris Sterkenburg, N10478728
     */
    @DeleteMapping("/trades/{tradeID}")
    public void cancelTrade(@PathVariable Integer tradeID) {
        TradesService.cancelTrade(tradeID);
    }
}

package server.communication.tradeEndpoint;

import org.springframework.stereotype.Service;
import server.exceptions.illegalOrgNameException;
import server.exceptions.trades.nonExistentTradeException;
import server.managers.OrganisationalUnitsManager;
import server.managers.TradesManager;
import server.objects.organisation.OrganisationalUnit;
import server.objects.trade.Trade;

import java.util.ArrayList;
import java.util.List;

/**
 * Back-end Java class that calls the appropriate methods from the TradesManager class where requested by the client
 * with their results defined in the service layer.
 *
 * @author Nicole Slabbert, N10476130
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@Service
public final class TradesService {
    // Read Methods:

    /**
     * Method for reading all trades stored in the database based on resolved state and that pertain to the
     * specified organisational unit
     *
     * @param orgName    name of the organisational unit
     * @param isResolved boolean value for resolved state
     * @return Returns a list of trades
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static List<Trade> readTradesByOrgName(String orgName, Boolean isResolved) {
        // Get all trades that have not been resolved
        List<Trade> readTrades = TradesManager.getTradesList(isResolved);

        // Verify that the organisational unit exists in the database
        OrganisationalUnit retrievedOrg = OrganisationalUnitsManager.getOrgInfo(orgName);
        if (retrievedOrg == null) {
            throw new illegalOrgNameException("The orgName parameter does not exist in the organisational_units table.");
        }

        // Check if readTrades is null, if so return an empty list
        if (readTrades.isEmpty()) return new ArrayList<>();

        // readTrades is not null, so loop through each entry and keep only those where
        // the organisational unit matches org
        readTrades.removeIf(trade -> !trade.getOrgName().equals(orgName));

        return readTrades;
    }

    /**
     * Method for reading all trades currently stored in the database based on resolved state.
     *
     * @param isResolved boolean value for resolved state
     * @return Returns a list of trades
     * @author Chris Sterkenburg, N10478728
     */
    public static List<Trade> readAllTrades(Boolean isResolved) {
        List<Trade> readTrades = TradesManager.getTradesList(isResolved);

        // Check if readTrades is null, otherwise return readTrades
        if (readTrades.isEmpty()) return new ArrayList<>();

        return readTrades;
    }

    /**
     * Method for reading an individual trade currently stored in the database.
     *
     * @param tradeID id of the trade
     * @return Returns the trade matching the id
     * @author Chris Sterkenburg, N10478728
     */
    public static Trade readIndividualTrade(Integer tradeID) {
        // Return Trade object, null otherwise
        return TradesManager.getTradeInfo(tradeID);
    }

    // Create Methods:

    /**
     * Method for creating a new trade and adding into the database.
     *
     * @param trade Trade object used to populate the data fields for insertion into the database
     * @author Chris Sterkenburg, N10478728
     */
    public static int createTrade(Trade trade) {
        return TradesManager.placeTrade(trade.getAssetName(), trade.getOrderType(), trade.getCreditPricePerUnit(), trade.getQuantity(), trade.getOrgName());
    }

    // Edit Methods:

    /**
     * Method for updating an trade's parameters in the database.
     *
     * @param tradeID id of the trade
     * @param trade   Trade object used to populate the data fields for insertion into the database
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static void editTrade(Integer tradeID, Trade trade) {
        // Retrieve the trade's current state from the database
        Trade retrievedTrade = TradesManager.getTradeInfo(tradeID);

        // Validate that the retrievedTrade exists
        if (retrievedTrade == null) {
            throw new nonExistentTradeException("The tradeID parameter does not exist in the trades table.");
        }

        // Define variables to hold parameters for calling of editTradeInfo
        Integer newCreditPricePerUnit = trade.getCreditPricePerUnit();
        Integer newQuantity = trade.getQuantity();

        // Check for and replace null values with the value stored in the database
        if (newCreditPricePerUnit == null) newCreditPricePerUnit = retrievedTrade.getCreditPricePerUnit();
        if (newQuantity == null) newQuantity = retrievedTrade.getQuantity();

        TradesManager.editTradeInfo(tradeID, newCreditPricePerUnit, newQuantity);
    }

    /**
     * Method for resolving a trade and updating the database.
     *
     * @param orgName name of organisational unit buying the trade
     * @param tradeID id of the trade
     * @author Chris Sterkenburg, N10478728
     */
    public static void resolveTrade(String orgName, Integer tradeID) {
        TradesManager.resolveSingleTrade(tradeID, orgName);
    }

    // Delete Methods:

    /**
     * Method for cancelling a trade in the database.
     *
     * @param tradeID id of the trade
     * @author Chris Sterkenburg, N10478728
     */
    public static void cancelTrade(Integer tradeID) {
        TradesManager.cancelTrade(tradeID);
    }
}

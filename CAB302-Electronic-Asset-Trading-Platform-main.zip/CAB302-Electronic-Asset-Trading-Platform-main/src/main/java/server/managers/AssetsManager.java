package server.managers;

import server.database.Database;
import org.springframework.stereotype.Repository;
import server.exceptions.assets.illegalNewAssetNameException;
import server.exceptions.assets.illegalOldAssetNameException;
import server.exceptions.faultyDatabaseConnectionException;
import server.exceptions.illegalAssetNameException;
import server.objects.asset.*;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static server.database.ValidationHelpers.*;

/**
 * Serverside Java class that contains methods relating to Assets.
 *
 * @author Navid Ahmed, N10470433
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@Repository
public class AssetsManager {
    /**
     * Method for adding a new asset into the database.
     *
     * @param assetName        name of the asset to be added
     * @param assetDescription description of asset to be added
     * @author Navid Ahmed, N10470433
     * @author Chris Sterkenburg, N10478728
     */
    public static void createAsset(String assetName, String assetDescription) {
        // Checks that all parameters are valid
        assetNameValid(assetName);
        assetDescriptionValid(assetDescription);

        Asset retrievedAsset = getAssetInfo(assetName);
        if (retrievedAsset != null) {
            throw new illegalAssetNameException("The assetName parameter already exists in the assets table.");
        }

        // Parameters are all valid, so connect to the database and initialise queries for it
        Connection connection = Database.getDatabaseConnection();

        String CREATE_ASSET = "INSERT INTO assets VALUES (?, ?);";

        try {
            // Prepare a statement to execute CREATE_ASSET
            PreparedStatement createAsset = connection.prepareStatement(CREATE_ASSET);

            // Insert parameters into prepared statement
            createAsset.setString(1, assetName);
            createAsset.setString(2, assetDescription);

            // Execute the statement
            createAsset.execute();
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing createAsset's query(ies) to the database.");
        }
    }

    /**
     * Method for deleting the specified asset from the database.
     *
     * @param assetName name of asset to be removed from the database
     * @author Navid Ahmed, N10470433
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static void deleteAsset(String assetName) {
        // Checks that all parameters are valid
        assetNameValid(assetName);

        // Verify that the asset exists in the database
        Asset retrievedAsset = getAssetInfo(assetName);
        if (retrievedAsset == null) {
            throw new illegalAssetNameException("The assetName parameter does not exist in the assets table.");
        }

        // Establish connection to database
        Connection connection = Database.getDatabaseConnection();

        // Attempt to remove row
        try {
            // Ensure that no current trade contains the asset
            String GET_ASSET_NAME_FROM_TRADES = "SELECT asset_name FROM trades WHERE asset_name=?;";
            PreparedStatement checkAssetName = connection.prepareStatement(GET_ASSET_NAME_FROM_TRADES);
            checkAssetName.setString(1, assetName);
            ResultSet queryResults = checkAssetName.executeQuery();

            // Check if the result set is not null, if so, the asset is in use, so throw an illegalAssetNameException
            if (queryResults.next()) throw new illegalAssetNameException("The assetName parameter is in use.");

            // Ensure that there is not an inventory that contains the assetName
            String GET_ASSET_NAME_FROM_ASSET_INVENTORY = "SELECT asset_name FROM asset_inventory WHERE asset_name=?";
            PreparedStatement checkAssetInventory = connection.prepareStatement(GET_ASSET_NAME_FROM_ASSET_INVENTORY);
            checkAssetInventory.setString(1, assetName);
            ResultSet queryAssetInventoryResults = checkAssetInventory.executeQuery();
            // Check if the result set is not null, if so, the asset is in use, so throw an illegalAssetNameException
            if (queryAssetInventoryResults.next())
                throw new illegalAssetNameException("The assetName parameter is in inventory");

            // Prepare a statement to execute DELETE_ASSET
            String DELETE_ASSET = "DELETE FROM assets WHERE name=?;";
            PreparedStatement removeAsset = connection.prepareStatement(DELETE_ASSET);
            removeAsset.setString(1, assetName);

            removeAsset.execute();
        } catch (illegalAssetNameException e) {
            throw e;
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing deleteAsset's query(ies) to the database.");
        }
    }

    /**
     * Method for returning the specified asset from the database.
     *
     * @param assetName name of asset to be returned from the database
     * @return info of specific asset
     * @author Navid Ahmed, N10470433
     * @author Chris Sterkenburg, N10478728
     */
    public static Asset getAssetInfo(String assetName) {
        Asset tempAsset; // temp asset object

        // Checks that all parameters are valid
        assetNameValid(assetName);

        // Parameter is valid, so connect to the database and initialise queries for it
        Connection connection = Database.getDatabaseConnection();

        String GET_ASSET = "SELECT * FROM assets WHERE name=?;";

        try {
            // Prepare a statement to execute GET_ASSET
            PreparedStatement getAsset = connection.prepareStatement(GET_ASSET);

            getAsset.setString(1, assetName);

            // Query the database for results
            ResultSet queryResult = getAsset.executeQuery();

            // Check if the result set is null, if so exit method
            if (!queryResult.next()) return null;

            // Create temp variables to place extracted data into
            String tempName = queryResult.getString("name");
            String tempDescription = queryResult.getString("description");

            // Place temp variables into tempAsset's constructor
            tempAsset = new Asset(tempName, tempDescription, null);

        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing getAssetInfo's query(ies) to the database.");
        }

        // Return info of requested asset
        return tempAsset;
    }

    /**
     * Method for returning the price history of the specified asset from the database.
     *
     * @param assetName name of asset's price history to be returned from the database
     * @return asset price history
     * @author Navid Ahmed, N10470433
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static List<AssetPriceHistory> getAssetPriceHistory(String assetName) {
        List<AssetPriceHistory> tempList = new ArrayList<>();

        AssetPriceHistory returnedPriceHistory; // temp AssetPriceHistory object
        // Checks that all parameters are valid
        assetNameValid(assetName);

        // Parameter is valid, so connect to the database and initialise queries for it
        Connection connection = Database.getDatabaseConnection();

        String GET_ASSET_PRICE_HISTORY = "SELECT resolved_date, price_per_unit FROM trades WHERE asset_name=? AND is_resolved=TRUE AND type='BUY';";

        // Attempt to edit trade values
        try {
            // Prepare a statement to execute GET_ORG_INVENTORY
            PreparedStatement getOrgInventory = connection.prepareStatement(GET_ASSET_PRICE_HISTORY);

            // Populate the query
            getOrgInventory.setString(1, assetName);

            // Query the database for results
            ResultSet queryResults = getOrgInventory.executeQuery();

            if (!queryResults.next()) return null;

            // Loop through queryResults, populating orgInventory with data
            do {
                LocalDate retrievedResolvedDate = queryResults.getDate("resolved_date").toLocalDate();
                Integer retrievedPricePerUnit = queryResults.getInt("price_per_unit");

                returnedPriceHistory = new AssetPriceHistory(retrievedResolvedDate, retrievedPricePerUnit);
                tempList.add(returnedPriceHistory);

            } while (queryResults.next());

        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing getAssetPriceHistory's query(ies) to the database.");
        }

        // return results from query
        return tempList;
    }

    /**
     * Method for editing an asset within the database.
     *
     * @param oldAssetName     current primary key of the asset in the database
     * @param newAssetName     new asset name to be inserted
     * @param assetDescription new asset description to be inserted
     * @author Navid Ahmed, N10470433
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static void editAssetInfo(String oldAssetName, String newAssetName, String assetDescription) {
        // Checks that all parameters are valid
        if ((oldAssetName == null) || (oldAssetName.trim().isEmpty()) || (oldAssetName.length() > 50)) {
            throw new illegalOldAssetNameException("The oldAssetName parameter does not meet the database constraints.");
        }

        if ((newAssetName == null) || (newAssetName.trim().isEmpty()) || (newAssetName.length() > 50)) {
            throw new illegalNewAssetNameException("The newAssetName parameter does not meet the database constraints.");
        }

        assetDescriptionValid(assetDescription);

        Asset retrievedAsset = getAssetInfo(oldAssetName);
        if (retrievedAsset == null) {
            throw new illegalOldAssetNameException("The oldAssetName parameter does not exist in the assets table.");
        }

        Asset retrievedAsset2 = getAssetInfo(newAssetName);
        if (retrievedAsset2 != null && !oldAssetName.equals(newAssetName)) {
            throw new illegalNewAssetNameException("The newAssetName parameter already exists in the assets table.");
        }

        // Parameters are valid, so connect to the database and initialise queries for it
        Connection connection = Database.getDatabaseConnection();

        String UPDATE_ASSET_NAME = "UPDATE assets SET name=?, description=? WHERE name=?";

        try {
            // Prepare a statement to execute UPDATE_ASSET_NAME
            PreparedStatement updateQuery = connection.prepareStatement(UPDATE_ASSET_NAME);

            updateQuery.setString(1, newAssetName);
            updateQuery.setString(2, assetDescription);
            updateQuery.setString(3, oldAssetName);

            updateQuery.execute();
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing editAssetInfo's query(ies) to the database.");
        }
    }

    /**
     * Method for returning a list of assets currently stored in the database.
     *
     * @return all currently stored assets
     * @author Navid Ahmed, N10470433
     * @author Chris Sterkenburg, N10478728
     */
    public static List<Asset> getAssetsList() {
        List<Asset> assetList = new ArrayList<>(); // temp ArrayList

        // connect to the database and initialise queries for it
        Connection connection = Database.getDatabaseConnection();

        String GET_ASSETS = "SELECT * FROM assets";

        try {
            // Prepare a statement to execute GET_ASSETS
            PreparedStatement getAssets = connection.prepareStatement(GET_ASSETS);

            ResultSet assetsQueryResults = getAssets.executeQuery();

            // Place results from query into variables
            while (assetsQueryResults.next()) {
                String assetName = assetsQueryResults.getString("name");
                String assetDescription = assetsQueryResults.getString("description");

                // Create asset object initialised with results from query
                Asset retrievedAsset = new Asset(assetName, assetDescription, null);

                // Add to list
                assetList.add(retrievedAsset);
            }
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing getAssetsList's query(ies) to the database.");
        }

        return assetList;
    }
}

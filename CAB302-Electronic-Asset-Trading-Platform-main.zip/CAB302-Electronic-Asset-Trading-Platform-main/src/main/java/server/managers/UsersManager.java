package server.managers;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import server.database.Database;
import server.exceptions.faultyDatabaseConnectionException;
import server.exceptions.illegalOrgNameException;
import server.exceptions.users.*;
import server.objects.organisation.OrganisationalUnit;
import server.objects.user.AccountType;
import server.objects.user.User;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static server.database.ValidationHelpers.*;

/**
 * Serverside Java class that contains methods relating to users.
 *
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 * @author Nicole Slabbert, N10476130
 */
public class UsersManager {
    private static final String SECRET = "SECRET_KEY";
    private static final long EXPIRATION_TIME = 900_000; // 15 mins
    static String defaultEmail = "itadministration@genericdomain.com";

    /**
     * Method for adding a new user into the database.
     *
     * @param email               email to be inserted
     * @param password            (unencrypted) password to be inserted
     * @param firstName           first name to be inserted
     * @param lastName            last name to be inserted
     * @param employeeAccountType account type to be inserted
     * @param orgName             organisational name to be inserted
     * @author Daniel Taylor, N10492623
     */
    public static void createUser(String email, String password, String firstName, String lastName,
                                  AccountType employeeAccountType, String orgName) {
        // Checks that all method parameters are valid before creating SQL query
        emailValid(email);
        passwordUnhasedValid(password);
        // Note to self: One of the first places I want to start when I clean stuff up
        firstNameValid(firstName);
        lastNameValid(lastName);
        accountTypeValid(employeeAccountType);
        orgNameValid(orgName);

        // Check uniqueness of the email parameter
        User retrievedUser = getUserInfo(email);
        if (retrievedUser != null) {
            throw new illegalEmailException("The email parameter already exists in the user_accounts table.");
        }

        // Parameters are all valid, so connect to the database and initialise a query for it
        Connection connection = Database.getDatabaseConnection();

        // Check that orgName exists
        OrganisationalUnit retrievedOrg = OrganisationalUnitsManager.getOrgInfo(orgName);
        if (retrievedOrg == null) {
            throw new illegalOrgNameException("The orgName parameter does not exist in the organisational_units table.");
        }

        String INSERT_USER = "INSERT INTO user_accounts VALUES (?, ?, ?, ?, ?, ?, ?);";

        // Generate a nine digit integer salt to protect the user's password.
        SecureRandom saltGenerator = new SecureRandom();
        String salt = Integer.toString(saltGenerator.nextInt(999999999 - 100000000) + 100000000);

        // Append the user's password to the salt
        String toBeHashed = salt + password;

        // Hash the user's password
        String hashedPassword = hashPassword(toBeHashed);

        try {
            // Insert parameters into prepared statement
            PreparedStatement insertUser = connection.prepareStatement(INSERT_USER);

            insertUser.setString(1, email);
            insertUser.setString(2, hashedPassword);
            insertUser.setString(3, salt);
            insertUser.setString(4, firstName);
            insertUser.setString(5, lastName);
            insertUser.setString(6, employeeAccountType.name());
            insertUser.setString(7, orgName);

            // Add new user to the database
            insertUser.execute();

        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing createUser's query(ies) to the database.");
        }
    }

    /**
     * Method for deleting the specified user from the database.
     *
     * @param email email of specific user
     * @author Chris Sterkenburg, N10478728
     */
    public static void deleteUser(String email) {
        // Check that email is valid
        emailValid(email);

        if (email.equals(defaultEmail)) {
            throw new illegalEmailException("The email parameter is the default user.");
        }

        // Parameter is valid, so connect to the database and initialise queries for it
        Connection connection = Database.getDatabaseConnection();

        try {
            // Attempt to delete user from the database now that all checks have passed
            String query = "DELETE FROM user_accounts WHERE email=?;";
            PreparedStatement removeUser = connection.prepareStatement(query);
            removeUser.setString(1, email);

            removeUser.execute();

        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing deleteUser's query(ies) to the database.");
        }
    }

    /**
     * Method for returning the specified user from the database.
     *
     * @param email email of specific user
     * @return Returns the requested user info
     * @author Chris Sterkenburg, N10478728
     */
    public static User getUserInfo(String email) {
        User tempUser; // temp user object for returning
        // Check that email is valid
        emailValid(email);

        // Parameter is valid, so connect to the database and initialise queries for it
        Connection connection = Database.getDatabaseConnection();

        // Statement for query
        String GET_ACCOUNT = "SELECT * FROM user_accounts WHERE email=?;";

        try {

            // Prepare a statement to execute GET_TRADE
            PreparedStatement getUser = connection.prepareStatement(GET_ACCOUNT);

            getUser.setString(1, email);

            // Query the database for results
            ResultSet queryResults = getUser.executeQuery();

            // Check if the result set is null, if so exit method
            if (!queryResults.next()) return null;

            // Create temp variables to place extracted data into
            String tempEmail = queryResults.getString("email");
            String tempPassword = queryResults.getString("password");
            String tempSalt = queryResults.getString("salt");
            String tempFirstName = queryResults.getString("first_name");
            String tempLastName = queryResults.getString("last_name");
            AccountType tempEmployeeAccountType = AccountType.valueOf(queryResults.getString("account_type"));
            String tempOrgName = queryResults.getString("organisation");

            // Place temp variables into tempUser's constructor
            tempUser = new User(tempEmail, tempPassword, tempSalt, tempFirstName, tempLastName, tempEmployeeAccountType, tempOrgName);

        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing getUserInfo's query(ies) to the database.");
        }

        // return request user
        return tempUser;
    }

    /**
     * Method for editing the specified user's info stored in the database.
     *
     * @param oldEmail            current primary key of the user in the database
     * @param newEmail            new email to be inserted
     * @param password            new (encrypted) password to be inserted
     * @param firstName           new first name to be inserted
     * @param lastName            new last name to be inserted
     * @param employeeAccountType mew account type to be inserted
     * @param orgName             mew organisational name to be inserted
     * @author Daniel Taylor, N10492623
     */
    public static void editUserInfo(String oldEmail, String newEmail, String password, String firstName, String lastName,
                                    AccountType employeeAccountType, String orgName) {
        // Checks that all method parameters are valid before creating SQL query
        emailValid(oldEmail);
        emailValid(newEmail);
        passwordValid(password);
        firstNameValid(firstName);
        lastNameValid(lastName);
        accountTypeValid(employeeAccountType);
        orgNameValid(orgName);

        // Check uniqueness of the newEmail parameter
        User checkNewEmail = getUserInfo(newEmail);
        if (checkNewEmail != null && !checkNewEmail.getEmail().equals(oldEmail)) {
            throw new illegalEmailException("The newEmail parameter already exists in the user_accounts table.");
        }

        if (oldEmail.equals(defaultEmail)) {
            throw new illegalEmailException("The oldEmail parameter is the default user.");
        }

        // Check that the oldEmail exists first
        User checkOldEmail = getUserInfo(oldEmail);
        if (checkOldEmail == null) {
            throw new nonExistentUserException("The oldEmail parameter does not exist in the user_accounts table.");
        }

        // Check that orgName exists
        OrganisationalUnit retrievedOrg = OrganisationalUnitsManager.getOrgInfo(orgName);
        if (retrievedOrg == null) {
            throw new illegalOrgNameException("The orgName parameter does not exist in the organisational_units table.");
        }

        // Parameters are all valid, so connect to the database and initialise a query for it
        Connection connection = Database.getDatabaseConnection();

        String CHECK_NEW_ORG = "SELECT organisation FROM organisational_units WHERE organisation=?";

        try {
            PreparedStatement checkOrg = connection.prepareStatement(CHECK_NEW_ORG);

            checkOrg.setString(1, orgName);

            ResultSet resultSet = checkOrg.executeQuery();

            if (!resultSet.next()) {
                throw new illegalOrgNameException("Org name does not exist");
            }
        } catch (Exception e) {
            throw new faultyDatabaseConnectionException("Something went wrong processing editUserInfo's query(ies) to the database: " + e);
        }

        String UPDATE_USER = "UPDATE user_accounts SET email=?, password=?, first_name=?, last_name=?, account_type=?, organisation=? WHERE email=?;";

        try {
            // Insert parameters into prepared statement
            PreparedStatement updateUser = connection.prepareStatement(UPDATE_USER);

            updateUser.setString(1, newEmail);
            updateUser.setString(2, password);
            updateUser.setString(3, firstName);
            updateUser.setString(4, lastName);
            updateUser.setString(5, employeeAccountType.name());
            updateUser.setString(6, orgName);
            updateUser.setString(7, oldEmail);

            // Edit the user to the database
            updateUser.execute();

        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing editUserInfo's query(ies) to the database.");
        }
    }

    /**
     * Method for returning a list of users currently stored in the database.
     *
     * @return Returns all currently stored users
     * @author Chris Sterkenburg, N10478728
     */
    public static List<User> getUsersList() {
        List<User> tempList = new ArrayList<>();

        // Connect to the database and initialise queries for it
        Connection connection = Database.getDatabaseConnection();

        // Statement for query
        String GET_USERS = "SELECT * FROM user_accounts;";

        try {
            // Prepare a statement to execute GET_USERS
            PreparedStatement getUsers = connection.prepareStatement(GET_USERS);

            // Query the database for results
            ResultSet queryResults = getUsers.executeQuery();

            // Check that the result set is null
            if (queryResults == null) {
                return null;
            }

            // Process each element from the ResultSet into temp values, construct users and place into tempList
            while (queryResults.next()) {
                String tempEmail = queryResults.getString("email");
                String tempPassword = queryResults.getString("password");
                String tempSalt = queryResults.getString("salt");
                String tempFirstName = queryResults.getString("first_name");
                String tempLastName = queryResults.getString("last_name");
                AccountType tempEmployeeAccountType = AccountType.valueOf(queryResults.getString("account_type"));
                String tempOrgName = queryResults.getString("organisation");

                // Place temp variables into tempUser's constructor
                User tempUser = new User(tempEmail, tempPassword, tempSalt, tempFirstName, tempLastName, tempEmployeeAccountType, tempOrgName);

                tempList.add(tempUser);
            }

        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing getUsersList's query(ies) to the database.");
        }

        // Return all users
        return tempList;
    }

    /**
     * Method for encrypting a password before storage in the database.
     *
     * @param unhashedPassword string that needs to be hashed for security
     * @return Returns an encrypted hexadecimal string
     * @author Daniel Taylor, N10492623
     * @author <a href="https://www.baeldung.com/author/baeldung/">baeldung</a>
     * @see <a href="https://www.baeldung.com/sha-256-hashing-java">Source</a>
     */
    public static String hashPassword(String unhashedPassword) {
        if ((unhashedPassword == null) || (unhashedPassword.trim().isEmpty())) {
            throw new illegalPasswordException("The unhashedPassword parameter is null or empty.");
        }

        // Initialise a converter to turn the password into a hashed byte array
        byte[] hashedPassword;
        try {
            MessageDigest converter = MessageDigest.getInstance("SHA-256");
            hashedPassword = converter.digest(unhashedPassword.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyHashingException
            throw new faultyHashingException("Something went wrong hashing the password.");
        }

        // Convert the hashed byte array to a hexadecimal string
        StringBuilder hashedPasswordHex = new StringBuilder(2 * hashedPassword.length);
        // Loop through each byte in hashedPassword, convert it to a hex string, and append it to the string
        for (byte b : hashedPassword) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hashedPasswordHex.append('0');
            }
            hashedPasswordHex.append(hex);
        }
        return hashedPasswordHex.toString();
    }

    /**
     * Method for logging into a user account.
     *
     * @param email    email address associated with the account being logged into
     * @param password (unencrypted) password that should be used to log in
     * @return Returns a JWT token as a string
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static String loginUser(String email, String password) {
        // Checks that all method parameters are valid before creating SQL query
        emailValid(email);
        passwordUnhasedValid(password);

        // Determine if the user exists
        User userBeingLoggedInto = getUserInfo(email);
        if (userBeingLoggedInto == null)
            throw new illegalEmailException("The email parameter does not exist in the user_accounts table.");

        // The user exists, so hash the password parameter
        String toBeHashed = userBeingLoggedInto.getSalt() + password;
        String hashedPassword = hashPassword(toBeHashed);

        // Compare hashedPassword to the encrypted password of the account stored in the database
        if (hashedPassword.equals(userBeingLoggedInto.getPassword())) {
            // The passwords match, so return a JWT token
            SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;

            byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(SECRET);
            Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());

            JwtBuilder jwtTokenBuilder = Jwts.builder().setId(UUID.randomUUID().toString())
                    .setIssuedAt(Date.valueOf(LocalDate.now()))
                    .setSubject(userBeingLoggedInto.getEmail())
                    .setIssuer("eatp")
                    .signWith(signatureAlgorithm, signingKey);

            long expireMs = Date.valueOf(LocalDate.now()).getTime() + EXPIRATION_TIME;
            Date expireDate = new Date(expireMs);
            jwtTokenBuilder.setExpiration(expireDate);

            return jwtTokenBuilder.compact();
        } else {
            // The passwords to not match, so throw an illegalPasswordException
            throw new illegalPasswordException("The password parameter does not match the expected value.");
        }
    }
}

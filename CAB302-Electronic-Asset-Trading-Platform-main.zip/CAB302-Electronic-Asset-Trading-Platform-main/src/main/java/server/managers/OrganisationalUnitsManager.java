package server.managers;

import server.database.Database;
import org.springframework.stereotype.Repository;
import server.exceptions.faultyDatabaseConnectionException;
import server.exceptions.illegalAssetNameException;
import server.exceptions.illegalOrgNameException;
import server.exceptions.organisationalUnit.illegalNewOrgNameException;
import server.exceptions.organisationalUnit.illegalOldOrgNameException;
import server.objects.asset.Asset;
import server.objects.organisation.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static server.database.ValidationHelpers.*;

/**
 * Serverside Java class that contains methods relating to organisational units.
 * @author Daniel Taylor, N10492623
 * @author Chris Sterkenburg, N10478728
 */
@Repository
public class OrganisationalUnitsManager {
    static String defaultOrg = "IT Administration";

    /**
     * Method for inserting an organisational unit into the database.
     *
     * @param orgName name of the organisation
     * @param creditBalance starting amount of credits that the organisation should have
     * @author Chris Sterkenburg, N10478728
     */
    public static void createOrg(String orgName, Integer creditBalance) {
        // Check parameters are valid
        orgNameValid(orgName);
        creditBalanceValid(creditBalance);

        // Check uniqueness
        OrganisationalUnit tempOrg = getOrgInfo(orgName);
        if (tempOrg != null) {
            throw new illegalOrgNameException("The orgName parameter already exists in the organisational_units table.");
        }

        // Parameters are valid, establish connection to database
        Connection connection = Database.getDatabaseConnection();

        String CREATE_ORG = "INSERT INTO organisational_units VALUES (?,?);";

        try {
            // Insert parameters into prepared statement
            PreparedStatement createOrg = connection.prepareStatement(CREATE_ORG);

            createOrg.setString(1, orgName);
            createOrg.setInt(2, creditBalance);

            // Add new organisation unit to the database
            createOrg.execute();

        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing createOrg's query(ies) to the database.");
        }
    }

    /**
     * Method for removing the specified organisational unit from the database.
     *
     * @param orgName name of the organisation
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static void deleteOrg(String orgName) {
        // Check orgName is valid
        orgNameValid(orgName);

        // Check that orgName is not a protected value
        if (orgName.equals(defaultOrg)) {
            throw new illegalOrgNameException("The orgName parameter is the default organisational unit.");
        }

        // Check that orgName exists
        OrganisationalUnit retrievedOrg = getOrgInfo(orgName);
        if (retrievedOrg == null) {
            throw new illegalOrgNameException("The orgName parameter does not exist in the organisational_units table.");
        }

        // orgName is valid, so connect to the database and initialise queries for it
        Connection connection = Database.getDatabaseConnection();

        try {
            // Ensure that no trade contains the organisational unit
            String GET_ORG_NAME_FROM_TRADES = "SELECT organisation FROM trades WHERE organisation=?;";
            PreparedStatement checkOrgNameTrades = connection.prepareStatement(GET_ORG_NAME_FROM_TRADES);
            checkOrgNameTrades.setString(1, orgName);
            ResultSet queryResultsTrades =  checkOrgNameTrades.executeQuery();

            // Check if the result set is not null, if so, the organisational unit is in use, so throw an illegalOrgNameException
            if (queryResultsTrades.next()) throw new illegalOrgNameException("The orgName parameter has trades.");

            // Ensure that no user is in the organisational unit
            String GET_ORG_NAME_FROM_USERS = "SELECT organisation FROM user_accounts WHERE organisation=?;";
            PreparedStatement checkOrgNameUsers = connection.prepareStatement(GET_ORG_NAME_FROM_USERS);
            checkOrgNameUsers.setString(1, orgName);
            ResultSet queryResultsUsers =  checkOrgNameUsers.executeQuery();

            // Check if the result set is not null, if so, the organisational unit is in use, so throw an illegalOrgNameException
            if (queryResultsUsers.next()) throw new illegalOrgNameException("The orgName parameter has users");

            // Check if the organisational unit has inventory assigned to it
            String GET_ORG_NAME_FROM_ASSET_INVENTORY = "SELECT organisation FROM asset_inventory WHERE organisation=?";
            PreparedStatement checkAssetInventory = connection.prepareStatement(GET_ORG_NAME_FROM_ASSET_INVENTORY);
            checkAssetInventory.setString(1, orgName);
            ResultSet queryAssetInventoryResults = checkAssetInventory.executeQuery();

            // Check if the result set is not null, if so, the asset is in use, so throw an illegalOrgNameException
            if (queryAssetInventoryResults.next()) throw new illegalOrgNameException("The orgName parameter has inventory.");
        } catch (illegalOrgNameException e) {
            throw e;
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing deleteOrg's query(ies) to the database.");
        }

        // Attempt to remove row
        try {
            String query = "DELETE FROM organisational_units WHERE organisation=?;";
            PreparedStatement removeOrg = connection.prepareStatement(query);
            removeOrg.setString(1, orgName);

            // Remove the organisational unit from the database
            removeOrg.execute();
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing deleteOrg's query(ies) to the database.");
        }
    }

    /**
     * Method for getting the specified organisational unit from the database.
     *
     * @param orgName name of the organisational unit
     * @return Returns the requested organisational unit's info
     * @author Daniel Taylor, N10492623
     */
    public static OrganisationalUnit getOrgInfo(String orgName) {
        // Initialise an OrganisationalUnit object to hold the result
        OrganisationalUnit resultOrg;

        // Check orgName is valid
        orgNameValid(orgName);

        // orgName is valid, so connect to the database and initialise queries for it
        Connection connection = Database.getDatabaseConnection();

        String GET_ORG_INVENTORY = "SELECT asset_name, quantity FROM asset_inventory WHERE organisation=?;";

        String GET_ORG = "SELECT * FROM organisational_units WHERE organisation=?;";

        // Define an empty HashMap to hold the organisation's inventory
        HashMap<String, Integer> orgInventory = new HashMap<>();

        try {
            // Prepare a statement to execute GET_ORG_INVENTORY
            PreparedStatement getOrgInventory = connection.prepareStatement(GET_ORG_INVENTORY);

            // Populate the query
            getOrgInventory.setString(1, orgName);

            // Query the database for results
            ResultSet queryResults = getOrgInventory.executeQuery();

            // Check if the result set is null
            if (queryResults.next()) {
                // Loop through queryResults, populating orgInventory with data
                do {
                    String retrievedAssetName = queryResults.getString("asset_name");
                    Integer retrievedQuantity = queryResults.getInt("quantity");

                    orgInventory.put(retrievedAssetName, retrievedQuantity);
                } while (queryResults.next());
            }
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing getOrgInfo's query(ies) to the database.");
        }

        try {
            // Prepare a statement to execute GET_ORG
            PreparedStatement getOrg = connection.prepareStatement(GET_ORG);

            // Populate the query
            getOrg.setString(1, orgName);

            // Query the database for results
            ResultSet queryResults = getOrg.executeQuery();

            // Check if the result set is null, if so exit method
            if (!queryResults.next()) return null;

            // Extract the data from the ResultSet
            String retrievedOrgName = queryResults.getString("organisation");
            int retrievedCredits = queryResults.getInt("credits");

            // Construct an organisational unit from the retrieved data
            resultOrg = new OrganisationalUnit(retrievedOrgName, retrievedCredits, orgInventory);

        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing getOrgInfo's query(ies) to the database.");
        }

        // Return info of requested trade
        return resultOrg;
    }

    /**
     * Method for editing the specified organisational unit's info.
     *
     * @param oldOrgName current primary key of the organisational unit in the database
     * @param newOrgName new orgName to be inserted
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static void editOrgName(String oldOrgName, String newOrgName){
        // Check parameters are valid
        if ((oldOrgName == null) || (oldOrgName.trim().isEmpty()) || (oldOrgName.length() > 50)) {
            throw new illegalOldOrgNameException("The oldOrgName parameter does not meet the database constraints.");
        }

        if ((newOrgName == null) || (newOrgName.trim().isEmpty()) || (newOrgName.length() > 50)) {
            throw new illegalNewOrgNameException("The newOrgName parameter does not meet the database constraints.");
        }

        // Check that the oldOrgName exists in the database
        OrganisationalUnit retrievedOrg = getOrgInfo(oldOrgName);
        if (retrievedOrg == null) {
            throw new illegalOldOrgNameException("The oldOrgName parameter does not exist in the organisational_unit table.");
        }

        // Check uniqueness
        OrganisationalUnit tempOrg = getOrgInfo(newOrgName);
        if (tempOrg != null && !oldOrgName.equals(newOrgName)) {
            throw new illegalNewOrgNameException("The newOrgName parameter already exists in the organisational_unit table.");
        }

        // Check that the oldOrgName is not a protected value
        if (oldOrgName.equals(defaultOrg) && !oldOrgName.equals(newOrgName)) {
            throw new illegalOrgNameException("The oldOrgName parameter is the default organisational unit.");
        }

        // parameters are valid, so connect to the database and initialise a query
        Connection connection = Database.getDatabaseConnection();

        String UPDATE_ORGNAME = "UPDATE organisational_units SET organisation=? WHERE organisation=?;";

        try{
            // Insert parameters into prepared statement
            PreparedStatement updateQuery = connection.prepareStatement(UPDATE_ORGNAME);

            updateQuery.setString(1, newOrgName);
            updateQuery.setString(2, oldOrgName);

            // Update organisation name in database
            updateQuery.execute();

        } catch (Exception e){
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing editOrgName's query(ies) to the database.");
        }
    }

    /**
     * Method for setting the specified organisational unit's balance.
     *
     * @param orgName name of the organisational unit
     * @param credits amount of credits the organisation should have
     * @author Daniel Taylor, N10492623
     */
    public static void setCredits(String orgName, Integer credits) {
        // Check parameters are valid
        orgNameValid(orgName);
        creditBalanceValid(credits);

        // Verify that the organisational unit exists in the database
        OrganisationalUnit retrievedOrg = getOrgInfo(orgName);
        if (retrievedOrg == null) {
            throw new illegalOrgNameException("The orgName parameter does not exist in the organisational_units table.");
        }

        // Checks if setting of credits would put org into debt
        checkSetWouldCauseCreditDebt(orgName, credits);

        // orgName is valid, so connect to the database and initialise a query
        Connection connection = Database.getDatabaseConnection();

        String UPDATE_CREDIT_BALANCE = "UPDATE organisational_units SET credits=? WHERE organisation=?;";

        try {
            // Prepare a statement to execute UPDATE_CREDIT_BALANCE
            PreparedStatement updateCreditBalance = connection.prepareStatement(UPDATE_CREDIT_BALANCE);

            // Populate the query
            updateCreditBalance.setInt(1, credits);
            updateCreditBalance.setString(2, orgName);

            // Execute the query
            updateCreditBalance.execute();
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing setCredits's query(ies) to the database.");
        }
    }

    /**
     * Method for adding credits to the specified organisational unit's balance
     *
     * @param orgName name of the organisational unit
     * @param creditsToAdd amount of credits to add to the balance
     * @author Daniel Taylor, N10492623
     */
    public static void addCredits(String orgName, Integer creditsToAdd) {
        // Check parameters are valid
        orgNameValid(orgName);
        creditsValid(creditsToAdd);

        // Verify that the organisational unit exists in the database
        OrganisationalUnit retrievedOrg = getOrgInfo(orgName);
        if (retrievedOrg == null) {
            throw new illegalOrgNameException("The orgName parameter does not exist in the organisational_units table.");
        }

        // orgName is valid, so connect to the database and initialise a query
        Connection connection = Database.getDatabaseConnection();

        String UPDATE_CREDIT_BALANCE = "UPDATE organisational_units SET credits=? WHERE organisation=?;";

        // Calculate how many credits the organisational unit should now have
        int newCreditsValue = retrievedOrg.getCreditBalance() + creditsToAdd;

        try {
            // Prepare a statement to execute UPDATE_CREDIT_BALANCE
            PreparedStatement updateCreditBalance = connection.prepareStatement(UPDATE_CREDIT_BALANCE);

            // Populate the query
            updateCreditBalance.setInt(1, newCreditsValue);
            updateCreditBalance.setString(2, orgName);

            // Execute the query
            updateCreditBalance.execute();
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing addCredits's query(ies) to the database.");
        }
    }

    /**
     * Method for removing credits from the specified organisational unit's balance.
     *
     * @param orgName name of the organisational unit
     * @param creditsToRemove amount of credits to remove from the balance
     * @author Daniel Taylor, N10492623
     */
    public static void removeCredits(String orgName, Integer creditsToRemove) {
        // Check parameters are valid
        orgNameValid(orgName);
        creditsValid(creditsToRemove);

        // Verify that the organisational unit exists in the database
        OrganisationalUnit retrievedOrg = getOrgInfo(orgName);
        if (retrievedOrg == null) {
            throw new illegalOrgNameException("The orgName parameter does not exist in the organisational_units table.");
        }

        // Checks if removal of credits would put org into debt
        checkCreateWouldCauseCreditDebt(orgName, creditsToRemove, 1);

        // orgName is valid, so connect to the database and initialise a query
        Connection connection = Database.getDatabaseConnection();

        String UPDATE_CREDIT_BALANCE = "UPDATE organisational_units SET credits=? WHERE organisation=?;";

        // Calculate how many credits the organisational unit should now have
        int newCreditsValue = retrievedOrg.getCreditBalance() - creditsToRemove;

        try {
            // Prepare a statement to execute UPDATE_CREDIT_BALANCE
            PreparedStatement updateCreditBalance = connection.prepareStatement(UPDATE_CREDIT_BALANCE);

            // Populate the query
            updateCreditBalance.setInt(1, newCreditsValue);
            updateCreditBalance.setString(2, orgName);

            // Execute the query
            updateCreditBalance.execute();
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing removeCredits's query(ies) to the database.");
        }
    }

    /**
     * Method for setting the specified organisational unit's inventory.
     *
     * @param orgName name of the organisational unit
     * @param orgInventory hashmap holding key, value pairs for each asset and its quantity owned
     * @author Daniel Taylor, N10492623
     */
    public static void setInventory(String orgName, HashMap<String, Integer> orgInventory) {
        // Check parameters are valid
        orgNameValid(orgName);

        // Verify that the organisational unit exists in the database
        OrganisationalUnit retrievedOrg = getOrgInfo(orgName);
        if (retrievedOrg == null) {
            throw new illegalOrgNameException("The orgName parameter does not exist in the organisational_units table.");
        }

        if (orgInventory != null) {
            for (Map.Entry<String, Integer> item : orgInventory.entrySet()) {
                assetNameValid(item.getKey());
                quantityValid(item.getValue());

                // Verify that the asset exists in the database
                Asset retrievedAsset = AssetsManager.getAssetInfo(item.getKey());
                if (retrievedAsset == null) {
                    throw new illegalAssetNameException("The assetName parameter does not exist in the assets table.");
                }

                // Check if the setting of the asset would put the organisation at risk of falling into debt
                checkSetWouldCauseInventoryDebt(orgName, item.getKey(), item.getValue());
            }
        }

        // orgName is valid, so connect to the database and determine what type of query needs to be run
        Connection connection = Database.getDatabaseConnection();

        // Clear the database of assets owned by the organisational unit
        String CLEAR_INVENTORY = "DELETE FROM asset_inventory WHERE organisation=?;";

        try {
            // Prepare a statement to execute CLEAR_INVENTORY
            PreparedStatement clearInventory = connection.prepareStatement(CLEAR_INVENTORY);

            // Populate the query
            clearInventory.setString(1, orgName);

            // Execute the query
            clearInventory.execute();
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing setInventory's query(ies) to the database.");
        }

        // Exit the method early if orgInventory is empty
        if (orgInventory == null || orgInventory.isEmpty()) return;

        // The asset has never been owned by the organisational unit, so add it as a new row in the inventory
        String UPDATE_INVENTORY = "INSERT INTO asset_inventory VALUES (?, ?, ?);";

        try {
            // Prepare a statement to execute UPDATE_INVENTORY
            PreparedStatement updateInventory = connection.prepareStatement(UPDATE_INVENTORY);

            // Add each key value pair of the inventory hashmap back to the database
            for (String key : orgInventory.keySet()) {
                // Populate the query
                updateInventory.setString(1, orgName);
                updateInventory.setString(2, key);

                updateInventory.setInt(3, orgInventory.get(key));

                // Execute the query
                updateInventory.execute();
            }
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing setInventory's query(ies) to the database.");
        }
    }

    /**
     * Method for adding a quantity of an asset to the specified organisational unit's inventory.
     *
     * @param orgName name of the organisational unit
     * @param assetName name of the asset to add
     * @param quantity number of the asset to add
     * @author Daniel Taylor, N10492623
     */
    public static void addToInventory(String orgName, String assetName, Integer quantity) {
        // Check parameters are valid
        orgNameValid(orgName);
        assetNameValid(assetName);
        quantityValid(quantity);

        // Verify that the organisational unit exists in the database
        OrganisationalUnit retrievedOrg = getOrgInfo(orgName);
        if (retrievedOrg == null) {
            throw new illegalOrgNameException("The orgName parameter does not exist in the organisational_units table.");
        }

        // Verify that the asset exists in the database
        Asset retrievedAsset = AssetsManager.getAssetInfo(assetName);
        if (retrievedAsset == null) {
            throw new illegalAssetNameException("The assetName parameter does not exist in the assets table.");
        }

        // orgName is valid, so connect to the database and determine what type of query needs to be run
        Connection connection = Database.getDatabaseConnection();

        if (retrievedOrg.getInventory().containsKey(assetName)) {
            // The asset already exists in the organisational unit's inventory, so change its quantity
            String UPDATE_INVENTORY = "UPDATE asset_inventory SET quantity=? WHERE organisation=? AND asset_name=?;";

            // Calculate how many of the asset the organisational unit should now have
            int newQuantity = retrievedOrg.getInventory().get(assetName) + quantity;

            try {
                // Prepare a statement to execute UPDATE_INVENTORY
                PreparedStatement updateInventory = connection.prepareStatement(UPDATE_INVENTORY);

                // Populate the query
                updateInventory.setInt(1, newQuantity);
                updateInventory.setString(2, orgName);
                updateInventory.setString(3, assetName);

                // Execute the query
                updateInventory.execute();
            } catch (Exception e) {
                // Something has gone wrong, so throw a faultyDatabaseConnectionException
                throw new faultyDatabaseConnectionException("Something went wrong processing addToInventory's query(ies) to the database.");
            }
        } else {
            // The asset has never been owned by the organisational unit, so add it as a new row in the inventory
            String UPDATE_INVENTORY = "INSERT INTO asset_inventory VALUES (?, ?, ?);";

            try {
                // Prepare a statement to execute UPDATE_INVENTORY
                PreparedStatement updateInventory = connection.prepareStatement(UPDATE_INVENTORY);

                // Populate the query
                updateInventory.setString(1, orgName);
                updateInventory.setString(2, assetName);
                updateInventory.setInt(3, quantity);

                // Execute the query
                updateInventory.execute();
            } catch (Exception e) {
                // Something has gone wrong, so throw a faultyDatabaseConnectionException
                throw new faultyDatabaseConnectionException("Something went wrong processing addToInventory's query(ies) to the database.");
            }
        }
    }

    /**
     * Method for removing a quantity of an asset from the specified organisational unit's inventory.
     *
     * @param orgName name of the organisational unit
     * @param assetName name of the asset to remove
     * @param quantity number of the asset to remove
     * @author Daniel Taylor, N10492623
     */
    public static void removeFromInventory(String orgName, String assetName, Integer quantity) {
        // Check parameters are valid
        orgNameValid(orgName);
        assetNameValid(assetName);
        quantityValid(quantity);

        // Verify that the organisational unit exists in the database
        OrganisationalUnit retrievedOrg = getOrgInfo(orgName);
        if (retrievedOrg == null) {
            throw new illegalOrgNameException("The orgName parameter does not exist in the organisational_units table.");
        }

        // Check if the removal of assets would put the organisation at risk of falling into debt
        checkCreateWouldCauseInventoryDebt(orgName, assetName, quantity);

        // Parameters are valid, so connect to the database and determine what type of query needs to be run
        Connection connection = Database.getDatabaseConnection();


        if (retrievedOrg.getInventory().containsKey(assetName)) {
            // The asset already exists in the organisational unit's inventory, so change its quantity
            String UPDATE_INVENTORY = "UPDATE asset_inventory SET quantity=? WHERE organisation=? AND asset_name=?;";

            // Calculate how many of the asset the organisational unit should now have
            int newQuantity = retrievedOrg.getInventory().get(assetName) - quantity;

            try {
                if (newQuantity == 0) {
                    String DELETE_FROM_INVENTORY = "DELETE FROM asset_inventory WHERE organisation=? AND asset_name=?;";

                    // Prepare a statement to execute DELETE_FROM_INVENTORY
                    PreparedStatement deleteFromInventory = connection.prepareStatement(DELETE_FROM_INVENTORY);

                    // Populate the query
                    deleteFromInventory.setString(1, orgName);
                    deleteFromInventory.setString(2, assetName);

                    deleteFromInventory.execute();
                }
                else {
                    // Prepare a statement to execute UPDATE_INVENTORY
                    PreparedStatement updateInventory = connection.prepareStatement(UPDATE_INVENTORY);

                    // Populate the query
                    updateInventory.setInt(1, newQuantity);
                    updateInventory.setString(2, orgName);
                    updateInventory.setString(3, assetName);

                    // Execute the query
                    updateInventory.execute();
                }
            } catch (Exception e) {
                // Something has gone wrong, so throw a faultyDatabaseConnectionException
                throw new faultyDatabaseConnectionException("Something went wrong processing removeFromInventory's query(ies) to the database.");
            }
        }
        // The asset does not exist in the inventory to remove, so let the method end
    }

    /**
     * Method for returning all organisational units in the database.
     *
     * @return list of all organisational units
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static List<OrganisationalUnit> getOrgsList() {
        List<OrganisationalUnit> resultsList = new ArrayList<>();

        // connect to the database and initialise queries for it
        Connection connection = Database.getDatabaseConnection();

        String GET_ORGS_INVENTORY = "SELECT asset_name, quantity FROM asset_inventory where organisation=?;";

        String GET_ORGS = "SELECT * FROM organisational_units;";

        try {
            // Prepare a statement to execute GET_ORGS
            PreparedStatement getOrgs = connection.prepareStatement(GET_ORGS);

            // Query the database for results
            ResultSet orgsQueryResults = getOrgs.executeQuery();

            // Loop through the ResultSet, creating an Organisational Unit and appending it to resultsList for
            // each row.
            while (orgsQueryResults.next()) {
                // Extract the data from the ResultSet into temp variables
                String retrievedOrgName = orgsQueryResults.getString("organisation");
                int retrievedCredits = orgsQueryResults.getInt("credits");

                // Prepare a statement to execute GET_ORGS_INVENTORY
                PreparedStatement getOrgInventory = connection.prepareStatement(GET_ORGS_INVENTORY);

                // Populate the query
                getOrgInventory.setString(1, retrievedOrgName);

                // Query the database for results
                ResultSet inventoryQueryResults = getOrgInventory.executeQuery();

                // Define an empty HashMap to hold the organisation's inventory
                HashMap<String, Integer> orgInventory = new HashMap<>();

                // Loop through the ResultSet, populating orgInventory
                while (inventoryQueryResults.next()) {
                    String retrievedAssetName = inventoryQueryResults.getString("asset_name");
                    Integer retrievedQuantity = inventoryQueryResults.getInt("quantity");

                    orgInventory.put(retrievedAssetName, retrievedQuantity);
                }

                // Construct an organisational unit from the retrieved data
                OrganisationalUnit resultOrg = new OrganisationalUnit(retrievedOrgName, retrievedCredits, orgInventory);

                // Add the resulting organisational unit to resultsList
                resultsList.add(resultOrg);
            }

        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing getOrgsList's query(ies) to the database.");
        }

        return resultsList;
    }
}

package server.managers;

import server.database.Database;
import org.springframework.stereotype.Repository;
import server.exceptions.faultyDatabaseConnectionException;
import server.exceptions.illegalAssetNameException;
import server.exceptions.illegalOrgNameException;
import server.exceptions.trades.*;
import server.objects.asset.Asset;
import server.objects.organisation.OrganisationalUnit;
import server.objects.trade.*;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static server.database.ValidationHelpers.*;
import static server.managers.OrganisationalUnitsManager.getOrgInfo;

/**
 * Serverside Java class that contains methods relating to trades.
 *
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@Repository
public class TradesManager {
    /**
     * Method for inserting a trade into the database.
     *
     * @param assetName          name of the asset
     * @param orderType          type of order
     * @param creditPricePerUnit credit price history of the asset
     * @param quantity           quantity to be purchases/sold
     * @param orgName            organisational unit name
     * @return Returns the tradeID of the listed trade if successful, -1 otherwise
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static int placeTrade(String assetName, OrderType orderType, Integer creditPricePerUnit,
                                 Integer quantity, String orgName) {
        // Checks that ALL method parameters are valid before creating SQL query
        assetNameValid(assetName);
        orderTypeValid(orderType);
        creditPricePerUnitValid(creditPricePerUnit);
        quantityValid(quantity);
        orgNameValid(orgName);

        // Verify that the asset exists in the database
        Asset retrievedAsset = AssetsManager.getAssetInfo(assetName);
        if (retrievedAsset == null) {
            throw new illegalAssetNameException("The assetName parameter does not exist in the assets table.");
        }

        // Verify that the organisational unit exists in the database
        OrganisationalUnit retrievedOrg = getOrgInfo(orgName);
        if (retrievedOrg == null) {
            throw new illegalOrgNameException("The orgName parameter does not exist in the organisational_units table.");
        }

        if (orderType == OrderType.BUY) {
            checkCreateWouldCauseCreditDebt(orgName, creditPricePerUnit, quantity);
        } else if (orderType == OrderType.SELL) {
            checkCreateWouldCauseInventoryDebt(orgName, assetName, quantity);
        }

        // Parameters are all valid, so connect to the database and initialise queries for it
        Connection connection = Database.getDatabaseConnection();

        String GET_MAX_TRADE_ID = "SELECT MAX(id) AS highest_trade_id FROM trades;";

        String INSERT_TRADE = "INSERT INTO trades VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";

        int highestStoredTradeID;

        try {
            // Prepare a statement to execute INSERT_TRADE
            PreparedStatement placeTrade = connection.prepareStatement(INSERT_TRADE);

            // Query the database for the maximum tradeID currently stored in the database
            ResultSet queryResults = connection.createStatement().executeQuery(GET_MAX_TRADE_ID);
            // Move the ResultSet's pointer to the first row and store the returned value
            queryResults.next();
            highestStoredTradeID = queryResults.getInt("highest_trade_id");

            // Increment highestStoredTradeID to create a unique, sequential tradeID for the new trade
            highestStoredTradeID += 1;

            // Populate the placeTrade statement with values
            placeTrade.setInt(1, highestStoredTradeID);
            placeTrade.setString(2, assetName);
            placeTrade.setString(3, orderType.name());
            placeTrade.setInt(4, creditPricePerUnit);
            placeTrade.setInt(5, quantity);
            placeTrade.setDate(6, Date.valueOf(LocalDate.now()));
            placeTrade.setDate(7, null);
            placeTrade.setString(8, orgName);
            placeTrade.setBoolean(9, false);

            // Execute the statement
            placeTrade.execute();
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing placeTrade's query(ies) to the database.");
        }
        return highestStoredTradeID; // SQL executed successfully
    }

    /**
     * Method for removing the specified trade from the database.
     *
     * @param tradeID tradeID of specific trade
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static void cancelTrade(Integer tradeID) {
        // Check tradeID is valid
        tradeIDValid(tradeID);

        // Verify that the param tradeID exists in the database
        Trade tempTrade = getTradeInfo(tradeID);
        if (tempTrade == null) {
            throw new nonExistentTradeException("The tradeID parameter does not exist in the trades table.");
        } else if (tempTrade.getIsResolved()) {
            throw new illegalManipulateResolvedTradeException("The tradeID parameter has already been resolved.");
        }

        // Establish connection to database
        Connection connection = Database.getDatabaseConnection();

        // Attempt to remove row
        try {
            String query = "DELETE FROM trades WHERE id=?;";
            PreparedStatement removeTrade = connection.prepareStatement(query);
            removeTrade.setInt(1, tradeID);

            removeTrade.execute();
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing cancelTrade's query(ies) to the database.");
        }
    }

    /**
     * Checks and returns the specified trade as a Trade Object.
     *
     * @param tradeID tradeID of specific trade
     * @return Returns the requested trade info
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static Trade getTradeInfo(Integer tradeID) {
        Trade tempTrade; // temp Trade object

        // Check tradeID is valid
        tradeIDValid(tradeID);

        // Parameter is valid, so connect to the database and initialise queries for it
        Connection connection = Database.getDatabaseConnection();

        String GET_TRADE = "SELECT * FROM trades WHERE id=?;";

        try {
            // Prepare a statement to execute GET_TRADE
            PreparedStatement getTrade = connection.prepareStatement(GET_TRADE);

            getTrade.setInt(1, tradeID);

            // Query the database for results
            ResultSet queryResults = getTrade.executeQuery();

            // Check if the result set is null, if so exit method
            if (!queryResults.next()) return null;

            // Create temp variables to place extracted data into
            int tempTradeID = queryResults.getInt("id");
            String tempAssetName = queryResults.getString("asset_name");
            OrderType tempOrderType = OrderType.valueOf(queryResults.getString("type"));
            int tempCreditPricePerUnit = queryResults.getInt("price_per_unit");
            int tempQuantity = queryResults.getInt("quantity");
            Date tempListingDate = queryResults.getDate("listing_date");
            Date tempResolvedDate = queryResults.getDate("resolved_date");
            String tempOrgName = queryResults.getString("organisation");
            boolean tempIsResolved = queryResults.getBoolean("is_resolved");

            // Handle null resolved dates where they occur
            LocalDate tempResolvedLocalDate = null;

            if (tempResolvedDate != null) {
                // tempResolvedDate is not null, so cast it as a LocalDate
                tempResolvedLocalDate = tempResolvedDate.toLocalDate();
            }

            // Place temp variables into tempTrade's constructor
            tempTrade = new Trade(tempTradeID, tempAssetName, tempOrderType, tempCreditPricePerUnit, tempQuantity,
                    tempListingDate.toLocalDate(), tempResolvedLocalDate, tempOrgName, tempIsResolved);
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing getTradeInfo's query(ies) to the database.");
        }
        // Return info of requested trade
        return tempTrade;
    }

    /**
     * Method for editing specified trade within the database.
     *
     * @param tradeID            id of the trade to edit
     * @param creditPricePerUnit credit price history of the asset
     * @param quantity           quantity to be purchases/sold
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static void editTradeInfo(Integer tradeID, Integer creditPricePerUnit, Integer quantity) {
        // Check parameters are valid
        tradeIDValid(tradeID);
        creditPricePerUnitValid(creditPricePerUnit);
        quantityValid(quantity);

        // Verify that the param tradeID exists in the database
        Trade tempTrade = getTradeInfo(tradeID);
        if (tempTrade == null) {
            throw new nonExistentTradeException("The tradeID parameter does not exist in the trades table.");
        } else if (tempTrade.getIsResolved()) {
            throw new illegalManipulateResolvedTradeException("The tradeID parameter has already been resolved.");
        }

        // Verify that the new values would not cause the organisational unit to fall into debt
        if (tempTrade.getOrderType() == OrderType.BUY) {
            checkEditWouldCauseCreditDebt(tempTrade.getOrgName(), creditPricePerUnit, quantity, tradeID);
        } else if (tempTrade.getOrderType() == OrderType.SELL) {
            checkEditWouldCauseInventoryDebt(tempTrade.getOrgName(), tempTrade.getAssetName(), quantity, tradeID);
        }

        // Parameter is valid, so connect to the database and initialise queries for it
        Connection connection = Database.getDatabaseConnection();

        String UPDATE_QUERY = "UPDATE trades SET price_per_unit=?, quantity=? WHERE id=?;";

        // Attempt to edit trade values
        try {

            PreparedStatement editTrade = connection.prepareStatement(UPDATE_QUERY);
            editTrade.setInt(1, creditPricePerUnit);
            editTrade.setInt(2, quantity);
            editTrade.setInt(3, tradeID);

            editTrade.execute();

        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing editTradeInfo's query(ies) to the database.");
        }
    }

    /**
     * Method for getting a list of Trade objects based on isResolved param from the database.
     *
     * @param isResolved boolean value of state of the trade
     * @return Returns the list of Trade object
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static List<Trade> getTradesList(Boolean isResolved) {
        List<Trade> tempList = new ArrayList<>();
        Trade tempTrade;
        // Check isResolved is valid
        isResolvedValid(isResolved);

        // Parameter is valid, so connect to the database and initialise queries for it
        Connection connection = Database.getDatabaseConnection();

        String GET_TRADES = "SELECT * FROM trades WHERE is_resolved=?;";

        try {
            // Prepare a statement to execute GET_TRADE
            PreparedStatement getTrade = connection.prepareStatement(GET_TRADES);

            getTrade.setBoolean(1, isResolved);

            // Query the database for results
            ResultSet queryResults = getTrade.executeQuery();

            // assign result set into list
            while (queryResults.next()) {
                // Create temp variables to place extracted data into
                int tempTradeID = queryResults.getInt("id");
                String tempAssetName = queryResults.getString("asset_name");
                OrderType tempOrderType = OrderType.valueOf(queryResults.getString("type"));
                int tempCreditPricePerUnit = queryResults.getInt("price_per_unit");
                int tempQuantity = queryResults.getInt("quantity");
                LocalDate tempListingDate = queryResults.getDate("listing_date").toLocalDate();
                Date tempResolvedDate = queryResults.getDate("resolved_date");
                String tempOrgName = queryResults.getString("organisation");
                boolean tempIsResolved = queryResults.getBoolean("is_resolved");

                // Handle null resolved dates where they occur
                LocalDate tempResolvedLocalDate = null;

                if (tempResolvedDate != null) {
                    // tempResolvedDate is not null, so cast it as a LocalDate
                    tempResolvedLocalDate = tempResolvedDate.toLocalDate();
                }

                // Place temp variables into tempTrade's constructor
                tempTrade = new Trade(tempTradeID, tempAssetName, tempOrderType, tempCreditPricePerUnit, tempQuantity,
                        tempListingDate, tempResolvedLocalDate, tempOrgName, tempIsResolved);
                tempList.add(tempTrade);
            }

        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing getTradesList's query(ies) to the database.");
        }
        // Return info of all trades
        return tempList;
    }

    /**
     * Method for resolving a trade.
     *
     * @param tradeID id value of trade being resolved
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static void resolveTrade(Integer tradeID) {
        // Check tradeID is valid
        tradeIDValid(tradeID);

        // Verify that the param tradeID exists in the database
        Trade tempTrade = getTradeInfo(tradeID);
        if (tempTrade == null) {
            throw new nonExistentTradeException("The tradeID parameter does not exist in the trades table.");
        } else if (tempTrade.getIsResolved()) {
            throw new illegalManipulateResolvedTradeException("The tradeID parameter has already been resolved.");
        }

        // Parameter is valid, so connect to the database and initialise queries for it
        Connection connection = Database.getDatabaseConnection();

        String RESOLVE_TRADE_QUERY = "UPDATE trades SET resolved_date=?, is_resolved=? WHERE id=?;";

        // Attempt to edit trade values
        try {
            PreparedStatement resolveTrade = connection.prepareStatement(RESOLVE_TRADE_QUERY);
            resolveTrade.setDate(1, Date.valueOf(LocalDate.now()));
            resolveTrade.setBoolean(2, true);
            resolveTrade.setInt(3, tradeID);

            resolveTrade.execute();

        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing resolveTrade's query(ies) to the database.");
        }
    }

    /**
     * Method for resolving a single trade.
     *
     * @param tradeID           id value of trade being resolved
     * @param otherOrganisation name of the organisational unit that the logged in user is a part of, passed from the client
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static void resolveSingleTrade(Integer tradeID, String otherOrganisation) {
        // Check the parameters are valid
        tradeIDValid(tradeID);
        orgNameValid(otherOrganisation);

        // Verify that the param tradeID exists in the database
        Trade tempTrade = getTradeInfo(tradeID);
        if (tempTrade == null) {
            throw new nonExistentTradeException("The tradeID parameter does not exist in the trades table.");
        } else if (tempTrade.getIsResolved()) {
            throw new illegalManipulateResolvedTradeException("The tradeID parameter has already been resolved.");
        }

        // Verify that the param buyingOrganisation exists in the database
        OrganisationalUnit tempOrg = getOrgInfo(otherOrganisation);
        if (tempOrg == null) {
            throw new illegalOrgNameException("The orgName parameter does not exist in the organisational_units table.");
        }

        try {
            // Get information from the resolved trade to use in another listing
            Trade originalTrade = getTradeInfo(tradeID);
            String sellingOrganisation;
            String buyingOrganisation;
            OrderType oppositeOrderType;
            if (Objects.requireNonNull(originalTrade).getOrderType() == OrderType.BUY) {
                oppositeOrderType = OrderType.SELL;
                buyingOrganisation = originalTrade.getOrgName();
                sellingOrganisation = otherOrganisation;
                // Check if the listing of a new trade in history would put the resolving organisation into debt
                checkCreateWouldCauseInventoryDebt(sellingOrganisation, originalTrade.getAssetName(),
                        originalTrade.getQuantity());
            } else {
                oppositeOrderType = OrderType.BUY;
                buyingOrganisation = otherOrganisation;
                sellingOrganisation = originalTrade.getOrgName();
                // Check if the listing of a new trade in history would put the resolving organisation into debt
                checkCreateWouldCauseCreditDebt(buyingOrganisation, originalTrade.getCreditPricePerUnit(),
                        originalTrade.getQuantity());
            }


            // Parameters are valid, so resolve the trade
            resolveTrade(tradeID);
            OrganisationalUnitsManager.removeFromInventory(sellingOrganisation, originalTrade.getAssetName(),
                    originalTrade.getQuantity());
            OrganisationalUnitsManager.addCredits(sellingOrganisation,
                    originalTrade.getCreditPricePerUnit() * originalTrade.getQuantity());

            // List a new trade to log the other half of the transaction
            int newTradeID = placeTrade(originalTrade.getAssetName(), oppositeOrderType,
                    originalTrade.getCreditPricePerUnit(), originalTrade.getQuantity(), otherOrganisation);

            // Resolve the newly listed trade
            resolveTrade(newTradeID);
            OrganisationalUnitsManager.addToInventory(buyingOrganisation, originalTrade.getAssetName(),
                    originalTrade.getQuantity());
            OrganisationalUnitsManager.removeCredits(buyingOrganisation,
                    originalTrade.getCreditPricePerUnit() * originalTrade.getQuantity());
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing resolveSingleTrade's query(ies) to the database.");
        }
    }

    /**
     * Method for mass resolving trades.
     * Resolving occurs when a buy and sell trade are for the same asset and an agreeable price.
     *
     * @param currentCount number of trades that have been resolved since the initial method call
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    public static int resolveTrades(int currentCount) {
        // Validate currentCount
        if (currentCount < 0) {
            throw new illegalCounterException("The currentCount parameter has been initialised below 0.");
        }

        // Define empty lists to hold the results of SQL queries
        List<Trade> unresolvedBuyTrades = new ArrayList<>();
        List<Trade> unresolvedSellTrades = new ArrayList<>();

        // Connect to the database and store that connection for later use
        Connection connection = Database.getDatabaseConnection();

        // Get all unresolved buy trades from the database
        String GET_UNRESOLVED_BUY_TRADES = "SELECT * FROM trades WHERE is_resolved='FALSE' AND type='BUY';";

        try {
            ResultSet buyResults = connection.createStatement().executeQuery(GET_UNRESOLVED_BUY_TRADES);

            // Loop through all results, instance them as trades and place them in the list
            while (buyResults.next()) {
                int tradeID = buyResults.getInt("id");
                String assetName = buyResults.getString("asset_name");
                int creditPricePerUnit = buyResults.getInt("price_per_unit");
                int quantity = buyResults.getInt("quantity");
                LocalDate listingDate = buyResults.getDate("listing_date").toLocalDate();
                String orgName = buyResults.getString("organisation");

                Trade resultingTrade = new Trade(tradeID, assetName, OrderType.BUY, creditPricePerUnit, quantity,
                        listingDate, null, orgName, false);

                unresolvedBuyTrades.add(resultingTrade);
            }
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing resolveTrades' query(ies) to the database.");
        }

        // Get all unresolved sell trades from the database
        String GET_UNRESOLVED_SELL_TRADES = "SELECT * FROM trades WHERE is_resolved='FALSE' AND type='SELL';";

        try {
            ResultSet sellResults = connection.createStatement().executeQuery(GET_UNRESOLVED_SELL_TRADES);

            // Loop through all results, instance them as trades and place them in the list
            while (sellResults.next()) {
                int tradeID = sellResults.getInt("id");
                String assetName = sellResults.getString("asset_name");
                int creditPricePerUnit = sellResults.getInt("price_per_unit");
                int quantity = sellResults.getInt("quantity");
                LocalDate listingDate = sellResults.getDate("listing_date").toLocalDate();
                String orgName = sellResults.getString("organisation");

                Trade resultingTrade = new Trade(tradeID, assetName, OrderType.SELL, creditPricePerUnit, quantity,
                        listingDate, null, orgName, false);

                unresolvedSellTrades.add(resultingTrade);
            }
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing resolveTrades' query(ies) to the database.");
        }

        // Loop through the buy trades, comparing each to every sell trade to look for a potential resolution
        for (Trade buyTrade : unresolvedBuyTrades) {
            for (Trade sellTrade : unresolvedSellTrades) {
                if ((buyTrade.getAssetName().equals(sellTrade.getAssetName())) &&
                        (sellTrade.getCreditPricePerUnit() <= buyTrade.getCreditPricePerUnit())) {
                    // This combination of trades can be resolved, so resolve it
                    if (buyTrade.getQuantity().equals(sellTrade.getQuantity())) {
                        // Both trades have the same quantities, so simply resolve them
                        resolveTrade(buyTrade.getTradeID());
                        resolveTrade(sellTrade.getTradeID());
                        OrganisationalUnitsManager.removeFromInventory(sellTrade.getOrgName(), sellTrade.getAssetName(),
                                sellTrade.getQuantity());
                        OrganisationalUnitsManager.addCredits(sellTrade.getOrgName(),
                                sellTrade.getCreditPricePerUnit() * sellTrade.getQuantity());
                        OrganisationalUnitsManager.addToInventory(buyTrade.getOrgName(), buyTrade.getAssetName(),
                                buyTrade.getQuantity());
                        OrganisationalUnitsManager.removeCredits(buyTrade.getOrgName(),
                                sellTrade.getCreditPricePerUnit() * buyTrade.getQuantity());

                    } else if (buyTrade.getQuantity() >= sellTrade.getQuantity()) {
                        // The buy trade wants more than the sell trade can provide, so start by resolving the sell trade
                        resolveTrade(sellTrade.getTradeID());
                        OrganisationalUnitsManager.removeFromInventory(sellTrade.getOrgName(), sellTrade.getAssetName(),
                                sellTrade.getQuantity());
                        OrganisationalUnitsManager.addCredits(sellTrade.getOrgName(),
                                sellTrade.getCreditPricePerUnit() * sellTrade.getQuantity());

                        // Resolve the old buy trade
                        editTradeInfo(buyTrade.getTradeID(), buyTrade.getCreditPricePerUnit(), sellTrade.getQuantity());
                        resolveTrade(buyTrade.getTradeID());
                        OrganisationalUnitsManager.addToInventory(buyTrade.getOrgName(), buyTrade.getAssetName(),
                                sellTrade.getQuantity());
                        OrganisationalUnitsManager.removeCredits(buyTrade.getOrgName(),
                                sellTrade.getCreditPricePerUnit() * sellTrade.getQuantity());

                        // List a new buy trade to cover the remainder
                        placeTrade(buyTrade.getAssetName(), OrderType.BUY, buyTrade.getCreditPricePerUnit(),
                                buyTrade.getQuantity() - sellTrade.getQuantity(), buyTrade.getOrgName());
                    } else if (buyTrade.getQuantity() <= sellTrade.getQuantity()) {
                        // The sell trade wants more than the buy trade wants, so start by resolving the buy trade
                        resolveTrade(buyTrade.getTradeID());
                        OrganisationalUnitsManager.addToInventory(buyTrade.getOrgName(), buyTrade.getAssetName(),
                                buyTrade.getQuantity());
                        OrganisationalUnitsManager.removeCredits(buyTrade.getOrgName(),
                                sellTrade.getCreditPricePerUnit() * buyTrade.getQuantity());


                        // Resolve the old sell trade
                        editTradeInfo(sellTrade.getTradeID(), sellTrade.getCreditPricePerUnit(), buyTrade.getQuantity());
                        resolveTrade(sellTrade.getTradeID());
                        OrganisationalUnitsManager.removeFromInventory(sellTrade.getOrgName(), sellTrade.getAssetName(),
                                buyTrade.getQuantity());
                        OrganisationalUnitsManager.addCredits(sellTrade.getOrgName(),
                                sellTrade.getCreditPricePerUnit() * buyTrade.getQuantity());

                        // List a new sell trade to cover the remainder
                        placeTrade(sellTrade.getAssetName(), OrderType.SELL, sellTrade.getCreditPricePerUnit(),
                                sellTrade.getQuantity() - buyTrade.getQuantity(), sellTrade.getOrgName());
                    }
                    // The trades list has been changed in a significant way, so recursively call resolveTrades()
                    return resolveTrades(currentCount + 2); // +2 to reflect two trades being resolved
                }
            }
        }

        // All trades have been checked, including trades created from the remainders of other trades, so
        // the method is finished running.
        return currentCount;
    }
}

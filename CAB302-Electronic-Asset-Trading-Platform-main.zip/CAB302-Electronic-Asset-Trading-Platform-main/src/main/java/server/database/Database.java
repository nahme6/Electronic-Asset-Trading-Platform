package server.database;

import server.exceptions.faultyDatabaseConnectionException;
import server.managers.OrganisationalUnitsManager;
import server.managers.UsersManager;
import server.objects.organisation.OrganisationalUnit;
import server.objects.user.AccountType;
import server.objects.user.User;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Serverside Java class that facilitates connection to the eatp.db database.
 *
 * @author Daniel Taylor, N10492623
 */
public final class Database {
    static String defaultEmail = "itadministration@genericdomain.com";
    static String defaultOrg = "IT Administration";

    // Static value that will hold the single instance of the database connection.
    private static Connection connection = null;

    /**
     * Accessor method for the private connection variable of the main database. Returns the value of connection,
     * or creates a new connection to the database to return if connection is null.
     *
     * @return Returns a database Connection
     * @author Daniel Taylor, N10492623
     */
    public static Connection getDatabaseConnection() {
        if (connection == null) {
            setDatabaseConnection(false);
        }
        return connection;
    }

    /**
     * Method for setting the private connection variable of the test database.
     *
     * @author Daniel Taylor, N10492623
     */
    public static void setDatabaseConnection(boolean isTestDb) {
        // Attempt to connect to the database
        Properties connectionConfig = new Properties();
        connectionConfig.put("user", "root");
        connectionConfig.put("password", "root");
        String url = "jdbc:mariadb://localhost:3306/eatp";

        if (isTestDb) {
            url = "jdbc:mariadb://localhost:3306/eatptest";
        }

        try {
            // Close any current conflicting connections
            if (connection != null && (connection.isClosed() || !url.equals(connection.getMetaData().getURL())))
                connection.close();
            // Set the connection variable to the new connection
            connection = DriverManager.getConnection(url, connectionConfig);
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing Database constructor's query(ies) to the database.");
        }
    }

    /**
     * Method for creating all tables and default data within the database.
     *
     * @param isTestDb boolean value of whether or not the database is the live db (false) or the test db (true)
     * @author Daniel Taylor, N10492623
     */
    public static void createNewDatabase(boolean isTestDb) {
        // Define string variables to hold the SQL queries that will be run
        String CREATE_EATP_DATABASE = "CREATE DATABASE IF NOT EXISTS ";

        String CREATE_USER_ACCOUNTS_TABLE =
                "CREATE TABLE IF NOT EXISTS user_accounts ("
                        + "email VARCHAR(320) PRIMARY KEY NOT NULL,"
                        + "password VARCHAR(128) NOT NULL,"
                        + "salt VARCHAR(128) NOT NULL,"
                        + "first_name VARCHAR(50) NOT NULL,"
                        + "last_name VARCHAR(50) NOT NULL,"
                        + "account_type VARCHAR(8) NOT NULL,"
                        + "organisation VARCHAR(50) NOT NULL";
        if (!isTestDb) {
            CREATE_USER_ACCOUNTS_TABLE += ",FOREIGN KEY (organisation) REFERENCES organisational_units(organisation) ON UPDATE CASCADE";
        }
        CREATE_USER_ACCOUNTS_TABLE += ");";

        String CREATE_ORGANISATIONAL_UNITS_TABLE =
                "CREATE TABLE IF NOT EXISTS organisational_units ("
                        + "organisation VARCHAR(50) PRIMARY KEY NOT NULL,"
                        + "credits INTEGER NOT NULL" + ");";

        String CREATE_ASSETS_TABLE =
                "CREATE TABLE IF NOT EXISTS assets ("
                        + "name VARCHAR(50) PRIMARY KEY NOT NULL,"
                        + "description VARCHAR(500)" + ");";

        String CREATE_ASSET_INVENTORY_TABLE =
                "CREATE TABLE IF NOT EXISTS asset_inventory ("
                        + "organisation VARCHAR(50) NOT NULL,"
                        + "asset_name VARCHAR(50) NOT NULL,"
                        + "quantity INTEGER NOT NULL,"
                        + "PRIMARY KEY (organisation, asset_name)";
        if (!isTestDb) {
            CREATE_ASSET_INVENTORY_TABLE += ",FOREIGN KEY (asset_name) REFERENCES assets(name) ON UPDATE CASCADE,"
                    + "FOREIGN KEY (organisation) REFERENCES organisational_units(organisation) ON UPDATE CASCADE";
        }
        CREATE_ASSET_INVENTORY_TABLE += ");";

        String CREATE_TRADES_TABLE =
                "CREATE TABLE IF NOT EXISTS trades ("
                        + "id INTEGER PRIMARY KEY NOT NULL UNIQUE,"
                        + "asset_name VARCHAR(50) NOT NULL,"
                        + "type VARCHAR(4) NOT NULL,"
                        + "price_per_unit INTEGER NOT NULL,"
                        + "quantity INTEGER NOT NULL,"
                        + "listing_date DATE NOT NULL,"
                        + "resolved_date DATE,"
                        + "organisation VARCHAR(50) NOT NULL,"
                        + "is_resolved BOOLEAN NOT NULL";
        if (!isTestDb) {
            CREATE_TRADES_TABLE += ",FOREIGN KEY (asset_name) REFERENCES assets(name) ON UPDATE CASCADE,"
                    + "FOREIGN KEY (organisation) REFERENCES organisational_units(organisation) ON UPDATE CASCADE";
        }
        CREATE_TRADES_TABLE += ");";

        try {
            // Connect to the database server without selecting a database
            Connection tempConnection = DriverManager.getConnection("jdbc:mariadb://localhost:3306/", "root", "root");

            // Populate and execute a query to create the database if it does not exist
            if (isTestDb) CREATE_EATP_DATABASE += "eatptest;";
            else CREATE_EATP_DATABASE += "eatp";
            tempConnection.createStatement().execute(CREATE_EATP_DATABASE);

            tempConnection.close();

            // Connect to the selected database and store that connection for later use
            setDatabaseConnection(isTestDb);

            // Execute SQL queries to create the database's tables if they are missing
            Connection dbConnection = getDatabaseConnection();
            dbConnection.createStatement().execute(CREATE_ASSETS_TABLE);
            dbConnection.createStatement().execute(CREATE_ORGANISATIONAL_UNITS_TABLE);
            dbConnection.createStatement().execute(CREATE_USER_ACCOUNTS_TABLE);
            dbConnection.createStatement().execute(CREATE_ASSET_INVENTORY_TABLE);
            dbConnection.createStatement().execute(CREATE_TRADES_TABLE);

            if (!isTestDb) {
                // Check if the default organisational unit and user need to be made
                OrganisationalUnit retrievedOrg = OrganisationalUnitsManager.getOrgInfo(defaultOrg);
                User retrievedUser = UsersManager.getUserInfo(defaultEmail);

                if (retrievedOrg == null) {
                    // Call method from the manager class to add a default organisational unit to the database
                    OrganisationalUnitsManager.createOrg(defaultOrg, 0);
                }
                if (retrievedUser == null) {
                    // Call method from the manager class to add a default user to the database
                    UsersManager.createUser(defaultEmail, "password123",
                            "John", "Doe", AccountType.Admin, "IT Administration");
                }
            }
        } catch (SQLException e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing createNewDatabase's query(ies) to the database.");
        }
    }
}

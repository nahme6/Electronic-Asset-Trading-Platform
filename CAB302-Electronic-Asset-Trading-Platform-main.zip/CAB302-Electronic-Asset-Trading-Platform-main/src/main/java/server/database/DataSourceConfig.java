package server.database;

import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

/**
 * Serverside Java class that configures the eatp.db database for use in spring application.
 * @author Daniel Taylor, N10492623
 */
@Configuration
public class DataSourceConfig {
    /**
     * Method for configuring the address, user and password of the eatp database.
     *
     * @return Returns the configured database Bean
     * @author Daniel Taylor, N10492623
     */
    @Bean(name="dataSourceServer")
    public DataSource getDataSource() {
        DataSourceBuilder<?> dataSourceBuilder = DataSourceBuilder.create();
        dataSourceBuilder.driverClassName("org.mariadb.jdbc.Driver");
        dataSourceBuilder.url("jdbc:mariadb://localhost:3306/eatp");
        dataSourceBuilder.username("root");
        dataSourceBuilder.password("root");
        return dataSourceBuilder.build();
    }
}
package server.database;

import server.exceptions.*;
import server.exceptions.assets.illegalAssetDescriptionException;
import server.exceptions.wouldRiskDebtException;
import server.exceptions.trades.*;
import server.exceptions.users.*;
import server.objects.trade.OrderType;
import server.objects.user.AccountType;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Objects;

import static server.managers.OrganisationalUnitsManager.getOrgInfo;

/**
 * Serverside Java class that contains methods used to enforce constraints on variables.
 *
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
public class ValidationHelpers {

    /**
     * Helper method for validating an email value.
     *
     * @param email email value to be checked
     * @throws illegalEmailException if param email is not valid
     * @author Chris Sterkenburg, N10478728
     */
    public static void emailValid(String email) throws illegalEmailException {
        // Check email is valid
        if ((email == null) || (email.trim().isEmpty())) {
            throw new illegalEmailException("The email parameter does not meet the database constraints.");
        }

        if (email.length() > 320) {
            throw new illegalEmailException("The email parameter does not meet the database constraints.");
        }

        String emailRegex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
        if (!email.matches(emailRegex)) {
            throw new illegalEmailException("The email parameter does not meet the database constraints.");
        }
    }

    /**
     * Helper method for validating an unhashed password value.
     *
     * @param unhashedPassword password value to be checked
     * @throws illegalPasswordException if param password is not valid
     * @author Chris Sterkenburg, N10478728
     */
    public static void passwordUnhasedValid(String unhashedPassword) throws illegalPasswordException {
        // Check password is valid
        if ((unhashedPassword == null) || (unhashedPassword.trim().isEmpty())) {
            throw new illegalPasswordException("The unhashedPassword parameter does not meet the database constraints.");
        }
    }

    /**
     * Helper method for validating a hashed password value.
     *
     * @param hashedPassword hashed password value to be checked
     * @throws illegalPasswordException if param password is not valid
     * @author Chris Sterkenburg, N10478728
     */
    public static void passwordValid(String hashedPassword) throws illegalPasswordException {
        // Check password is valid
        if ((hashedPassword == null) || (hashedPassword.trim().isEmpty())) {
            throw new illegalPasswordException("The hashedPassword parameter does not meet the database constraints.");
        }

        if (hashedPassword.length() > 120) {
            throw new illegalPasswordException("The hashedPassword parameter does not meet the database constraints.");
        }
    }

    /**
     * Helper method for validating a firstName value.
     *
     * @param firstName firstName value to be checked
     * @throws illegalFirstNameException if param firstName is not valid
     * @author Chris Sterkenburg, N10478728
     */
    public static void firstNameValid(String firstName) throws illegalFirstNameException {
        // Check firstName is valid
        if ((firstName == null) || (firstName.trim().isEmpty())) {
            throw new illegalFirstNameException("The firstName parameter does not meet the database constraints.");
        }

        if (firstName.length() > 50) {
            throw new illegalFirstNameException("The firstName parameter does not meet the database constraints.");
        }
    }

    /**
     * Helper method for validating a lastName value.
     *
     * @param lastName lastName value to be checked
     * @throws illegalLastNameException if param lastName is not valid
     * @author Chris Sterkenburg, N10478728
     */
    public static void lastNameValid(String lastName) throws illegalLastNameException {
        // Check lastName is valid
        if ((lastName == null) || (lastName.trim().isEmpty())) {
            throw new illegalLastNameException("The lastName parameter does not meet the database constraints.");
        }

        if (lastName.length() > 50) {
            throw new illegalLastNameException("The lastName parameter does not meet the database constraints.");
        }
    }

    /**
     * Helper method for validating an account Type.
     *
     * @param accountType account Type to be checked
     * @throws illegalAccountTypeException if param accountType is not valid
     * @author Chris Sterkenburg, N10478728
     */
    public static void accountTypeValid(AccountType accountType) throws illegalAccountTypeException {
        // Check accountType is valid
        if (accountType == null) {
            throw new illegalAccountTypeException("The accountType parameter is null.");
        }
    }

    /* --------------------------------------------------------------------------------------------------------------------*/

    /**
     * Helper method for validating an tradeID value.
     *
     * @param tradeID tradeID value to be checked
     * @throws illegalTradeIDException if param tradeID is not valid
     * @author Chris Sterkenburg, N10478728
     */
    public static void tradeIDValid(Integer tradeID) throws illegalTradeIDException {
        // Check tradeID is valid
        if ((tradeID == null) || (tradeID < 1)) {
            throw new illegalTradeIDException("The tradeID parameter does not meet the database constraints.");
        }
    }

    /**
     * Helper method for validating an asset's name.
     *
     * @param assetName name of the asset to be checked
     * @throws illegalAssetNameException if param assetName is not valid
     * @author Chris Sterkenburg, N10478728
     */
    public static void assetNameValid(String assetName) throws illegalAssetNameException {
        // Check assetName is valid
        if ((assetName == null) || (assetName.trim().isEmpty())) {
            throw new illegalAssetNameException("The assetName parameter does not meet the database constraints.");
        }

        if (assetName.length() > 50) {
            throw new illegalAssetNameException("The assetName parameter does not meet the database constraints.");
        }
    }

    /**
     * Helper method for validating an description value.
     *
     * @param description description string to be checked
     * @throws illegalAssetDescriptionException if param description is not valid
     * @author Navid Ahmed, N10470433
     */
    public static void assetDescriptionValid(String description) throws illegalAssetDescriptionException {
        // Check credits is valid
        if ((description == null) || (description.trim().isEmpty())) {
            throw new illegalAssetDescriptionException("The description parameter does not meet the database constraints.");
        }

        if (description.length() > 500) {
            throw new illegalAssetDescriptionException("The description parameter does not meet the database constraints.");
        }
    }

    /**
     * Helper method for validating an order type.
     *
     * @param orderType order type to be checked
     * @throws illegalOrderTypeException if param orderType is not valid
     * @author Chris Sterkenburg, N10478728
     */
    public static void orderTypeValid(OrderType orderType) throws illegalOrderTypeException {
        // Check orderType is valid
        if (orderType == null) {
            throw new illegalOrderTypeException("The orderType parameter is null.");
        }
    }

    /**
     * Helper method for validating the credit price history.
     *
     * @param creditPricePerUnit credit price history to be checked
     * @throws illegalCreditsException if param creditPricePerUnit is not valid
     * @author Chris Sterkenburg, N10478728
     */
    public static void creditPricePerUnitValid(Integer creditPricePerUnit) throws illegalCreditsException {
        // Check creditPricePerUnit is valid
        if ((creditPricePerUnit == null) || (creditPricePerUnit < 1)) {
            throw new illegalCreditsException("The creditPricePerUnit parameter does not meet the database constraints.");
        }
    }

    /**
     * Helper method for validating an quantity value.
     *
     * @param quantity quantity value to be checked
     * @throws illegalQuantityException if param quantity is not valid
     * @author Chris Sterkenburg, N10478728
     */
    public static void quantityValid(Integer quantity) throws illegalQuantityException {
        // Check quantity is valid
        if ((quantity == null) || (quantity < 1)) {
            throw new illegalQuantityException("The quantity parameter does not meet the database constraints.");
        }
    }

    /**
     * Helper method for validating an orgName value.
     *
     * @param orgName organisational unit's name value to be checked
     * @throws illegalOrgNameException if param orgName is not valid
     * @author Chris Sterkenburg, N10478728
     */
    public static void orgNameValid(String orgName) throws illegalOrgNameException {
        if ((orgName == null) || (orgName.trim().isEmpty())) {
            throw new illegalOrgNameException("The orgName parameter does not meet the database constraints.");
        }

        if (orgName.length() > 50) {
            throw new illegalOrgNameException("The orgName parameter does not meet the database constraints.");
        }
    }

    /**
     * Helper method for validating isResolved value.
     *
     * @param isResolved boolean value to be checked
     * @throws illegalResolvedStatusException if param isResolved is not valid
     * @author Chris Sterkenburg, N10478728
     */
    public static void isResolvedValid(Boolean isResolved) throws illegalResolvedStatusException {
        if ((isResolved == null)) {
            throw new illegalResolvedStatusException("The isResolved parameter is null.");
        }
    }

    /**
     * Helper method for validating a credit balance value.
     *
     * @param creditBalance credits value to be checked
     * @throws illegalCreditsException if param creditBalance is not valid
     * @author Chris Sterkenburg, N10478728
     */
    public static void creditBalanceValid(Integer creditBalance) throws illegalCreditsException {
        // Check credits is valid
        if ((creditBalance == null) || (creditBalance < 0)) {
            throw new illegalCreditsException("The creditBalance parameter does not meet the database constraints.");
        }
    }

    /**
     * Helper method for validating a credit's value.
     *
     * @param credits credits value to be checked
     * @throws illegalCreditsException if param credits is not valid
     * @author Daniel Taylor, N10492623
     */
    public static void creditsValid(Integer credits) throws illegalCreditsException {
        // Check credits is valid
        if ((credits == null) || (credits < 1)) {
            throw new illegalCreditsException("The credits parameter does not meet the database constraints.");
        }
    }

    /**
     * Helper method for validating whether an organisational unit would go into debt.
     *
     * @param orgName            organisational unit to be checked
     * @param creditPricePerUnit price per unit of a trade
     * @param quantity           quantity of a trade
     * @throws RuntimeException if an error occurs
     * @author Daniel Taylor, N10492623
     */
    public static void checkCreateWouldCauseCreditDebt(String orgName, int creditPricePerUnit, int quantity) throws RuntimeException {
        // The order is a BUY order, so check that the organisation has enough credits left, including other listed
        // orders

        // Connect to the database and initialise a query for it
        Connection connection = Database.getDatabaseConnection();
        String GET_ORG_BUY_TRADES = "SELECT price_per_unit, quantity FROM trades WHERE organisation=? AND type='BUY' AND is_resolved='FALSE';";

        try {
            // Get the current credits of the organisation
            int orgCredits = Objects.requireNonNull(getOrgInfo(orgName)).getCreditBalance();

            // Prepare a statement to execute GET_ORG_BUY_TRADES
            PreparedStatement getOrgBuyTrades = connection.prepareStatement(GET_ORG_BUY_TRADES);

            // Populate the getOrgBuyTrades statement with values
            getOrgBuyTrades.setString(1, orgName);

            // Execute the statement
            ResultSet getOrgBuyTradesResults = getOrgBuyTrades.executeQuery();

            // Loop through all results, subtracting their effect on the credits total from orgCredits
            while (getOrgBuyTradesResults.next()) {
                int resultCreditPricePerUnit = getOrgBuyTradesResults.getInt("price_per_unit");
                int resultQuantity = getOrgBuyTradesResults.getInt("quantity");

                orgCredits -= resultCreditPricePerUnit * resultQuantity;
            }

            // Check if the trade would put the organisation into debt
            if (orgCredits < (creditPricePerUnit * quantity) || orgCredits < 0) {
                // The trade would put the organisation into debt, so throw an illegalCreditsException
                throw new wouldRiskDebtException("Trade would put the organisational unit into debt.");
            }
        } catch (wouldRiskDebtException e) {
            throw e;
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing checkCreateWouldCauseCreditDebt's query(ies) to the database.");
        }
    }

    /**
     * Helper method for validating whether an organisational unit would go into debt.
     *
     * @param orgName            organisational unit to be checked
     * @param creditPricePerUnit price per unit of a trade
     * @param quantity           quantity of a trade
     * @throws RuntimeException if an error occurs
     * @author Daniel Taylor, N10492623
     */
    public static void checkEditWouldCauseCreditDebt(String orgName, int creditPricePerUnit, int quantity, int tradeID) throws RuntimeException {
        // The order is a BUY order, so check that the organisation has enough credits left, including other listed
        // orders

        // Connect to the database and initialise a query for it
        Connection connection = Database.getDatabaseConnection();
        String GET_ORG_BUY_TRADES = "SELECT id, price_per_unit, quantity FROM trades WHERE organisation=? AND type='BUY' AND is_resolved='FALSE';";

        try {
            // Get the current credits of the organisation
            int orgCredits = Objects.requireNonNull(getOrgInfo(orgName)).getCreditBalance();

            // Prepare a statement to execute GET_ORG_BUY_TRADES
            PreparedStatement getOrgBuyTrades = connection.prepareStatement(GET_ORG_BUY_TRADES);

            // Populate the getOrgBuyTrades statement with values
            getOrgBuyTrades.setString(1, orgName);

            // Execute the statement
            ResultSet getOrgBuyTradesResults = getOrgBuyTrades.executeQuery();

            // Loop through all results, subtracting their effect on the credits total from orgCredits
            while (getOrgBuyTradesResults.next()) {
                int resultCreditPricePerUnit = getOrgBuyTradesResults.getInt("price_per_unit");
                int resultQuantity = getOrgBuyTradesResults.getInt("quantity");
                if (getOrgBuyTradesResults.getInt("id") != tradeID)
                    orgCredits -= resultCreditPricePerUnit * resultQuantity;
            }

            // Check if the trade would put the organisation into debt
            if (orgCredits < (creditPricePerUnit * quantity) || orgCredits < 0) {
                // The trade would put the organisation into debt, so throw an illegalCreditsException
                throw new wouldRiskDebtException("Trade would put the organisational unit into debt.");
            }
        } catch (wouldRiskDebtException e) {
            throw e;
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing checkEditWouldCauseCreditDebt's query(ies) to the database.");
        }
    }

    /**
     * Helper method for validating whether an organisational unit would go into debt.
     *
     * @param orgName organisational unit to be checked
     * @param credits credit amount
     * @throws RuntimeException if an error occurs
     * @author Daniel Taylor, N10492623
     */
    public static void checkSetWouldCauseCreditDebt(String orgName, int credits) throws RuntimeException {
        // Connect to the database and initialise a query for it
        Connection connection = Database.getDatabaseConnection();
        String GET_ORG_BUY_TRADES = "SELECT price_per_unit, quantity FROM trades WHERE organisation=? AND type='BUY' AND is_resolved='FALSE';";

        try {
            // Prepare a statement to execute GET_ORG_BUY_TRADES
            PreparedStatement getOrgBuyTrades = connection.prepareStatement(GET_ORG_BUY_TRADES);

            // Populate the getOrgBuyTrades statement with values
            getOrgBuyTrades.setString(1, orgName);

            // Execute the statement
            ResultSet getOrgBuyTradesResults = getOrgBuyTrades.executeQuery();

            // Loop through all results, subtracting their effect on the credits total from orgCredits
            while (getOrgBuyTradesResults.next()) {
                int resultCreditPricePerUnit = getOrgBuyTradesResults.getInt("price_per_unit");
                int resultQuantity = getOrgBuyTradesResults.getInt("quantity");

                credits -= resultCreditPricePerUnit * resultQuantity;
            }

            // Check if the trade would put the organisation into debt
            if (credits < 0) {
                // The trade would put the organisation into debt, so throw an illegalCreditsException
                throw new wouldRiskDebtException("Trade would put the organisational unit into debt.");
            }
        } catch (wouldRiskDebtException e) {
            throw e;
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing checkCreateWouldCauseCreditDebt's query(ies) to the database.");
        }
    }

    /**
     * Helper method for validating whether an organisational unit would go into debt.
     *
     * @param orgName   organisational unit to be checked
     * @param assetName name of the asset
     * @param quantity  quantity of the asset
     * @throws RuntimeException if an error occurs
     * @author Daniel Taylor, N10492623
     */
    public static void checkCreateWouldCauseInventoryDebt(String orgName, String assetName, int quantity) throws RuntimeException {
        // The order is a SELL order, so check that the organisation has enough assets left, including other listed
        // orders

        // Connect to the database and initialise a query for it
        Connection connection = Database.getDatabaseConnection();
        String GET_ORG_SELL_TRADES = "SELECT quantity FROM trades WHERE organisation=? AND type='SELL' AND is_resolved='FALSE' AND asset_name=?;";

        try {
            // Get the current quantity of the asset owned by the organisation
            HashMap<String, Integer> orgInventory = Objects.requireNonNull(getOrgInfo(orgName)).getInventory();
            int ownedQuantity = 0;
            if (orgInventory.get(assetName) != null) {
                ownedQuantity = orgInventory.get(assetName);
            }

            // Prepare a statement to execute GET_ORG_SELL_TRADES
            PreparedStatement getOrgSellTrades = connection.prepareStatement(GET_ORG_SELL_TRADES);

            // Populate the getOrgSellTrades statement with values
            getOrgSellTrades.setString(1, orgName);
            getOrgSellTrades.setString(2, assetName);

            // Execute the statement
            ResultSet getOrgSellTradesResults = getOrgSellTrades.executeQuery();

            // Loop through all results, subtracting their effect on the quantity total from ownedQuantity
            while (getOrgSellTradesResults.next()) {
                int resultQuantity = getOrgSellTradesResults.getInt("quantity");

                ownedQuantity -= resultQuantity;
            }

            // Check if the trade would put the organisation into debt
            if (ownedQuantity < quantity || ownedQuantity < 0) {
                // The trade would put the organisation into debt, so throw an illegalQuantityException
                throw new wouldRiskDebtException("Trade would put the organisational unit into debt.");
            }
        } catch (wouldRiskDebtException e) {
            throw e;
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing checkCreateWouldCauseInventoryDebt's query(ies) to the database.");
        }
    }

    /**
     * Helper method for validating whether an organisational unit would go into debt.
     *
     * @param orgName   organisational unit to be checked
     * @param assetName name of the asset
     * @param quantity  quantity of the asset
     * @param tradeID   id of a trade
     * @throws RuntimeException if an error occurs
     * @author Daniel Taylor, N10492623
     */
    public static void checkEditWouldCauseInventoryDebt(String orgName, String assetName, int quantity, int tradeID) throws RuntimeException {
        // The order is a SELL order, so check that the organisation has enough assets left, including other listed
        // orders

        // Connect to the database and initialise a query for it
        Connection connection = Database.getDatabaseConnection();
        String GET_ORG_SELL_TRADES = "SELECT id, quantity FROM trades WHERE organisation=? AND type='SELL' AND is_resolved='FALSE' AND asset_name=?;";

        try {
            // Get the current quantity of the asset owned by the organisation
            HashMap<String, Integer> orgInventory = Objects.requireNonNull(getOrgInfo(orgName)).getInventory();
            int ownedQuantity = 0;
            if (!(orgInventory.get(assetName) == null)) {
                ownedQuantity = orgInventory.get(assetName);
            }

            // Prepare a statement to execute GET_ORG_SELL_TRADES
            PreparedStatement getOrgSellTrades = connection.prepareStatement(GET_ORG_SELL_TRADES);

            // Populate the getOrgSellTrades statement with values
            getOrgSellTrades.setString(1, orgName);
            getOrgSellTrades.setString(2, assetName);

            // Execute the statement
            ResultSet getOrgSellTradesResults = getOrgSellTrades.executeQuery();

            // Loop through all results, subtracting their effect on the quantity total from ownedQuantity
            while (getOrgSellTradesResults.next()) {
                int resultQuantity = getOrgSellTradesResults.getInt("quantity");
                if (getOrgSellTradesResults.getInt("id") != tradeID) ownedQuantity -= resultQuantity;
            }

            // Check if the trade would put the organisation into debt
            if (ownedQuantity < quantity || ownedQuantity < 0) {
                // The trade would put the organisation into debt, so throw an illegalQuantityException
                throw new wouldRiskDebtException("Trade would put the organisational unit into debt.");
            }
        } catch (wouldRiskDebtException e) {
            throw e;
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing checkEditWouldCauseInventoryDebt's query(ies) to the database.");
        }
    }

    /**
     * Helper method for validating whether an organisational unit would go into debt.
     *
     * @param orgName   organisational unit to be checked
     * @param assetName name of the asset
     * @param quantity  quantity of the asset
     * @throws RuntimeException if an error occurs
     * @author Daniel Taylor, N10492623
     */
    public static void checkSetWouldCauseInventoryDebt(String orgName, String assetName, int quantity) throws RuntimeException {
        // Connect to the database and initialise a query for it
        Connection connection = Database.getDatabaseConnection();
        String GET_ORG_SELL_TRADES = "SELECT quantity FROM trades WHERE organisation=? AND type='SELL' AND is_resolved='FALSE' AND asset_name=?;";

        try {
            // Prepare a statement to execute GET_ORG_SELL_TRADES
            PreparedStatement getOrgSellTrades = connection.prepareStatement(GET_ORG_SELL_TRADES);

            // Populate the getOrgSellTrades statement with values
            getOrgSellTrades.setString(1, orgName);
            getOrgSellTrades.setString(2, assetName);

            // Execute the statement
            ResultSet getOrgSellTradesResults = getOrgSellTrades.executeQuery();

            // Loop through all results, subtracting their effect on the quantity total from ownedQuantity
            while (getOrgSellTradesResults.next()) {
                int resultQuantity = getOrgSellTradesResults.getInt("quantity");

                quantity -= resultQuantity;
            }

            // Check if the trade would put the organisation into debt
            if (quantity < 0) {
                // The trade would put the organisation into debt, so throw an illegalQuantityException
                throw new wouldRiskDebtException("Trade would put the organisational unit into debt.");
            }
        } catch (wouldRiskDebtException e) {
            throw e;
        } catch (Exception e) {
            // Something has gone wrong, so throw a faultyDatabaseConnectionException
            throw new faultyDatabaseConnectionException("Something went wrong processing checkSetWouldCauseInventoryDebt's query(ies) to the database.");
        }
    }
}

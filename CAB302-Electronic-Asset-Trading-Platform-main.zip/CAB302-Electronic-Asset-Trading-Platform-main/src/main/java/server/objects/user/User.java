package server.objects.user;

/**
 * Serverside Java class that creates a User object required for login and operation of the application.
 *
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
public class User {
    private final String email;
    private final String password;
    private final String salt;
    private final String firstName;
    private final String lastName;
    private final AccountType accountType;
    private final String orgName;


    public User(String email, String password, String salt, String firstName, String lastName, AccountType accountType, String orgName) {
        this.email = email;
        this.password = password;
        this.salt = salt;
        this.firstName = firstName;
        this.lastName = lastName;
        this.accountType = accountType;
        this.orgName = orgName;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getSalt() {
        return salt;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public AccountType getAccountType() {
        return accountType;
    }

    public String getOrgName() {
        return orgName;
    }

    /**
     * Compares an User to another object and determines if they are the same.
     * Overrides default equals(Object comparedObject) method.
     *
     * @param comparedObject object to check if the User is equal to
     * @return Returns whether the User is equal to comparedObject
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Override
    public boolean equals(Object comparedObject) {
        // Check if comparedObject is the same User in memory
        if (this == comparedObject) return true;
        // Check if comparedObject is not an User at all
        if (comparedObject == null || getClass() != comparedObject.getClass()) return false;
        // Cast comparedObject as a User and compare each value
        User comparedUser = (User) comparedObject;
        return email.equals(comparedUser.email)
                && password.equals(comparedUser.password)
                && salt.equals(comparedUser.salt)
                && firstName.equals(comparedUser.firstName)
                && lastName.equals(comparedUser.lastName)
                && accountType.equals(comparedUser.accountType)
                && orgName.equals((comparedUser.orgName));
    }
}

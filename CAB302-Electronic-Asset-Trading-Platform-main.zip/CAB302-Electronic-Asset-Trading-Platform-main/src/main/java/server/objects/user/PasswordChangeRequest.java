package server.objects.user;

/**
 * Serverside Java class that creates a User Object required for login and operation of the application.
 *
 * @author Chris Sterkenburg, N10478728
 */
public class PasswordChangeRequest {
    private final String oldPassword;
    private final String newPassword;

    public PasswordChangeRequest(String oldPassword, String newPassword) {
        this.oldPassword = oldPassword;
        this.newPassword = newPassword;
    }

    public String getOldPassword() {
        return oldPassword;
    }

    public String getNewPassword() {
        return newPassword;
    }
}

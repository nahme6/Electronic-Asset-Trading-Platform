package server.objects.user;

/**
 * Enum class for User account type.
 *
 * @author Chris Sterkenburg, N10478728
 */

public enum AccountType {
    Admin,
    Employee
}

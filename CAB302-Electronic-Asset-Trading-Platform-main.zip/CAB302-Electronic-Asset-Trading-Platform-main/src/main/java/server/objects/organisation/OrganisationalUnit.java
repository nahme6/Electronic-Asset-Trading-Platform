package server.objects.organisation;

import org.springframework.lang.Nullable;

import java.util.HashMap;
import java.util.Objects;

/**
 * Serverside Java class that creates a OrganisationalUnit object required for organisational unit of the application.
 *
 * @author Navid Ahmed, N10470433
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
public class OrganisationalUnit {
    private final String orgName;
    private final Integer creditBalance;
    private final HashMap<String, Integer> inventory;

    public OrganisationalUnit(String orgName, Integer creditBalance, @Nullable HashMap<String, Integer> inventory) {
        this.orgName = orgName;
        this.creditBalance = creditBalance;
        this.inventory = inventory;
    }

    public String getOrgName() {
        return orgName;
    }

    public Integer getCreditBalance() {
        return creditBalance;
    }

    public HashMap<String, Integer> getInventory() {
        return inventory;
    }

    /**
     * Compares an OrganisationalUnit to another object and determines if they are the same.
     * Overrides default equals(Object comparedObject) method.
     *
     * @param comparedObject object to check if the OrganisationalUnit is equal to
     * @return Returns whether the OrganisationalUnit is equal to comparedObject
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Override
    public boolean equals(Object comparedObject) {
        // Check if comparedObject is the same trade in memory
        if (this == comparedObject) return true;
        // Check if comparedObject is not an OrganisationalUnit at all
        if (comparedObject == null || getClass() != comparedObject.getClass()) return false;
        // Cast comparedObject as a OrganisationalUnit and compare each value
        OrganisationalUnit comparedOrganisationalUnit = (OrganisationalUnit) comparedObject;
        return orgName.equals(comparedOrganisationalUnit.orgName)
                && creditBalance.equals(comparedOrganisationalUnit.creditBalance)
                && Objects.equals(inventory, comparedOrganisationalUnit.inventory);
    }
}

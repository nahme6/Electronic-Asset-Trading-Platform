package server.objects.trade;

/**
 * Enum type used in Trade class.
 *
 * @author Navid Ahmed, N10470433
 */
public enum OrderType {
    BUY,
    SELL
}

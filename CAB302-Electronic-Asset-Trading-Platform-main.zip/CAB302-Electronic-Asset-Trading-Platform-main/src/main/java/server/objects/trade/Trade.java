package server.objects.trade;

import java.time.LocalDate;

/**
 * Serverside Java class that creates a Trade object required for trades of the application.
 *
 * @author Navid Ahmed, N10470433
 * @author Daniel Taylor, N10492623
 */
public class Trade {
    private final Integer tradeID;
    private final String assetName;
    private final OrderType orderType;
    private final Integer creditPricePerUnit;
    private final Integer quantity;
    private final LocalDate listingDate;
    private final LocalDate resolvedDate;
    private final String orgName;
    private final Boolean isResolved;

    public Trade(Integer tradeID, String assetName, OrderType orderType, Integer creditPricePerUnit, Integer quantity, LocalDate listingDate, LocalDate resolvedDate, String orgName, Boolean isResolved) {
        this.tradeID = tradeID;
        this.assetName = assetName;
        this.orderType = orderType;
        this.creditPricePerUnit = creditPricePerUnit;
        this.quantity = quantity;
        this.listingDate = listingDate;
        this.resolvedDate = resolvedDate;
        this.orgName = orgName;
        this.isResolved = isResolved;
    }

    public Integer getTradeID() {
        return tradeID;
    }

    public String getAssetName() {
        return assetName;
    }

    public OrderType getOrderType() {
        return orderType;
    }

    public Integer getCreditPricePerUnit() {
        return creditPricePerUnit;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public LocalDate getListingDate() {
        return listingDate;
    }

    public LocalDate getResolvedDate() {
        return resolvedDate;
    }

    public String getOrgName() {
        return orgName;
    }

    public Boolean getIsResolved() {
        return isResolved;
    }

    /**
     * Compares a trade to another object and determines if they are the same.
     * Overrides default equals(Object comparedObject) method.
     *
     * @param comparedObject object to check if the trade is equal to
     * @return Returns whether the trade is equal to comparedObject
     * @author Daniel Taylor, N10492623
     */
    @Override
    public boolean equals(Object comparedObject) {
        // Check if comparedObject is the same trade in memory
        if (this == comparedObject) return true;
        // Check if comparedObject is not a trade at all
        if (comparedObject == null || getClass() != comparedObject.getClass()) return false;
        // Cast comparedObject as a trade and compare each value
        Trade comparedTrade = (Trade) comparedObject;
        // Check if either resolvedDate is null and compare based on this check
        if (resolvedDate == null && comparedTrade.resolvedDate == null) {
            // Both resolvedDate are null, so compare only the other values
            return tradeID.equals(comparedTrade.tradeID)
                    && assetName.equals(comparedTrade.assetName)
                    && orderType.equals(comparedTrade.orderType)
                    && creditPricePerUnit.equals(comparedTrade.creditPricePerUnit)
                    && quantity.equals(comparedTrade.quantity)
                    && listingDate.equals(comparedTrade.listingDate)
                    && orgName.equals(comparedTrade.orgName)
                    && isResolved == comparedTrade.isResolved;
        } else if (resolvedDate == null || comparedTrade.resolvedDate == null) {
            // One resolvedDate is null, so return false
            return false;
        } else {
            // Neither resolvedDate is null, so compare all values
            return tradeID.equals(comparedTrade.tradeID)
                    && assetName.equals(comparedTrade.assetName)
                    && orderType.equals(comparedTrade.orderType)
                    && creditPricePerUnit.equals(comparedTrade.creditPricePerUnit)
                    && quantity.equals(comparedTrade.quantity)
                    && listingDate.equals(comparedTrade.listingDate)
                    && resolvedDate.equals(comparedTrade.resolvedDate)
                    && orgName.equals(comparedTrade.orgName)
                    && isResolved == comparedTrade.isResolved;
        }
    }
}

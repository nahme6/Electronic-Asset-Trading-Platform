package server.objects.asset;

import java.time.LocalDate;

/**
 * Serverside Java class that creates a AssetPriceHistory object used within assets of the application.
 *
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
public class AssetPriceHistory {
    private final LocalDate date;
    private final Integer pricePerUnit;

    public AssetPriceHistory(LocalDate date, Integer pricePerUnit) {
        this.date = date;
        this.pricePerUnit = pricePerUnit;
    }

    public LocalDate getDate() {
        return date;
    }

    public Integer getPricePerUnit() {
        return pricePerUnit;
    }

    /**
     * Compares an AssetPriceHistory to another object and determines if they are the same.
     * Overrides default equals(Object comparedObject) method.
     *
     * @param comparedObject object to check if the AssetPriceHistory is equal to
     * @return Returns whether the AssetPriceHistory is equal to comparedObject
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Override
    public boolean equals(Object comparedObject) {
        // Check if comparedObject is the same AssetPriceHistory in memory
        if (this == comparedObject) return true;
        // Check if comparedObject is not an AssetPriceHistory at all
        if (comparedObject == null || getClass() != comparedObject.getClass()) return false;
        // Cast comparedObject as a Asset and compare each value
        AssetPriceHistory comparedAssetPriceHistory = (AssetPriceHistory) comparedObject;
        // Check if either assetPriceHistory is null and compare based on this check
        return date.equals(comparedAssetPriceHistory.date)
                && pricePerUnit.equals(comparedAssetPriceHistory.pricePerUnit);
    }
}
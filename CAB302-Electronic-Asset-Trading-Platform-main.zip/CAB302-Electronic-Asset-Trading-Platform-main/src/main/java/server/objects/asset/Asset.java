package server.objects.asset;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;

/**
 * Serverside Java class that creates a Asset object required for assets of the application.
 *
 * @author Navid Ahmed, N10470433
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
public class Asset {
    private final String assetName;
    private final String assetDescription;
    private final ArrayList<AssetPriceHistory> assetPriceHistory;

    public Asset(String assetName, String assetDescription, @Nullable ArrayList<AssetPriceHistory> assetPriceHistory) {
        this.assetName = assetName;
        this.assetDescription = assetDescription;
        this.assetPriceHistory = assetPriceHistory;
    }

    public String getAssetName() {
        return assetName;
    }

    public String getAssetDescription() {
        return assetDescription;
    }

    public ArrayList<AssetPriceHistory> getAssetPriceHistory() {
        return assetPriceHistory;
    }

    /**
     * Compares an Asset to another object and determines if they are the same.
     * Overrides default equals(Object comparedObject) method.
     *
     * @param comparedObject object to check if the Asset is equal to
     * @return Returns whether the Asset is equal to comparedObject
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Override
    public boolean equals(Object comparedObject) {
        // Check if comparedObject is the same Asset in memory
        if (this == comparedObject) return true;
        // Check if comparedObject is not an Asset at all
        if (comparedObject == null || getClass() != comparedObject.getClass()) return false;
        // Cast comparedObject as a Asset and compare each value
        Asset comparedAsset = (Asset) comparedObject;
        // Check if either assetPriceHistory is null and compare based on this check
        if (assetPriceHistory == null && comparedAsset.assetPriceHistory == null) {
            // Both assetPriceHistory are null, so compare only the other values
            return assetName.equals(comparedAsset.assetName)
                    && assetDescription.equals(comparedAsset.assetDescription);
        } else if (assetPriceHistory == null || comparedAsset.assetPriceHistory == null) {
            // One assetPriceHistory is null, so return false
            return false;
        } else {
            // Neither assetPriceHistory is null, so compare all values
            return assetName.equals(comparedAsset.assetName)
                    && assetDescription.equals(comparedAsset.assetDescription)
                    && assetPriceHistory.equals(comparedAsset.assetPriceHistory);
        }
    }
}

package server.exceptions.users;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception handling for illegal account type values.
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
public class illegalAccountTypeException extends RuntimeException {
    public illegalAccountTypeException(String message) {
        super(message);
    }
}

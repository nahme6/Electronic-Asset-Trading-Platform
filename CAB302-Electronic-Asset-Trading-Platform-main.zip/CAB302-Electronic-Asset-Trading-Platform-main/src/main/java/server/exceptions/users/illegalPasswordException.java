package server.exceptions.users;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception handling for illegal passwords.
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
public class illegalPasswordException extends RuntimeException {
    public illegalPasswordException(String message) {
        super(message);
    }
}

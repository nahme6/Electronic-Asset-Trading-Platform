package server.exceptions.users;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception handling for illegal last names.
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
public class illegalLastNameException extends RuntimeException {
    public illegalLastNameException(String message) {
        super(message);
    }
}

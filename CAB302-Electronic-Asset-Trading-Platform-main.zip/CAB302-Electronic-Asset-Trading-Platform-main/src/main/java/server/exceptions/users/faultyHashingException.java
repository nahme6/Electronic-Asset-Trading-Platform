package server.exceptions.users;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception handling for unknown errors that may occur when hashing a password.
 * @author Daniel Taylor, N10492623
 */
@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
public class faultyHashingException extends RuntimeException {
    public faultyHashingException(String message) {
        super(message);
    }
}
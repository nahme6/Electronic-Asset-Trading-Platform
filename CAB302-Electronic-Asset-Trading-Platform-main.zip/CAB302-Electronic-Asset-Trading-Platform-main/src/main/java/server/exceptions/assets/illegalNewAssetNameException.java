package server.exceptions.assets;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception handling for changing an asset name to an illegal value.
 * @author Daniel Taylor, N10492623
 */
@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
public class illegalNewAssetNameException extends RuntimeException {
    public illegalNewAssetNameException(String errorMessage) {
        super(errorMessage);
    }
}

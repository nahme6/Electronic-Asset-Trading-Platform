package server.exceptions.assets;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception handling for attempting to change an illegal asset name.
 * @author Daniel Taylor, N10492623
 */
@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
public class illegalOldAssetNameException extends RuntimeException {
    public illegalOldAssetNameException(String errorMessage) {
        super(errorMessage);
    }
}

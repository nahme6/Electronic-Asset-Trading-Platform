package server.exceptions.trades;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception handling for non-existent trade IDs.
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
public class nonExistentTradeException extends RuntimeException {
    public nonExistentTradeException(String errorMessage) {
        super(errorMessage);
    }
}

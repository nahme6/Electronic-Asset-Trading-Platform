package server.exceptions.trades;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception handling for manipulating trades that are already resolved.
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
public class illegalManipulateResolvedTradeException extends RuntimeException {
    public illegalManipulateResolvedTradeException(String errorMessage) {
        super(errorMessage);
    }
}

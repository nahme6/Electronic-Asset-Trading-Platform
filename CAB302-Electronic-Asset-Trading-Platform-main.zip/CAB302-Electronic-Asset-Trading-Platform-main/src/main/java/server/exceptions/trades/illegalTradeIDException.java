package server.exceptions.trades;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception handling for illegal trade IDs.
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
public class illegalTradeIDException extends RuntimeException {
    public illegalTradeIDException(String errorMessage) {
        super(errorMessage);
    }
}

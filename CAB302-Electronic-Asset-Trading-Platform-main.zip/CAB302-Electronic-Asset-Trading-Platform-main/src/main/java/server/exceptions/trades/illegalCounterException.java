package server.exceptions.trades;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception handling for illegal counter values.
 * @author Daniel Taylor, N10492623
 */
@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
public class illegalCounterException extends RuntimeException {
    public illegalCounterException(String errorMessage) {
        super(errorMessage);
    }
}

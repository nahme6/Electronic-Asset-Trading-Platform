package server.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception handling for illegal credit values (with boundary dependant on context).
 * @author Daniel Taylor, N10492623
 */
@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
public class illegalCreditsException extends RuntimeException {
    public illegalCreditsException(String errorMessage) {
        super(errorMessage);
    }
}

package server.exceptions.organisationalUnit;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception handling for changing an organisational unit's name to an illegal value.
 * @author Daniel Taylor, N10492623
 */
@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
public class illegalNewOrgNameException extends RuntimeException {
    public illegalNewOrgNameException(String errorMessage) {
        super(errorMessage);
    }
}

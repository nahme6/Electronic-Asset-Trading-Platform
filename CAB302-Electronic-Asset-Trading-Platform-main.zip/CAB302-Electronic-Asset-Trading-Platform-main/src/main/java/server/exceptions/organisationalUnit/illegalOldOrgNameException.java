package server.exceptions.organisationalUnit;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception handling for attempting to change an illegal organisational unit name.
 * @author Daniel Taylor, N10492623
 */
@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
public class illegalOldOrgNameException extends RuntimeException {
    public illegalOldOrgNameException(String errorMessage) {
        super(errorMessage);
    }
}

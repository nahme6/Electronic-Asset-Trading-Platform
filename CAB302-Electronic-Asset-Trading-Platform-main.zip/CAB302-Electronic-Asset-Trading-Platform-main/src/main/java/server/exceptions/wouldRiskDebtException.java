package server.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception handling for method calls that would put an organisational unit into debt, or at risk of falling into
 * debt with their current unresolved trade listings.
 * @author Daniel Taylor, N10492623
 */
@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
public class wouldRiskDebtException extends RuntimeException {
    public wouldRiskDebtException(String errorMessage) {
        super(errorMessage);
    }
}

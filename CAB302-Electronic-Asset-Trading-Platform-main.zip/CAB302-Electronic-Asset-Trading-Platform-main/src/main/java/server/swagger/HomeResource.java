package server.swagger;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Redirects to the Swagger from localhost:8080.
 *
 * @author Nicole Slabbert, N10476130
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@Controller
public class HomeResource {

    /**
     * Method for mapping the swagger doc API to the "/" endpoint on localhost:8080.
     *
     * @return Returns the redirect string url
     * @author Nicole Slabbert, N10476130
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @GetMapping("/")
    public String swaggerUI() {
        return "redirect:/swagger-ui/";
    }
}
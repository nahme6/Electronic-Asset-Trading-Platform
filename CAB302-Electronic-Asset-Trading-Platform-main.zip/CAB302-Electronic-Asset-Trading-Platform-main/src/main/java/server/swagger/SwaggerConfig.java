package server.swagger;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Enables and configures a Swagger for testing and documentation of communications between the client and server.
 *
 * @author Nicole Slabbert, N10476130
 * @author Chris Sterkenburg, N10478728
 * @author Daniel Taylor, N10492623
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig {

    /**
     * Method for building the swagger doc API based on the communication package.
     *
     * @return Returns the build swagger doc API
     * @author Nicole Slabbert, N10476130
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.basePackage("server"))
                .paths(PathSelectors.any())
                .build()
                .apiInfo(apiInfo());
    }

    /**
     * Method for setting the info of the swagger doc API based on the communication package.
     *
     * @return Returns the build swagger doc API
     * @author Nicole Slabbert, N10476130
     * @author Chris Sterkenburg, N10478728
     * @author Daniel Taylor, N10492623
     */
    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("Electronic Asset Trading Platform")
                .description("CAB302 Project")
                .build();
    }
}
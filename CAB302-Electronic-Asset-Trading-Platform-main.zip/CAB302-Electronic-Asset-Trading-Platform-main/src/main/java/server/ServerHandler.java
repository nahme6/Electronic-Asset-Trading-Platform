package server;

import server.database.Database;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import server.managers.TradesManager;

import java.io.*;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Main back-end Java class that handles server startup.
 *
 * @author Daniel Taylor, N10492623
 */
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class ServerHandler {
    /**
     * Main method that handles startup of the server and creation of the database.
     *
     * @author Daniel Taylor, N10492623
     */
    public static void main(String[] args) throws IOException {
        // Initialise SpringBoot
        SpringApplication.run(ServerHandler.class, args);

        // Clear the console and print initialising statement
        clearConsole();
        System.out.println("Initialising EATP server...");

        // Check that the database is ready for use
        System.out.println("Checking database...");
        Database.createNewDatabase(false);

        System.out.println("Complete: EATP server is up and running!");
        // Run resolveTrades method periodically in operation
        Timer timer = new Timer();
        TimerTask resolveTradesTask = new TimerTask() {
            @Override
            public void run() {
                System.out.println("Attempting to resolve pending trades...");
                int resolutions = TradesManager.resolveTrades(0);
                System.out.println("Complete: Resolved " + resolutions + " trades!\n");
            }
        };

        timer.schedule(resolveTradesTask, 0, 1000 * 60 * 5); // Runs every 5 minutes
    }

    /**
     * Helper method for the clearing the console.
     *
     * @author Chris Sterkenburg, N10478728
     */
    private static void clearConsole()
    {
        for(int i = 0; i < 20; i++) {
            System.out.println("\n");
        }
    }
}

// author: Nicole Slabbert, n10476130

import React, { useState, useEffect } from "react";
// react bootstrap components
import { Container, Button, Row, Modal, Form, FormGroup, FormLabel, FormControl, Alert, Col } from "react-bootstrap";
// ag grid imports
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-alpine.css";

// API import from config file
const API_URL = `${process.env.REACT_APP_SERVER_URL}:${process.env.REACT_APP_SERVER_PORT}`;


// function which genertes a list of assets with their inventories for use in creating or editing an organisaitional unit's detials
// will respond dynamically to checkbox selections and current database data
function AssetNamesList(props) {
  const checkItem = (assetName, current) => {
    props.setMasterInventory({
      ...props.masterInventory,
      [assetName]: current === 0 ? 1 : 0,
    });
  }

  const onChange = (assetName, event) => {
    props.setMasterInventory({
      ...props.masterInventory,
      [assetName]: parseInt(event.target.value, 10),
    });
  }

  // map inventory values to seperate form elements and bind related values based on checkbox state
  return (
    <>
      {Object.entries(props.masterInventory).map(([assetName, value]) => (
        <Row key={assetName}>
          <Col>
            <Form.Check type="checkbox" label={assetName} onChange={checkItem.bind(null, assetName, value)} checked={value !== 0} />
          </Col>
          <Col>
            <Form.Control disabled={value === 0} type="number" value={value} onChange={ev => onChange(assetName, ev)} />
          </Col>
        </Row>
      ))}
    </>
  );
}

// function for creating a new organisational unit with a modal display, using the correct API endpoint
function OrgUnitCreation(props) {
  const [creditBalance, setCreditBalance] = useState("");
  const [orgName, setOrgName] = useState("");
  const [masterInventory, setMasterInventory] = useState({});

  const [responseStatus, setResponseStatus] = useState("");
  const [responseMessage, setResponseMessage] = useState("");

  useEffect(() => {
    async function getAssetNames() {
      const response = await fetch(`${API_URL}/assets`);
      const body = await response.json();

      const data = body.reduce((xs, asset) => {
        xs[asset.assetName] = 0;
        return xs;
      }, {});

      setMasterInventory(data);
    }
    getAssetNames();
  }, []);

  const [submissionInventory, setSubmissionInventory] = useState({});
  useEffect(() => {
    if (!masterInventory) {
      return;
    }

    const keyList = Object.keys(masterInventory);

    const acc = {};

    keyList.forEach(key => {
      if (masterInventory[key] !== 0) {
        acc[key] = masterInventory[key];
      }
    })
    setSubmissionInventory(acc);
  }, [masterInventory])

  // function which performs API call to post a new organisational unit
  function addOrgUnit() {
    const newOrgUnit = JSON.stringify({
      creditBalance,
      orgName,
      inventory: submissionInventory,
    });
    const url = `${API_URL}/organisationalUnits`;
    return fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: newOrgUnit,
    })
      .then(async (res) => {
        if (res.status !== 200) {
          throw await res.json();
        }
        setResponseStatus('success');
        props.onHide();
      })
      .catch(err => {
        if (err.message === "The orgName parameter already exists in the organisational_units table.") {
          setResponseMessage("Invalid organisational unit details: Organisation name already exists.");
        }
        else {
          setResponseMessage("Invalid organisational unit details: " + err.message);
        }
        setResponseStatus('danger');
      });
  }

  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          Organisational Unit Creation
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Alert variant={responseStatus}>{responseMessage}</Alert>
        <Form>
          <FormGroup>
            <FormLabel htmlFor="orgName">Name</FormLabel>
            <FormControl
              value={orgName}
              type="text"
              name="orgName"
              id="orgName"
              onChange={(event) => {
                setOrgName(event.target.value);
              }}>
            </ FormControl >
          </FormGroup>

          <FormGroup>
            <FormLabel htmlFor="creditBalance">Credit Balance</FormLabel>
            <FormControl
              value={creditBalance}
              type="number"
              name="creditBalance"
              id="creditBalance"
              onChange={(event) => {
                setCreditBalance(event.target.value);
              }}>
            </ FormControl >
          </FormGroup>

          <Form.Group controlId="exampleForm.ControlSelect1">
            <Form.Label>Assets - Name, Quantity</Form.Label>
            <AssetNamesList masterInventory={masterInventory} setMasterInventory={setMasterInventory} />
          </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button type="submit" onClick={addOrgUnit}>Submit</Button>
      </Modal.Footer>
    </Modal>
  );
}

// function for editing an organisational unit with a modal display, using the correct API endpoint
function OrgUnitEdit(props) {
  const [creditBalance, setCreditBalance] = useState("");
  const [orgName, setOrgName] = useState("");
  const [inventory, setInventory] = useState({});
  const [initialisedInventory, setInitialisedInventory] = useState({});


  const [responseStatus, setResponseStatus] = useState("");
  const [responseMessage, setResponseMessage] = useState("");

  useEffect(() => {
    async function getAssetNames() {
      const response = await fetch(`${API_URL}/assets`);
      const body = await response.json();

      const data = body.reduce((xs, asset) => {
        xs[asset.assetName] = 0;
        return xs;
      }, {});

      setInventory(data);
    }
    getAssetNames();
  }, []);

  // function which initialised values to fill the modal with corresponding values of the selected organisational unit
  function InitialiseValuesOrg(props) {
    const orgName = props.orgName;
    useEffect(() => {
      async function getOrgInfo() {
        const response = await fetch(`${API_URL}/organisationalUnits/${orgName}`);
        const body = await response.json();
        setOrgName(body.orgName);
        setCreditBalance(body.creditBalance);
        setInitialisedInventory(body.inventory);
      }
      getOrgInfo();
    }, [orgName]);
  }

  // combine list of all assets with inventory state for the required organisational unit
  const [masterInventory, setMasterInventory] = useState({});
  useEffect(() => {
    if (!inventory || !initialisedInventory) {
      return;
    }

    const keyList = new Set([...Object.keys(inventory), ...Object.keys(initialisedInventory)]);

    const acc = {};

    keyList.forEach(key => {
      acc[key] = (inventory[key] ?? 0) + (initialisedInventory[key] ?? 0);
    })
    setMasterInventory(acc);
  }, [inventory, initialisedInventory])

  // don't submit empty inventory fields as apart of the inventory object, create new list which excludes 0 values
  const [submissionInventory, setSubmissionInventory] = useState({});
  useEffect(() => {
    if (!masterInventory) {
      return;
    }

    const keyList = Object.keys(masterInventory);

    const acc = {};

    keyList.forEach(key => {
      if (masterInventory[key] !== 0) {
        acc[key] = masterInventory[key];
      }
    })
    setSubmissionInventory(acc);
  }, [masterInventory])

  // function which makes API call to edit an organisaitonal unit's details
  function editOrgUnit(props) {
    const orgNameURL = props.orgName;

    console.log(orgName);
    const newOrgUnit = JSON.stringify({
      creditBalance,
      orgName,
      inventory: submissionInventory,
    });
    const url = `${API_URL}/organisationalUnits/edit/${orgNameURL}`;
    return fetch(url, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: newOrgUnit,
    })
      .then(async (res) => {
        if (res.status !== 200) {
          throw await res.json();
        }
        setResponseStatus('success');
        props.onHide();
      })
      .catch(err => {
        if (err.message === "The oldOrgName parameter is the default organisational unit.") {
          setResponseMessage("Cannot edit name of IT Administration organisational unit");
        }
        else {
          setResponseMessage("Invalid organisational unit details");
        }
        setResponseStatus('danger');
      });
  }

  // function wich makes API call to delete an organisational unit from the database
  function deleteOrgUnit(props) {
    const orgNameURL = props.orgName;

    const url = `${API_URL}/organisationalUnits/${orgNameURL}`;
    return fetch(url, {
      method: "DELETE",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      }
    })
      .then(async (res) => {
        if (res.status !== 200) {
          throw await res.json();
        }
        setResponseStatus('success');
        props.onHide();
      })
      .catch(err => {
        if (err.message === "The orgName parameter has inventory.") {
          setResponseMessage("Cannot delete an organisational unit that has inventory assigned to it");
        }
        else if (err.message === "The orgName parameter has users") {
          setResponseMessage("Cannot delete an organisational unit that has users assigned to it")
        }
        else {
          setResponseMessage("Invalid organisational unit details");
        }
        setResponseStatus('danger');
      });
  }

  // initialise values to fill modal with
  InitialiseValuesOrg(props);

  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          Organisational Unit Edits
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Alert variant={responseStatus}>{responseMessage}</Alert>
        <Form>
          <FormGroup>
            <FormLabel htmlFor="orgName">Name</FormLabel>
            <FormControl
              value={orgName}
              type="text"
              name="orgName"
              id="orgName"
              onChange={(event) => {
                setOrgName(event.target.value);
              }}>
            </ FormControl >
          </FormGroup>

          <FormGroup>
            <FormLabel htmlFor="creditBalance">Credit Balance</FormLabel>
            <FormControl
              value={creditBalance}
              type="number"
              name="creditBalance"
              id="creditBalance"
              onChange={(event) => {
                setCreditBalance(event.target.value);
              }}>
            </ FormControl >
          </FormGroup>

          <Form.Group controlId="exampleForm.ControlSelect1">
            <Form.Label>Assets - Name, Quantity</Form.Label>
            <AssetNamesList masterInventory={masterInventory} setMasterInventory={setMasterInventory} />
          </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button type="submit" onClick={() => deleteOrgUnit(props)}>Delete</Button>
        <Button type="submit" onClick={() => editOrgUnit(props)}>Submit</Button>
      </Modal.Footer>
    </Modal>
  );
}

// function for creating a new user with a modal display, using the correct API endpoint
function UserCreation(props) {
  const accountTypes = ["Employee", "Admin"];

  const [accountType, setAccountType] = useState(accountTypes[0]);
  const [email, setEmail] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [orgName, setOrgName] = useState("IT Administration");
  const [password, setPassword] = useState("");

  const [responseStatus, setResponseStatus] = useState("");
  const [responseMessage, setResponseMessage] = useState("");

  // function which generates a dropdown select list of all organisational units within the company
  function OrgNameDropdown() {
    const [items, setItems] = useState([]);

    useEffect(() => {
      async function getOrgNames() {
        const response = await fetch(`${API_URL}/organisationalUnits`);
        const body = await response.json();
        const orgs = body.map(({ orgName }) => ({ label: orgName, value: orgName }));
        setItems(orgs);
        setOrgName(orgs[0].value);
      }
      getOrgNames();
    }, []);

    return (
      <>
        {items.map(({ label, value }) => (
          <option key={value} value={value}>
            {label}
          </option>
        ))}
      </>
    );
  }

  // function which makes API call to add a user to the database
  function addUser() {
    const newUser = JSON.stringify({
      accountType: accountType,
      email: email,
      firstName: firstName,
      lastName: lastName,
      orgName: orgName,
      password: password
    });
    const url = `${API_URL}/users`;
    return fetch(url, {
      method: "POST",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      },
      body: newUser,
    })
      .then(async (res) => {
        if (res.status !== 200) {
          throw await res.json();
        }
        setResponseStatus('success');
        props.onHide();
      })
      .catch(err => {
        if (err.message === "The email parameter does not meet the database constraints.") {
          setResponseMessage("Invalid user email");
        }
        else {
          setResponseMessage("Invalid user details");
        }
        setResponseStatus('danger');
      });
  }


  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          User Creation
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Alert variant={responseStatus}>{responseMessage}</Alert>
        <Form>
          <FormGroup>
            <FormLabel for="firstName">First Name</FormLabel>
            <FormControl
              value={firstName}
              type="text"
              name="firstName"
              id="firstName"
              placeholder="insert first name"
              onChange={(event) => {
                setFirstName(event.target.value);
              }}
            />
          </FormGroup>

          <FormGroup>
            <FormLabel for="lastName">Last Name</FormLabel>
            <FormControl
              value={lastName}
              type="text"
              name="lastName"
              id="lastName"
              placeholder="insert last name"
              onChange={(event) => {
                setLastName(event.target.value);
              }}
            />
          </FormGroup>

          <FormGroup>
            <FormLabel for="email">Email</FormLabel>
            <FormControl
              value={email}
              type="text"
              name="email"
              id="email"
              placeholder="insert email"
              onChange={(event) => {
                setEmail(event.target.value);
              }}
            />
          </FormGroup>

          <FormGroup>
            <FormLabel for="accountType">Account Type</FormLabel>
            <FormControl
              value={accountType}
              as="select"
              name="accountType"
              id="accountType"
              placeholder="insert account type"
              onChange={(event) => {
                setAccountType(event.target.value);
              }}
            >
              {accountTypes.map(x => (
                <option key={x}>{x}</option>
              ))}
            </FormControl>
          </FormGroup>

          <FormGroup>
            <FormLabel for="password">Password</FormLabel>
            <FormControl
              value={password}
              type="text"
              name="password"
              id="password"
              placeholder="insert password"
              onChange={(event) => {
                setPassword(event.target.value);
              }}
            />
          </FormGroup>

          <FormGroup>
            <FormLabel for="orgName">Organisational Unit</FormLabel>
            <FormControl
              value={orgName}
              as="select"
              name="orgName"
              id="orgName"
              onChange={(event) => {
                setOrgName(event.target.value);
              }}>
              {OrgNameDropdown()}
            </ FormControl >
          </FormGroup>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button type="submit" onClick={addUser}>Submit</Button>
      </Modal.Footer>
    </Modal>
  );
}

// function for editiing a user with a modal display, using the correct API endpoint
function UserEdit(props) {
  const accountTypes = ["Employee", "Admin"];

  const [accountType, setAccountType] = useState(accountTypes[0]);
  const [email, setEmail] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [orgName, setOrgName] = useState("IT Administration");
  const [password, setPassword] = useState("");

  const [responseStatus, setResponseStatus] = useState("");
  const [responseMessage, setResponseMessage] = useState("");

  function InitialiseValuesUser(props) {
    const email = props.email;
    useEffect(() => {
      async function getUserInfo() {
        const response = await fetch(`${API_URL}/users/${email}`);
        const body = await response.json();
        setEmail(body.email);
        setAccountType(body.accountType);
        setFirstName(body.firstName);
        setLastName(body.lastName);
        setOrgName(body.orgName);
        setPassword(body.password);
      }
      getUserInfo();
    }, [email]);
  }

  // function which generates a dropdown select list of all organisational units within the company
  function OrgNameDropdown() {
    const [items, setItems] = useState([]);

    useEffect(() => {
      async function getOrgNames() {
        const response = await fetch(`${API_URL}/organisationalUnits`);
        const body = await response.json();
        const orgs = body.map(({ orgName }) => ({ label: orgName, value: orgName }));
        setItems(orgs);
        setOrgName(orgs[0].value);
      }
      getOrgNames();
    }, []);

    return (
      <>
        {items.map(({ label, value }) => (
          <option key={value} value={value}>
            {label}
          </option>
        ))}
      </>
    );
  }

  // function which makes API call to edit a user's details in the database
  function editUser(props) {
    const emailURL = props.email;

    const newUser = JSON.stringify({
      accountType: accountType,
      email: email,
      firstName: firstName,
      lastName: lastName,
      orgName: orgName
    });
    const url = `${API_URL}/users/edit/${emailURL}`;
    return fetch(url, {
      method: "PUT",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      },
      body: newUser,
    })
      .then(async (res) => {
        if (res.status !== 200) {
          throw await res.json();
        }
        setResponseStatus('success');
        props.onHide();
      })
      .catch(err => {
        if (err.message === "The email parameter does not meet the database constraints.") {
          setResponseMessage("Invalid user email");
        }
        else if (err.message === "The oldEmail parameter is the default user.") {
          setResponseMessage("Cannot edit details of master");
        }
        else {
          setResponseMessage("Invalid user details");
        }
        setResponseStatus('danger');
      });
  }

  // function which makes API call to delete a user from the database
  function deleteUser(props) {
    const emailURL = props.email;

    const url = `${API_URL}/users/${emailURL}`;
    return fetch(url, {
      method: "DELETE",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      }
    })
      .then(async (res) => {
        if (res.status !== 200) {
          throw await res.json();
        }
        setResponseStatus('success');
        props.onHide();
      })
      .catch(err => {
        if (err.message === "The email parameter does not meet the database constraints.") {
          setResponseMessage("Invalid user email");
        }
        else {
          setResponseMessage("Invalid user details");
        }
        setResponseStatus('danger');
      });
  }

  // intialise values to fill the database with
  InitialiseValuesUser(props);

  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          User Edit
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Alert variant={responseStatus}>{responseMessage}</Alert>
        <Form>
          <FormGroup>
            <FormLabel for="firstName">First Name</FormLabel>
            <FormControl
              value={firstName}
              type="text"
              name="firstName"
              id="firstName"
              placeholder="insert first name"
              onChange={(event) => {
                setFirstName(event.target.value);
              }}
            />
          </FormGroup>

          <FormGroup>
            <FormLabel for="lastName">Last Name</FormLabel>
            <FormControl
              value={lastName}
              type="text"
              name="lastName"
              id="lastName"
              placeholder="insert last name"
              onChange={(event) => {
                setLastName(event.target.value);
              }}
            />
          </FormGroup>

          <FormGroup>
            <FormLabel for="email">Email</FormLabel>
            <FormControl
              value={email}
              type="text"
              name="email"
              id="email"
              placeholder="insert email"
              onChange={(event) => {
                setEmail(event.target.value);
              }}
            />
          </FormGroup>

          <FormGroup>
            <FormLabel for="accountType">Account Type</FormLabel>
            <FormControl
              value={accountType}
              as="select"
              name="accountType"
              id="accountType"
              placeholder="insert account type"
              onChange={(event) => {
                setAccountType(event.target.value);
              }}
            >
              {accountTypes.map(x => (
                <option key={x}>{x}</option>
              ))}
            </FormControl>
          </FormGroup>

          <FormGroup hidden>
            <FormLabel for="password">Password</FormLabel>
            <FormControl
              value={password}
              type="text"
              name="password"
              id="password"
              placeholder="insert password"
              onChange={(event) => {
                setPassword(event.target.value);
              }}
            />
          </FormGroup>

          <FormGroup>
            <FormLabel for="orgName">Organisational Unit</FormLabel>
            <FormControl
              value={orgName}
              as="select"
              name="orgName"
              id="orgName"
              onChange={(event) => {
                setOrgName(event.target.value);
              }}>
              {OrgNameDropdown()}
            </ FormControl >
          </FormGroup>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button type="submit" onClick={() => deleteUser(props)}>Delete</Button>
        <Button type="submit" onClick={() => editUser(props)}>Submit</Button>
      </Modal.Footer>
    </Modal>
  );
}

// function for creating a new asset with a modal display, using the correct API endpoint
function AssetCreation(props) {
  const [assetName, setAssetName] = useState("");
  const [assetDescription, setAssetDescription] = useState("");
  const [responseStatus, setResponseStatus] = useState("");
  const [responseMessage, setResponseMessage] = useState("");

  // function which makes API call to add a new asset to the database
  function addAsset() {
    const newAsset = JSON.stringify({
      assetName: assetName,
      assetDescription: assetDescription
    });
    const url = `${API_URL}/assets`;
    return fetch(url, {
      method: "POST",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      },
      body: newAsset,
    })
      .then(async (res) => {
        if (res.status !== 200) {
          throw await res.json();
        }
        setResponseStatus('success');
        props.onHide();
      })
      .catch(err => {
        if (err.message === "The assetName parameter already exists in the assets table.") {
          setResponseMessage("Invalid asset details: Asset already exists");
        }
        else {
          setResponseMessage("Invalid asset details");
        }
        setResponseStatus('danger');
      });
  }

  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          Asset Creation
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Alert variant={responseStatus}>{responseMessage}</Alert>
        <Form>
          <FormGroup>
            <FormLabel for="assetName">Asset Name</FormLabel>
            <FormControl
              value={assetName}
              type="text"
              name="assetName"
              id="assetName"
              placeholder="insert asset name"
              onChange={(event) => {
                setAssetName(event.target.value);
              }}
            />
          </FormGroup>
          <FormGroup>
            <FormLabel for="assetDescription">Asset Description</FormLabel>
            <FormControl
              value={assetDescription}
              type="textareas"
              name="assetDescription"
              id="assetDescription"
              placeholder="insert asset name"
              onChange={(event) => {
                setAssetDescription(event.target.value);
              }}
            />
          </FormGroup>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button type="submit" onClick={addAsset}>Submit</Button>
      </Modal.Footer>
    </Modal>
  );
}

// function for editiing an asset with a modal display, using the correct API endpoint
function AssetEdit(props) {
  const [assetName, setAssetName] = useState("");
  const [assetDescription, setAssetDescription] = useState("");
  const [responseStatus, setResponseStatus] = useState("");
  const [responseMessage, setResponseMessage] = useState("");

  // function which initialises values to fill the editing modal with based on select asset
  function InitialiseValuesAsset(props) {
    const assetName = props.assetName;
    useEffect(() => {
      async function getAssetInfo() {
        const response = await fetch(`${API_URL}/assets/${assetName}`);
        const body = await response.json();
        console.log(body);
        setAssetName(body.assetName);
        setAssetDescription(body.assetDescription);
      }
      getAssetInfo();
    }, [assetName]);
  }

  // function which makes API call to edit an asset's details in the database
  function editAsset(props) {
    const newAsset = JSON.stringify({
      assetName: assetName,
      assetDescription: assetDescription
    });
    const assetNameParam = props.assetName;
    const url = `${API_URL}/assets/edit/${assetNameParam}`;
    return fetch(url, {
      method: "PUT",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      },
      body: newAsset,
    })
      .then(async (res) => {
        if (res.status !== 200) {
          throw await res.json();
        }
        setResponseStatus('success');
        props.onHide();
      })
      .catch(err => {
        setResponseMessage("Invalid asset details");
        setResponseStatus('danger');
      });
  }

  // function which makes API call to delete an asset from the database
  function deleteAsset(props) {
    const assetNameParam = props.assetName;
    const url = `${API_URL}/assets/${assetNameParam}`;
    return fetch(url, {
      method: "DELETE",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      }
    })
      .then(async (res) => {
        if (res.status !== 200) {
          throw await res.json();
        }
        setResponseStatus('success');
        props.onHide();
      })
      .catch(err => {
        if (err.message === "The assetName parameter is in inventory") {
          setResponseMessage("Cannot delete an asset that has been used by orgnanisational units in the company");
        }
        else {
          setResponseMessage("Invalid asset details");
        }
        setResponseStatus('danger');
      });
  }

  // intialise values to fill the modal with
  InitialiseValuesAsset(props);

  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          Asset Edit
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Alert variant={responseStatus}>{responseMessage}</Alert>
        <Form>
          <FormGroup>
            <FormLabel for="assetName">Asset Name</FormLabel>
            <FormControl
              value={assetName}
              type="text"
              name="assetName"
              id="assetName"
              placeholder="insert task name"
              onChange={(event) => {
                setAssetName(event.target.value);
              }}
            />
          </FormGroup>
          <FormGroup>
            <FormLabel for="assetDescription">Asset Description</FormLabel>
            <FormControl
              value={assetDescription}
              type="textareas"
              name="assetDescription"
              id="assetDescription"
              placeholder="insert task name"
              onChange={(event) => {
                setAssetDescription(event.target.value);
              }}
            />
          </FormGroup>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button type="submit" onClick={() => deleteAsset(props)}>Delete Asset</Button>
        <Button type="submit" onClick={() => editAsset(props)}>Submit</Button>
      </Modal.Footer>
    </Modal>
  );
}

// main export function which displays all admin portal components in the correct order
export default function AdminPortal() {
  const [orgUnitCreationModalShow, setOrgUnitCreationModalShow] = useState(false);
  const [orgUnitEditModalShow, setOrgUnitEditModalShow] = useState(false);
  const [userCreationModalShow, setUserCreationModalShow] = useState(false);
  const [userEditModalShow, setUserEditModalShow] = useState(false);
  const [assetCreationModalShow, setAssetCreationModalShow] = useState(false);
  const [assetEditModalShow, setAssetEditModalShow] = useState(false);

  const [eventTargetOrgName, setEventTargetOrgName] = useState("");
  const [eventTargetEmail, setEventTargetEmail] = useState("");
  const [eventTargetAssetName, setEventTargetAssetName] = useState("");
  
  // function which creates a table display information of all users in the database, using API call to populate it
  function UserTable() {
    const [rowData, setRowData] = useState([]);

    const columns = [
      { headerName: "NAME", field: "name", sortable: true, filter: true },
      { headerName: "EMAIL", field: "email", sortable: true, filter: "agNumberColumnFilter", width: "300" },
      { headerName: "ORGANISATIONAL UNIT", field: "orgUnit", filter: true, sortable: true, width: "250" },
      { headerName: "ACCOUNT TYPE", field: "accountType", filter: true, sortable: true },
    ];

    const url = `${API_URL}/users`;

    useEffect(() => {
      fetch(url)
        .then(res => res.json())
        .then(data =>
          data.map(user => {
            return {
              name: user.firstName + " " + user.lastName,
              email: user.email,
              orgUnit: user.orgName,
              accountType: user.accountType
            };
          })
        )
        .then(users => setRowData(users));
    }, [url]);

    return (
      <div className="ag-theme-alpine" style={{ width: "88.1%", height: "518.8px", marginTop: "20px" }}>
        <AgGridReact
          rowSelection="single"
          onRowSelected={OnUserRowSelected}
          columnDefs={columns}
          rowData={rowData}
          pagination={true}
          paginationPageSize={10}
        />
      </div>
    )
  }

  // function which creates a table display information of all assets in the database, using API call to populate it
  function AssetTable() {
    const [rowData, setRowData] = useState([]);

    const columns = [
      { headerName: "NAME", field: "assetName", sortable: true, filter: true, width: 200 },
      { headerName: "DESCRIPTION", field: "description", sortable: true, filter: true, width: 800 },
    ];

    const url = `${API_URL}/assets`;

    useEffect(() => {
      fetch(url)
        .then(res => res.json())
        .then(data =>
          data.map(asset => {
            return {
              assetName: asset.assetName,
              description: asset.assetDescription,
            };
          })
        )
        .then(assets => setRowData(assets));
    }, [url]);

    return (
      <div className="ag-theme-alpine" style={{ width: "88.1%", height: "518.8px", marginTop: "20px" }}>
        <AgGridReact
          rowSelection="single"
          onRowSelected={OnAssetRowSelected}
          columnDefs={columns}
          rowData={rowData}
          pagination={true}
          paginationPageSize={10}
        />
      </div>
    )
  }

  // function which creates a table display information of all organisational units in the database, using API call to populate it
  function OrganisationalUnitTable() {
    const [rowData, setRowData] = useState([]);

    const columns = [
      { headerName: "NAME", field: "orgName", sortable: true, filter: true, width: 500 },
      { headerName: "CREDIT BALANCE", field: "creditBalance", sortable: true, filter: "agNumberColumnFilter", width: 495 },
    ];

    const url = `${API_URL}/organisationalUnits`;

    useEffect(() => {
      fetch(url)
        .then(res => res.json())
        .then(data =>
          data.map(orgUnit => {
            return {
              orgName: orgUnit.orgName,
              creditBalance: orgUnit.creditBalance,
            };
          })
        )
        .then(orgUnits => setRowData(orgUnits));
    }, [url]);


    return (
      <div className="ag-theme-alpine" style={{ width: "88.1%", height: "518.8px", marginTop: "20px" }}>
        <AgGridReact
          rowSelection="single"
          onRowSelected={OnOrgRowSelected}
          columnDefs={columns}
          rowData={rowData}
          pagination={true}
          paginationPageSize={10}
        />
      </div>
    )
  }

  // function which reacts to the event of a row in the organisational units table being selected
  function OnOrgRowSelected(event) {
    setOrgUnitEditModalShow(true);
    setEventTargetOrgName(event.node.data.orgName);
  }

  // function which reacts to the event of a row in the users table being selected
  function OnUserRowSelected(event) {
    setUserEditModalShow(true);
    setEventTargetEmail(event.node.data.email);
  }

  // function which reacts to the event of a row in the assets table being selected
  function OnAssetRowSelected(event) {
    setAssetEditModalShow(true);
    setEventTargetAssetName(event.node.data.assetName)
  }

  return (
    <div>
      <Container className="pt-5">
        <Row className="justify-content-md-center section-title">
          <h1>Administration Portal</h1>
        </Row>

        <Row className="section-subtitle">
          <h4>Organisational Units:</h4>
        </Row>

        <Row className="justify-content-md-center">
          <OrganisationalUnitTable />
        </Row>

        <Row className="justify-content-md-center modal-button">
          <Button variant="primary" onClick={() => setOrgUnitCreationModalShow(true)}>
            Add Organisational Unit
          </Button>
        </Row>

        <Row className="section-subtitle">
          <h4>Users:</h4>
        </Row>

        <Row className="justify-content-md-center">
          <UserTable />
        </Row>

        <Row className="justify-content-md-center modal-button">
          <Button variant="primary" onClick={() => setUserCreationModalShow(true)}  >
            Add User
          </Button>
        </Row>

        <Row className="section-subtitle">
          <h4>Assets:</h4>
        </Row>

        <Row className="justify-content-md-center">
          <AssetTable />
        </Row>

        <Row className="justify-content-md-center modal-button">
          <Button variant="primary" onClick={() => setAssetCreationModalShow(true)}>
            Add Asset
          </Button>
        </Row>

        <OrgUnitCreation
          show={orgUnitCreationModalShow}
          onHide={() => { setOrgUnitCreationModalShow(false); window.location.href = "/admin_portal"; }}
        />

        <OrgUnitEdit
          show={orgUnitEditModalShow}
          onHide={() => { setOrgUnitEditModalShow(false); window.location.href = "/admin_portal"; }}
          orgName={eventTargetOrgName}
        />

        <UserCreation
          show={userCreationModalShow}
          onHide={() => { setUserCreationModalShow(false); window.location.href = "/admin_portal"; }}
        />

        <UserEdit
          show={userEditModalShow}
          onHide={() => { setUserEditModalShow(false); window.location.href = "/admin_portal"; }}
          email={eventTargetEmail}
        />

        <AssetCreation
          show={assetCreationModalShow}
          onHide={() => { setAssetCreationModalShow(false); window.location.href = "/admin_portal"; }}
        />

        <AssetEdit
          show={assetEditModalShow}
          onHide={() => { setAssetEditModalShow(false); window.location.href = "/admin_portal"; }}
          assetName={eventTargetAssetName}
        />

      </Container>
    </div>
  );
}

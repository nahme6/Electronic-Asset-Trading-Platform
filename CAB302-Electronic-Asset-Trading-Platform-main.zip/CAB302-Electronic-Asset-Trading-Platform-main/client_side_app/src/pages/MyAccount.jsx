// author: Nicole Slabbert, n10476130

import React, { useState, useEffect } from "react";
// react bootstrap compoments
import { Container, Button, Row, Modal, Form, FormGroup, FormLabel, FormControl, Alert, Col } from "react-bootstrap";

// API import from config file
const API_URL = `${process.env.REACT_APP_SERVER_URL}:${process.env.REACT_APP_SERVER_PORT}`;

// function for editiing a user with a modal display, using the correct API endpoint
function EditUser(props) {
  const accountTypes = ["Employee", "Admin"];

  const [accountType, setAccountType] = useState(accountTypes[0]);
  const [email, setEmail] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [orgName, setOrgName] = useState("IT Administration");
  const [password, setPassword] = useState("");

  const [responseStatus, setResponseStatus] = useState("");
  const [responseMessage, setResponseMessage] = useState("");

  // function which initialises user detail values based on the user that is currently logged in
  function InitialiseValues(props) {
    const email = props.email;
    useEffect(() => {
      async function getUserInfo() {
        const response = await fetch(`${API_URL}/users/${email}`);
        const body = await response.json();
        setEmail(body.email);
        setAccountType(body.accountType);
        setFirstName(body.firstName);
        setLastName(body.lastName);
        setOrgName(body.orgName);
        setPassword(body.password);
      }
      getUserInfo();
    }, [email]);
  }

  // function which generates a dropdown select list of all organisational units within the company
  function OrgNameDropdown() {
    const [items, setItems] = useState([]);

    useEffect(() => {
      async function getOrgNames() {
        const response = await fetch(`${API_URL}/organisationalUnits`);
        const body = await response.json();
        const orgs = body.map(({ orgName }) => ({ label: orgName, value: orgName }));
        setItems(orgs);
        setOrgName(orgs[0].value);
      }
      getOrgNames();
    }, []);

    return (
      <>
        {items.map(({ label, value }) => (
          <option key={value} value={value}>
            {label}
          </option>
        ))}
      </>
    );
  }

  // function which makes API call to edit a user in the database
  function editUser(props) {
    const emailURL = props.email;

    const newUser = JSON.stringify({
      accountType: accountType,
      email: email,
      firstName: firstName,
      lastName: lastName,
      orgName: orgName
    });
    const url = `${API_URL}/users/edit/${emailURL}`;
    return fetch(url, {
      method: "PUT",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      },
      body: newUser,
    })
      .then(async (res) => {
        if (res.status !== 200) {
          throw await res.json();
        }
        setResponseStatus('success');
        props.onHide();
        // log user out if their email address is changed as that will disable their web token
        if (emailURL !== email) {
          window.location.href = '/logout';
        }
      })
      .catch(err => {
        if (err.message === "The newEmail parameter already exists in the user_accounts table.") {
          setResponseMessage("Email already exists");
        }
        else if (err.message === "The oldEmail parameter is the default user.") {
          setResponseMessage("Cannot edit details of default user");
        }
        else {
          setResponseMessage("Invalid user details");
        }
        setResponseStatus('danger');
      });
  }

  // intialise values to fill modal with
  InitialiseValues(props);

  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          User Edit
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Alert variant={responseStatus}>{responseMessage}</Alert>
        <Form>
          <FormGroup>
            <FormLabel for="firstName">First Name</FormLabel>
            <FormControl
              value={firstName}
              type="text"
              name="firstName"
              id="firstName"
              placeholder="insert first name"
              onChange={(event) => {
                setFirstName(event.target.value);
              }}
            />
          </FormGroup>

          <FormGroup>
            <FormLabel for="lastName">Last Name</FormLabel>
            <FormControl
              value={lastName}
              type="text"
              name="lastName"
              id="lastName"
              placeholder="insert last name"
              onChange={(event) => {
                setLastName(event.target.value);
              }}
            />
          </FormGroup>

          <FormGroup>
            <FormLabel for="email">Email</FormLabel>
            <FormControl
              value={email}
              type="text"
              name="email"
              id="email"
              placeholder="insert email"
              onChange={(event) => {
                setEmail(event.target.value);
              }}
            />
          </FormGroup>

          <FormGroup hidden>
            <FormLabel for="accountType">Account Type</FormLabel>
            <FormControl
              value={accountType}
              as="select"
              name="accountType"
              id="accountType"
              placeholder="insert account type"
              onChange={(event) => {
                setAccountType(event.target.value);
              }}
            >
              {accountTypes.map(x => (
                <option key={x}>{x}</option>
              ))}
            </FormControl>
          </FormGroup>

          <FormGroup hidden>
            <FormLabel for="password">Password</FormLabel>
            <FormControl
              value={password}
              type="text"
              name="password"
              id="password"
              placeholder="insert password"
              onChange={(event) => {
                setPassword(event.target.value);
              }}
            />
          </FormGroup>

          <FormGroup hidden>
            <FormLabel for="orgName">Organisational Unit</FormLabel>
            <FormControl
              value={orgName}
              as="select"
              name="orgName"
              id="orgName"
              onChange={(event) => {
                setOrgName(event.target.value);
              }}>
              {OrgNameDropdown()}
            </ FormControl >
          </FormGroup>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button type="submit" onClick={() => editUser(props)}>Submit</Button>
      </Modal.Footer>
    </Modal>
  );
}

// function for editiing a user password with a modal display, using the correct API endpoint
function EditPassword(props) {
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [responseStatus, setResponseStatus] = useState("");
  const [responseMessage, setResponseMessage] = useState("");

  // function which makes API call to change a user's password
  function changePassword(props) {
    const email = props.email;

    if (newPassword !== confirmPassword) {
      setResponseMessage("Passwords don't match");
      setResponseStatus("danger");
      return;
    }

    const change = JSON.stringify({
      oldPassword: oldPassword,
      newPassword: newPassword
    });
    const url = `${API_URL}/users/edit/password/${email}`;
    return fetch(url, {
      method: "PUT",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      },
      body: change,
    })
      .then(async (res) => {
        if (res.status !== 200) {
          throw await res.json();
        }
        setResponseStatus('success');
        props.onHide();
      })
      .catch(err => {
        if (err.message === "The oldPassword parameter does not match the expected value.") {
          setResponseMessage("Incorrect old password entry");
        }
        else if (err.message === "The oldEmail parameter is the default user.") {
          setResponseMessage("Cannot edit details of default user");
        }
        else {
          setResponseMessage("Invalid password details");
        }
        setResponseStatus('danger');
      });
  }

  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          Change Password
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Alert variant={responseStatus}>{responseMessage}</Alert>
        <Form>
          <FormGroup>
            <FormLabel for="oldPassword">Old Password</FormLabel>
            <FormControl
              value={oldPassword}
              type="password"
              name="oldPassword"
              id="oldPassword"
              placeholder="insert old password"
              onChange={(event) => {
                setOldPassword(event.target.value);
              }}
            />
          </FormGroup>

          <FormGroup>
            <FormLabel for="newPassword">New Password</FormLabel>
            <FormControl
              value={newPassword}
              type="password"
              name="newPassword"
              id="newPassword"
              placeholder="insert new password"
              onChange={(event) => {
                setNewPassword(event.target.value);
              }}
            />
          </FormGroup>

          <FormGroup>
            <FormLabel for="confirmPassword">Confirm Password</FormLabel>
            <FormControl
              value={confirmPassword}
              type="password"
              name="confirmPassword"
              id="confirmPassword"
              placeholder="confirm new password"
              onChange={(event) => {
                setConfirmPassword(event.target.value);
              }}
            />
          </FormGroup>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button type="submit" onClick={() => changePassword(props)}>Change Password</Button>
      </Modal.Footer>
    </Modal>
  );
}

// main export function which displays all my account components in the correct order
export default function MyAccount({ user }) {
  const [userDetailsEditModalShow, setUserDetailsEditModalShow] = useState(false);
  const [changePasswordModalShow, setChangePasswordModalShow] = useState(false);

  return (
    <Container className="pt-5">
      <Row className="justify-content-md-center section-title">
        <h1>Account Details</h1>
      </Row>
      <Form>
        <hr></hr>
        <Form.Group controlId="formGridEmail">
          <Form.Label>Email</Form.Label>
          <Form.Control type="email" placeholder={user.email} disabled />
        </Form.Group>
        <Form.Row>
          <Form.Group as={Col} controlId="formGridEmail">
            <Form.Label>First Name</Form.Label>
            <Form.Control placeholder={user.firstName} disabled />
          </Form.Group>

          <Form.Group as={Col} controlId="formGridPassword">
            <Form.Label>Last Name</Form.Label>
            <Form.Control placeholder={user.lastName} disabled />
          </Form.Group>
        </Form.Row>

        <Row className="justify-content-end">
          <Button variant="primary" type="button" style={{ marginRight: "15px" }} onClick={() => setUserDetailsEditModalShow(true)}>
            Edit Details
          </Button>
        </Row>
        <hr></hr>
        <Form.Group controlId="formGridEmail">
          <Form.Label>Organisational Unit</Form.Label>
          <Form.Control placeholder={user.orgName} disabled />
        </Form.Group>
      </Form>
      <hr></hr>
      <Row className="justify-content-center">
        <Button variant="primary" type="button" style={{ marginRight: "15px" }} onClick={() => setChangePasswordModalShow(true)}>
          Change Password
  </Button>
      </Row>

      <EditUser
        show={userDetailsEditModalShow}
        onHide={() => { setUserDetailsEditModalShow(false); window.location.href = "/my_account"; }}
        email={user.email}
      />

      <EditPassword
        show={changePasswordModalShow}
        onHide={() => { setChangePasswordModalShow(false); window.location.href = "/my_account"; }}
        email={user.email}
      />
    </Container>
  );
}
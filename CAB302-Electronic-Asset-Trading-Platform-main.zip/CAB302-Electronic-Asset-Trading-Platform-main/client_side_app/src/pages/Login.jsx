// author: Nicole Slabbert, n10476130

import React, {useState} from "react";
// react bootstrap components
import {
  Form,
  FormGroup,
  FormControl,
  FormLabel,
  Alert,
  InputGroup,
  Container,
  Button,
  Row,
  Col,
} from "react-bootstrap";
// fontawesome icon imports
import {faAt, faLock} from "@fortawesome/free-solid-svg-icons";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";

// API import from config file
const API_URL = `${process.env.REACT_APP_SERVER_URL}:${process.env.REACT_APP_SERVER_PORT}`;

// render and handle login form - storing web token upon completion and redirecting user to another page
export default function LoginForm(props) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [responseStatus, setResponseStatus] = useState("");
  const [responseMessage, setResponseMessage] = useState("");

  // API post request to handle user login based on form input
  function login() {
    const credentials = JSON.stringify({
      email: email,
      password: password,
    });
    const url = `${API_URL}/users/login`;

    // generate web token and store in localstorage
    return fetch(url, {
      method: "POST",
      headers: { accept: "application/json", "Content-Type": "application/json" },
      body : credentials
    })
    .then(response => response.body)
    .then(rb => {
      const reader = rb.getReader();
    
      return new ReadableStream({
        start(controller) {
          // The following function handles each data chunk
          function push() {
            // "done" is a Boolean and value a "Uint8Array"
            reader.read().then( ({done, value}) => {
              // If there is no more data to read
              if (done) {
                controller.close();
                return;
              }
              controller.enqueue(value);

              push();
            })
          }
          push();
        }
      });
    })
    .then(stream => {
      // Respond with our stream
      return new Response(stream, { headers: { "Content-Type": "text/html" } }).text();
    })
    .then(async (result) => {
      if (result.includes("status")) {
        throw await result.json();
      }
      else {
        // ensure new token is stored 
        localStorage.clear("token");
        localStorage.setItem("token", result);
      }
      // go to dashboard page upon successful login
      window.location.href = "/dashboard";
    })
    .catch(err => {
      setResponseMessage("Username or password are incorrect");
      setResponseStatus('danger');
    });
  }

  return (
    <Container className="mt-5">
      <Row className="justify-content-md-center">
        <Col md={7}>
          <h1>Login</h1>
          <Form>
            <Alert variant={responseStatus}>{responseMessage}</Alert>
            <FormGroup>
              <FormLabel htmlFor="exampleEmail">Email</FormLabel>
              <InputGroup>
                <InputGroup.Prepend>
                  <InputGroup.Text id="inputGroupPrepend">
                    <FontAwesomeIcon icon={faAt} />
                  </InputGroup.Text>
                </InputGroup.Prepend>
                <FormControl
                  value={email}
                  type="email"
                  name="email"
                  id="exampleEmail"
                  placeholder="insert email"
                  onChange={(event) => {
                    setEmail(event.target.value);
                  }}
                />
              </InputGroup>
            </FormGroup>
            <FormGroup>
              <FormLabel htmlFor="Password">Password</FormLabel>
              <InputGroup>
                <InputGroup.Prepend>
                  <InputGroup.Text id="inputGroupPrepend">
                    <FontAwesomeIcon icon={faLock} />
                  </InputGroup.Text>
                </InputGroup.Prepend>
                <FormControl
                  value={password}
                  type="password"
                  name="password"
                  id="Password"
                  placeholder="insert password"
                  onChange={(event) => {
                    setPassword(event.target.value);
                  }}
                />
              </InputGroup>
            </FormGroup>
            <Button id="submitLogin" onClick={login} className="mb-2">
              Login
            </Button>
          </Form>
        </Col>
      </Row>
    </Container>
  );
}

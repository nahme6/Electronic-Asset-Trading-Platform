// author: Nicole Slabbert, n10476130

import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
// react bootstrap components
import { Container, Button, Row, Modal, Form, FormGroup, FormLabel, FormControl, Alert, Col } from "react-bootstrap";
// charting components
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LabelList
} from "recharts";

// API import from config file
const API_URL = `${process.env.REACT_APP_SERVER_URL}:${process.env.REACT_APP_SERVER_PORT}`;

// function which makes API call to get price history of the asset being offered in the current trade
function FetchAsset(assetName) {
  const url = `${API_URL}/assets/priceHistory/${assetName}`;

  return fetch(url).then((res) => res.json());
}

// function which calls API call to generate price history data upon page load
function useAsset(assetName) {
  const [asset, setAsset] = useState([]);

  // query API each time the URL paramaters are altered
  useEffect(() => {
    FetchAsset(assetName)
      .then((asset) => {
        setAsset(asset);
      })
  }, [assetName]);

  return {
    asset
  };
}

//function which customised graph label options
const CustomizedLabel = (props) => {
  const { x, y, stroke, value } = props;

  return (
    <text x={x} y={y} dy={-4} fill={stroke} fontSize={10} textAnchor="middle">
      {value}
    </text>
  );
};

//function which customised graph axis tick options
const CustomizedAxisTick = (props) => {
  const { x, y, payload } = props;

  return (
    <g transform={`translate(${x},${y})`}>
      <text
        x={0}
        y={0}
        dy={16}
        textAnchor="end"
        fill="#666"
        transform="rotate(-35)"
      >
        {payload.value}
      </text>
    </g>
  );
};

// function which makes API call to fetch information pertaining to current trade listing
function FetchID(idStr) {
  const url = `${API_URL}/trades/${idStr}`;

  return fetch(url).then((res) => res.json());
}

// function which calls API call function to load trade listing information upon page load
function useID(idStr) {
  const [trade, setTrade] = useState([]);

  // query API each time the URL paramaters are altered
  useEffect(() => {
    FetchID(idStr)
      .then((trade) => {
        setTrade(trade);
      })
  }, [idStr]);

  return {
    trade
  };
}

// main export function which displays all trade listing components in the correct order
export default function TradeListing({ user }) {
  let currentUserOrg;
  let buttonSet;

  const [deleteTradeModalShow, setDeleteTradeModalShow] = useState(false);
  const [tradeDetailsEditModalShow, setTradeDetailsEditModalShow] = useState(false);
  const [reconcileTradeModalshow, setReconcileTradeModalshow] = useState(false);
  const [responseStatus, setResponseStatus] = useState("");
  const [responseMessage, setResponseMessage] = useState("");

  // retrieve filtering data from the URL paramaters
  let { id } = useParams();
  const idStr = JSON.stringify({ id }).replace('{"id":"', "").replace('"}', "");
  const { trade } = useID(idStr);
  const { asset } = useAsset(trade.assetName);

  // generate graph data
  const lineData = asset;
  
  // determine whether user is viewing a trade from their own organisational unit or another
  // this will affect the button options they are presented with
  if (user.orgName === trade.orgName) {
    currentUserOrg = true;
  }
  else {
    currentUserOrg = false;
  }

  // function which makes API call to reconcile the current trade
  function ReconcileTrade(props) {
    const orgNameURL = props.orgName;
    const url = `${API_URL}/trades/resolve/${orgNameURL}/${trade.tradeID}`;
    if (!trade) {
      return;
    }

    return fetch(url, {
      method: "PUT",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      }
    })
    .then(async (res) => {
      if (res.status !== 200) {
        throw await res.json();
      }
      setResponseStatus('success');
      window.location.href = "/organisational_unit_home";
      props.onHide();
    })
    .catch(err => {
      setResponseMessage("Your organisational unit does not have the required resource to reconcile this trade");
      setResponseStatus('danger');
    });
  }

  // function which generates the modal wich allows for reconciling a trade
  function ReconcileTradeModal(props) {
    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            Reconcile Trade
        </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Alert variant={responseStatus}>{responseMessage}</Alert>
          Are you sure you want to reconcile this trade for your organisational unit?
        </Modal.Body>
        <Modal.Footer>
          <Button type="submit" onClick={() => ReconcileTrade(props)}>Reconcile Trade</Button>
        </Modal.Footer>
      </Modal>
    );
  }

  // function for editing a trade with a modal display, using the correct API endpoint
  function EditTradeModal(props) {
    const orderTypes = ["BUY", "SELL"]
    const [assetName, setAssetName] = useState("");
    const [creditPricePerUnit, setCreditPricePerUnit] = useState("");
    const [orderType, setOrderType] = useState(orderTypes[0]);
    const [quantity, setQuantity] = useState("");
    const [orgname, setOrgName] = useState("");

    const [responseStatus, setResponseStatus] = useState("");
    const [responseMessage, setResponseMessage] = useState("");

  // function which generates a dropdown select list of all assets within the company if it is a buy trade
  // and all assets which that organisational unit has in inventory if it is a sell trade
    function AssetNameDropdown() {
      const [items, setItems] = useState([]);

      useEffect(() => {
        async function getAssetNames() {
          let response;
          if (trade.orderType === 'BUY') {
            response = await fetch(`${API_URL}/assets`);
          }
          else {
            response = await fetch(`${API_URL}/organisationalUnits/inventory/${trade.orgName}`);
          }
          const body = await response.json();
          console.log(body);
          if (body.error) {
            throw body;
          }
          let assets;
          if (trade.orderType === 'BUY') {
            assets = body.map(({ assetName }) => ({ label: assetName, value: assetName }));
          }
          else {
            assets = body;
          }
          setItems(assets);
        }
        if (trade.orgName) {
          getAssetNames();
        }
      }, []);

      if (trade.orderType === 'BUY') {
      return (
        <>
          {items.map(({ label, value }) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </>
      );}
      else {
        return (
          <>
            {items.map(item => (
              <option key={item}>{item}</option>
            ))}
          </>
        );
      }
    }

    // function which initialised the values which pertain to the current trade
    function InitialiseValues() {
      useEffect(() => {
        setOrgName(trade.orgName);
        setAssetName(trade.assetName);
        setCreditPricePerUnit(trade.creditPricePerUnit);
        setQuantity(trade.quantity);
        setOrderType(trade.orderType);
      }, []);
    }

    // function which makes the API call to edit trade detials for the current trade
    function EditTrade(props) {
      const tradeEdit = JSON.stringify({
        assetName: assetName,
        creditPricePerUnit: creditPricePerUnit,
        orderType: orderType,
        quantity: quantity,
        orgName: orgname
      });
      const url = `${API_URL}/trades/edit/${trade.tradeID}`;
      return fetch(url, {
        method: "PUT",
        headers: {
          accept: "application/json",
          "Content-Type": "application/json",
        },
        body: tradeEdit,
      })
      .then(async (res) => {
        if (res.status !== 200) {
          throw await res.json();
        }
        setResponseStatus('success');
        props.onHide();
      })
      .catch(err => {
        if (err.message === "Trade would put the organisational unit into debt.") {
          setResponseMessage("These trade details would put your organisational unit into debt");
        }
        else {
          setResponseMessage("Invalid trade details");
        }
        setResponseStatus('danger');
      });
    }

    // intialised values to fill modal with
    InitialiseValues(props);

    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            Edit Trade
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Alert variant={responseStatus}>{responseMessage}</Alert>
          <Form>
            <FormGroup>
              {/* <FormLabel for="orderType">Order Type</FormLabel> */}
              <FormControl
                hidden
                disabled
                value={orderType}
                as="select"
                name="orderType"
                id="orderType"
                placeholder="insert order type"
                onChange={(event) => {
                  setOrderType(event.target.value);
                }}
              >
                {orderTypes.map(x => (
                  <option key={x}>{x}</option>
                ))}
              </FormControl>
            </FormGroup>

            <FormGroup>
              <FormLabel for="assetName">Asset Name</FormLabel>
              <FormControl
                value={assetName}
                as="select"
                name="assetName"
                id="assetName"
                onChange={(event) => {
                  setAssetName(event.target.value);
                }}
              >
                  {AssetNameDropdown()}
              </FormControl>
            </FormGroup>

            <FormGroup>
              <FormLabel for="creditPricePerUnit">Credit Price Per Unit</FormLabel>
              <FormControl
                value={creditPricePerUnit}
                type="number"
                name="creditPricePerUnit"
                id="creditPricePerUnit"
                placeholder="insert credit price per unit"
                onChange={(event) => {
                  setCreditPricePerUnit(event.target.value);
                }}
              />
            </FormGroup>

            <FormGroup>
              <FormLabel for="quantity">Quantity</FormLabel>
              <FormControl
                value={quantity}
                type="number"
                name="quantity"
                id="quantity"
                placeholder="insert quantity"
                onChange={(event) => {
                  setQuantity(event.target.value);
                }}
              />
            </FormGroup>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button type="submit" onClick={() => EditTrade(props)}>Submit</Button>
        </Modal.Footer>
      </Modal>
    );
  }

  // function which makes API call to delete a trade from the database
  function DeleteTrade(props) {
    const url = `${API_URL}/trades/${trade.tradeID}`;
    if (!trade) {
      return;
    }

    return fetch(url, {
      method: "DELETE",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      }
    })
      .then(async (res) => {
        if (res.status !== 200) {
          throw await res.json();
        }
        setResponseStatus('success');
        window.location.href = "/organisational_unit_home";
      })
      .catch(err => {
        setResponseMessage(err.message);
        setResponseStatus('danger');
      });
  }

  // function which displays a price history graph of the given trade's asset if it exists
  function PriceHistoryGraph() {
    if (lineData.length === 0){
      return;
    }

    return (
      <Row className="justify-content-md-center graph-section">
            <h5 className="graph-title">Asset Price History:</h5>
            <LineChart
              width={500}
              height={300}
              data={lineData}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 10
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" height={60} tick={<CustomizedAxisTick />} />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="pricePerUnit" stroke="#145DA0">
                <LabelList content={<CustomizedLabel />} />
              </Line>
            </LineChart>
          </Row>
    )
  }

  // function which displays the modal which allows a user to delete a trade
  function DeleteTradeModal(props) {
    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            Delete Trade
      </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to delete this trade? This action can't be undone.
    </Modal.Body>
        <Modal.Footer>
          <Button type="cancel" onClick={props.onHide}>Cancel</Button>
          <Button type="submit" onClick={() => DeleteTrade()}>Delete</Button>
        </Modal.Footer>
      </Modal>
    );
  }

  // only display user actions on unresolved trades
  if (!trade.isResolved) {
    if (currentUserOrg) {
      buttonSet =
        <div>
          <Button variant="primary" type="button" style={{ marginRight: "15px" }} onClick={() => setTradeDetailsEditModalShow(true)}>
            Edit Trade
        </Button>
          <Button variant="primary" type="button" style={{ marginRight: "15px" }} onClick={() => setDeleteTradeModalShow(true)}>
            Delete Trade
        </Button>
        </div>
    }
    else {
      buttonSet =
        <div>
          <Button variant="primary" type="button" style={{ marginRight: "15px" }} onClick={() => setReconcileTradeModalshow(true)}>
            Reconcile Trade
        </Button>
        </div>
    }  
  }
  
  return (
    <main>
      <Container className="home-text pt-5">
        <h1>Trade Listing</h1>
      </Container>
      <Container>
        <Form>
          <hr></hr>
          <Form.Row>
            <Form.Group as={Col} controlId="formGridEmail">
              <Form.Label>Asset Name</Form.Label>
              <Form.Control placeholder={trade.assetName} disabled />
            </Form.Group>

            <Form.Group as={Col} controlId="formGridPassword">
              <Form.Label>Listing Date</Form.Label>
              <Form.Control placeholder={trade.listingDate} disabled />
            </Form.Group>
          </Form.Row>
          <Form.Row>
            <Form.Group as={Col} controlId="formGridEmail">
              <Form.Label>Quantity</Form.Label>
              <Form.Control placeholder={trade.quantity} disabled />
            </Form.Group>

            <Form.Group as={Col} controlId="formGridPassword">
              <Form.Label>Credit Price / Unit</Form.Label>
              <Form.Control placeholder={trade.creditPricePerUnit} disabled />
            </Form.Group>
          </Form.Row>
          <Form.Row>
            <Form.Group as={Col} controlId="formGridPassword">
              <Form.Label>Order Type</Form.Label>
              <Form.Control placeholder={trade.orderType} disabled />
            </Form.Group>
            <Form.Group as={Col} controlId="formGridEmail">
              <Form.Label>Organisational Unit</Form.Label>
              <Form.Control placeholder={trade.orgName} disabled />
            </Form.Group>
          </Form.Row>
          <Row className="justify-content-end">
            {buttonSet}
          </Row>
          <hr></hr>
        </Form>
      </Container>
      <Container>
        {PriceHistoryGraph()}

        <DeleteTradeModal
          show={deleteTradeModalShow}
          onHide={() => setDeleteTradeModalShow(false)}
        />
        <EditTradeModal
          show={tradeDetailsEditModalShow}
          onHide={() => {setTradeDetailsEditModalShow(false); window.location.href= `/trade_listing/${trade.tradeID}`;}}
        />

        <ReconcileTradeModal
          show={reconcileTradeModalshow}
          onHide={() => setReconcileTradeModalshow(false)}
          orgName = {user.orgName}
        />
      </Container>
    </main>
  );
}

// author: Nicole Slabbert, n10476130

import React, { useState, useEffect } from "react";
// react bootstrap compoments
import { Container, Button, Row, Modal, Form, FormGroup, FormLabel, FormControl, Alert, Col } from "react-bootstrap";
// ag-grid imports
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-alpine.css";

// API import from config file
const API_URL = `${process.env.REACT_APP_SERVER_URL}:${process.env.REACT_APP_SERVER_PORT}`;

// function which takes user to trade listings page
function viewTradeListings() {
  window.location.href = "/trade_listings";
}

// function wich takes user to organisational unit home page
function viewOrgUnitHome() {
  window.location.href = "/organisational_unit_home";
}

// function for placing a new buy trade with a modal display, using the correct API endpoint
function BuyTradeCreation(props) {
  const orderTypes = ["BUY", "SELL"]

  const [assetName, setAssetName] = useState("");
  const [creditPricePerUnit, setCreditPricePerUnit] = useState("");
  const [orderType, setOrderType] = useState(orderTypes[0]);
  const [quantity, setQuantity] = useState("");
  const [orgname, setOrgName] = useState("");

  const [responseStatus, setResponseStatus] = useState("");
  const [responseMessage, setResponseMessage] = useState("");

  // function which generates a dropdown select list of all assets within the company
  function AssetNameDropdown() {
    const [items, setItems] = useState([]);

    useEffect(() => {
      async function getAssetNames() {
        const response = await fetch(`${API_URL}/assets`);
        const body = await response.json();
        if (body.error) {
          throw body;
        }

        const assets = body.map(({ assetName }) => ({ label: assetName, value: assetName }));
        if(assets.length !== 0) {
          setItems(assets);
          setAssetName(assets[0].value);
        }
      }
      getAssetNames();
    }, []);

    return (
      <>
        {items.map(({ label, value }) => (
          <option key={value} value={value}>
            {label}
          </option>
        ))}
      </>
    );
  }

  // function which initialises organisation name values based on the user that is currently logged in
  function InitialiseValues(props) {
    useEffect(() => {
        setOrgName(props.orgname);
    }, [props.orgname]);
  }

  // function which makes API call to place a trade in the database
  function placeTrade(props) {
    const newBuyTrade = JSON.stringify({
      assetName: assetName,
      creditPricePerUnit: creditPricePerUnit,
      orderType: orderType,
      quantity: quantity,
      orgName: orgname
    });
    const url = `${API_URL}/trades`;
    return fetch(url, {
      method: "POST",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      },
      body: newBuyTrade,
    })
    .then(async (res) => {
      if (res.status !== 200) {
        throw await res.json();
      }
      setResponseStatus('success');
      props.onHide();
    })
    .catch(err => {
      if (err.message === "Trade would put the organisational unit into debt.") {
        setResponseMessage("These trade details would put your organisational unit into dept");
      }
      else {
        setResponseMessage("Invalid trade details");
      }
      setResponseStatus('danger');
    });
  }

  // initialise values to fill modal with
  InitialiseValues(props);

  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          Place New Buy Order
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Alert variant={responseStatus}>{responseMessage}</Alert>
        <Form>
        <FormGroup>
            {/* <FormLabel for="orderType">Order Type</FormLabel> */}
            <FormControl
              hidden
              disabled
              value={orderType}
              as="select"
              name="orderType"
              id="orderType"
              placeholder="insert order type"
              onChange={(event) => {
                setOrderType(event.target.value);
              }}
            >
              {orderTypes.map(x => (
                <option key={x}>{x}</option>
              ))}
            </FormControl>
          </FormGroup>

          <FormGroup>
            <FormLabel for="assetName">Asset Name</FormLabel>
            <FormControl
              value={assetName}
              as = "select"
              name="assetName"
              id="assetName"
              onChange={(event) => {
                setAssetName(event.target.value);
              }}
            >
              {AssetNameDropdown(props)}
            </FormControl>
          </FormGroup>

          <FormGroup>
            <FormLabel for="creditPricePerUnit">Credit Price Per Unit</FormLabel>
            <FormControl
              value={creditPricePerUnit}
              type="number"
              name="creditPricePerUnit"
              id="creditPricePerUnit"
              placeholder="insert credit price per unit"
              onChange={(event) => {
                setCreditPricePerUnit(event.target.value);
              }}
            />
          </FormGroup>

          <FormGroup>
            <FormLabel for="quantity">Quantity</FormLabel>
            <FormControl
              value={quantity}
              type="number"
              name="quantity"
              id="quantity"
              placeholder="insert quantity"
              onChange={(event) => {
                setQuantity(event.target.value);
              }}
            />
          </FormGroup>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button type="submit" onClick={() => placeTrade(props)}>Submit</Button>
      </Modal.Footer>
    </Modal>
  );
}


// function for placing a new sell trade with a modal display, using the correct API endpoint
function SellTradeCreation(props) {
  const orderTypes = ["BUY", "SELL"]

  const [assetName, setAssetName] = useState("");
  const [creditPricePerUnit, setCreditPricePerUnit] = useState("");
  const [orderType, setOrderType] = useState(orderTypes[1]);
  const [quantity, setQuantity] = useState("");
  const [orgname, setOrgName] = useState("");

  const [responseStatus, setResponseStatus] = useState("");
  const [responseMessage, setResponseMessage] = useState("");

  // function which generates a dropdown select list of all assets within the company which that organisational unit has in inventory
  function AssetNameDropdown(props) {
    const [items, setItems] = useState([]);
    useEffect(() => {
      async function getAssetNames() {
        const response = await fetch(`${API_URL}/organisationalUnits/inventory/${props.orgname}`);
        const body = await response.json();
        if (body.error) {
          throw body;
        }

        setItems(body);
        setAssetName(body[0]);
      }
      if (props.orgname) {
        getAssetNames();
      }
    }, [props.orgname]);

    return (
      <>
        {items.map(item => (
          <option key={item}>{item}</option>
        ))}
      </>
    );
  }

  // function which initialises organisation name values based on the user that is currently logged in
  function InitialiseValues(props) {
    useEffect(() => {
        setOrgName(props.orgname);
    }, [props.orgname]);
  }

  // function which makes API call to place a trade in the database
  function placeTrade(props) {
    const newSellTrade = JSON.stringify({
      assetName: assetName,
      creditPricePerUnit: creditPricePerUnit,
      orderType: orderType,
      quantity: quantity,
      orgName: orgname
    });
    const url = `${API_URL}/trades`;
    return fetch(url, {
      method: "POST",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      },
      body: newSellTrade,
    })
    .then(async (res) => {
      if (res.status !== 200) {
        throw await res.json();
      }
      setResponseStatus('success');
      props.onHide();
    })
    .catch(err => {
      if (err.message === "Trade would put the organisational unit into debt.") {
        setResponseMessage("These trade details would put your organisational unit into dept");
      }
      else {
        setResponseMessage("Invalid trade details");
      }
      setResponseStatus('danger');
    });
  }

  // initialise values to fill modal with
  InitialiseValues(props);

  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          Place New Sell Order
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Alert variant={responseStatus}>{responseMessage}</Alert>
        <Form>
        <FormGroup>
            {/* <FormLabel for="orderType">Order Type</FormLabel> */}
            <FormControl
              hidden
              disabled
              value={orderType}
              as="select"
              name="orderType"
              id="orderType"
              placeholder="insert order type"
              onChange={(event) => {
                setOrderType(event.target.value);
              }}
            >
              {orderTypes.map(x => (
                <option key={x}>{x}</option>
              ))}
            </FormControl>
          </FormGroup>

          <FormGroup>
            <FormLabel for="assetName">Asset Name</FormLabel>
            <FormControl
              value={assetName}
              as = "select"
              name="assetName"
              id="assetName"
              onChange={(event) => {
                setAssetName(event.target.value);
              }}
            >
              {AssetNameDropdown(props)}
            </FormControl>
          </FormGroup>

          <FormGroup>
            <FormLabel for="creditPricePerUnit">Credit Price Per Unit</FormLabel>
            <FormControl
              value={creditPricePerUnit}
              type="number"
              name="creditPricePerUnit"
              id="creditPricePerUnit"
              placeholder="insert credit price per unit"
              onChange={(event) => {
                setCreditPricePerUnit(event.target.value);
              }}
            />
          </FormGroup>

          <FormGroup>
            <FormLabel for="quantity">Quantity</FormLabel>
            <FormControl
              value={quantity}
              type="number"
              name="quantity"
              id="quantity"
              placeholder="insert quantity"
              onChange={(event) => {
                setQuantity(event.target.value);
              }}
            />
          </FormGroup>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button type="submit" onClick={() => placeTrade(props)}>Submit</Button>
      </Modal.Footer>
    </Modal>
  );
}

// function which goes to the page for an individual trade listing if it is selected it the table
function OnRowSelected(event) {
  window.location.href = `/trade_listing/${event.node.data.tradeID}`;
}

  // function which creates a table display information of all current trade listings in the database, using API call to populate it
function FeaturedOrderListingsTable(props) {
  const [rowData, setRowData] = useState([]);

  const columns = [
    { headerName: "ID", field: "tradeID", hide: true },
    { headerName: "ASSET NAME", field: "assetName", sortable: true },
    { headerName: "ORGANISATIONAL UNIT", field: "orgUnit", sortable: true },
    { headerName: "CREDIT PRICE / UNIT", field: "creditPricePerUnit", filter: "agNumberColumnFilter" },
    { headerName: "QTY", field: "quantity", filter: "agNumberColumnFilter" },
    { headerName: "LISTING DATE", field: "listingDate", filter: "agNumberColumnFilter" }
  ];

  const url = `${API_URL}/trades/isResolved/false`;

  useEffect(() => {
    fetch(url)
      .then(res => res.json())
      .then(data =>
        data.map(trade => {
          return {
            tradeID: trade.tradeID,
            assetName: trade.assetName,
            creditPricePerUnit: trade.creditPricePerUnit,
            quantity: trade.quantity,
            listingDate: trade.listingDate,
            orgUnit: trade.orgName,
            orderType: trade.orderType
          };
        })
      )
      .then(trades => setRowData(trades));
  }, [url]);

  var filteredRowData;

  // filter data based on the order type
  if (props.orderType === 'Sell') {
    filteredRowData = rowData.filter(function (el) {
      return el.orderType === 'SELL';
    });
  }
  else {
    filteredRowData = rowData.filter(function (el) {
      return el.orderType === 'BUY';
    });
  }

  return (
    <div className="ag-theme-alpine" style={{ width: "88.1%", height: "518.8px", marginTop: "20px" }}>
      <AgGridReact
        rowSelection="single"
        onRowSelected={OnRowSelected}
        columnDefs={columns}
        rowData={filteredRowData}
        pagination={true}
        paginationPageSize={10}
      />
    </div>
  )
}

  // function which creates a table display information of all current trade listings for the currently logged in user's
  // orgnaisational unit in the database, using API call to populate it
function OrganisationalUnitOrderListingsTable(props) {
  const [rowData, setRowData] = useState([]);

  const columns = [
    { headerName: "ID", field: "tradeID", hide: true },
    { headerName: "ASSET NAME", field: "assetName", sortable: true },
    { headerName: "ORDER TYPE", field: "orderType", sortable: true },
    { headerName: "CREDIT PRICE / UNIT", field: "creditPricePerUnit", filter: "agNumberColumnFilter" },
    { headerName: "QTY", field: "quantity", filter: "agNumberColumnFilter" },
    { headerName: "LISTING DATE", field: "listingDate", filter: "agNumberColumnFilter" }
  ];
  const url = `${API_URL}/trades/tradeListings/${props.orgname}/false`;

  useEffect(() => {
    if (props.orgname) {
    fetch(url)
      .then(res => res.json())
      .then(data =>
        data.map(trade => {
          return {
            tradeID: trade.tradeID,
            assetName: trade.assetName,
            creditPricePerUnit: trade.creditPricePerUnit,
            quantity: trade.quantity,
            listingDate: trade.listingDate,
            orderType: trade.orderType
          };
        })
      )
      .then(trades => setRowData(trades));}
  }, [props.orgname, url]);

  return (
    <div className="ag-theme-alpine" style={{ width: "88.1%", height: "518.8px", marginTop: "20px" }}>
      <AgGridReact
        rowSelection="single"
        onRowSelected={OnRowSelected}
        columnDefs={columns}
        rowData={rowData}
        pagination={true}
        paginationPageSize={10}
      />
    </div>
  )
}

// main export function which displays all virtual dashbaord components in the correct order
export default function Dashboard({ user }) {
  const [sellModalShow, setSellModalShow] = useState(false);
  const [buyModalShow, setBuyModalShow] = useState(false);

  return (
    <div>
      <main className="home-background">
        <Container className="home-text pt-5 center">
          <Row className="justify-content-md-center section-title">
            <h1 className="quick-order" style={{ fontSize: "52px" }}>Quick Order</h1>
          </Row>
          <Row className="order-buttons">
            <Col>
              <Button variant="primary" onClick={() => setBuyModalShow(true)}>
                Place New Buy Order
          </Button>
            </Col>
            <Col>
              <Button variant="primary" onClick={() => setSellModalShow(true)}>
                Place New Sell Order
              </Button>
            </Col>
          </Row>
        </Container>
      </main>

      <Container className="pt-5">
        <Row className="justify-content-md-center section-title">
          <h1>My Organisational Unit</h1>
        </Row>
        <Row className="section-subtitle">
          <h4>My Organisational Unit Listings - Featured:</h4>
        </Row>
        <Row className="justify-content-md-center">
          < OrganisationalUnitOrderListingsTable orgname = {user.orgName}/>
        </Row>
        <Row className="justify-content-md-center section-button">
          <Button variant="primary" onClick={viewOrgUnitHome}>
            See More
          </Button>
        </Row>
      </Container>

      <div className="grey-container">
        <Container className="pt-5">
          <Row className="justify-content-md-center section-title">
            <h1>Featured Trade Listings</h1>
          </Row>
          <Row className="section-subtitle">
            <h4>Featured Buy Order Trades:</h4>
          </Row>
          <Row className="justify-content-md-center">
            <FeaturedOrderListingsTable orderType={'Buy'} />
          </Row>
          <Row className="section-subtitle">
            <h4>Featured Sell Order Trades:</h4>
          </Row>
          <Row className="justify-content-md-center">
            <FeaturedOrderListingsTable orderType={'Sell'} />
          </Row>
          <Row className="justify-content-md-center section-button">
            <Button variant="primary" onClick={viewTradeListings}>
              See All Listings
              </Button>
          </Row>
        </Container>
      </div>


      <SellTradeCreation
        show={sellModalShow}
        onHide={() => {setSellModalShow(false); window.location.href = "/dashboard";}}
        orgname = {user.orgName}
      />

      <BuyTradeCreation
        show={buyModalShow}
        onHide={() => {setBuyModalShow(false); window.location.href = "/dashboard";}}
        orgname = {user.orgName}
      />
    </div>
  );
}

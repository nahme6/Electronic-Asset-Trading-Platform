// author: Nicole Slabbert, n10476130

//  clear token and redirect to home
export default function logout() {
  localStorage.clear("token");
  localStorage.clear("reconciledTradeIds");
  window.location.href = "/";
}

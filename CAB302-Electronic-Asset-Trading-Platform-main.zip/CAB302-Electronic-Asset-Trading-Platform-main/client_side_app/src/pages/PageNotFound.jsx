// author: Nicole Slabbert, n10476130

import React from "react";
// react bootstrap components
import {Container} from "react-bootstrap";
// fontawesome icon imports
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faFrown} from "@fortawesome/free-solid-svg-icons";

// render custom 404 page in response to any invalid URL entries
export default function PageNotFound() {
  return (
    <Container>
      <h1>
        Page Not Found
        <FontAwesomeIcon icon={faFrown} className="pl-2 icon" />
      </h1>
      <p>Please give the following a try:</p>
      <ul>
        <li> Check that the provided URL is correct</li>
        <li> Try another link</li>
        <li>Use the navigation bar above</li>
        <li>Go back to the home page</li>
      </ul>
    </Container>
  );
}

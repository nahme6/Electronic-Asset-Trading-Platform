// author: Nicole Slabbert, n10476130

import React, { useState, useEffect } from "react";
// reactstrap components
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink
} from "reactstrap";
// react bootstrap components
import { Alert, Container } from "react-bootstrap";
// fontawesome icon imports
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faSignOutAlt,
  faUser,
  faChartLine
} from "@fortawesome/free-solid-svg-icons";

// API import from config file
const API_URL = `${process.env.REACT_APP_SERVER_URL}:${process.env.REACT_APP_SERVER_PORT}`;

// dismissible alert function which generates a notification upon page load displaying any new trades that have been 
// reconciled since the site was last refreshed
function AlertDismissible(props) {
  const [rowData, setRowData] = useState([]);

  const url = `${API_URL}/trades/tradeListings/${props.orgName}/true`;

  const getReconciledTrades = () => localStorage.getItem("reconciledTradeIds")?.split(',')?.map(x => parseInt(x, 10)) ?? [];

  useEffect(() => {
    if (!props.orgName) {
      return;
    }

    fetch(url)
      .then(res => res.json())
      .then(trades => {
        const storedTrades = getReconciledTrades();
        const newTrades = trades.filter(x => !storedTrades.includes(x.tradeID));
        setRowData(newTrades);

      });
  }, [props.orgName, url]);

  const onHide = (tradeID) => {
    const newTrades = rowData.filter(x => x.tradeID !== tradeID);
    setRowData(newTrades);

    const savedTrades = getReconciledTrades();
    savedTrades.push(tradeID);
    localStorage.setItem("reconciledTradeIds", savedTrades.join(','));
  }

  return (
    <Container>
      {rowData.filter((_, idx) => idx < 4).map(trade => (
        <Alert key={trade.tradeID} variant="success" onClose={() => onHide(trade.tradeID)} dismissible>
          <Alert.Heading>Trade Reconciled:</Alert.Heading>
          <p>
            {trade.orderType} ORDER, {trade.quantity} {trade.assetName}, Listed: {trade.listingDate}, Reconciled: {trade.resolvedDate}
          </p>
        </Alert>
      ))}
    </Container>
  );
}

// Navigation bar with user credentials imported to display email within
export default function Navigation({ user }) {
  // handle hamburger toggle
  const [isOpen, setIsOpen] = useState(false);
  let userActions;
  let navigationOptions;
  let accountSelector;
  let adminPortal;
  const toggle = () => setIsOpen(!isOpen);

  // conditionally display navigation items depending on whether a user is logged in or not (login vs logout)
  if (Object.keys(user).length !== 0) {
    if (user.accountType ===  "Admin") {
      adminPortal = (
      <NavItem>
        <NavLink href="/admin_portal">Administration Portal</NavLink>
      </NavItem>
      );
    };

    userActions = (
      <Nav>
        <NavItem>
          <NavLink>
            <FontAwesomeIcon icon={faUser} className="icon" />
            {user.email}
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink href="/logout">
            <FontAwesomeIcon icon={faSignOutAlt} className="icon" />
            Logout
          </NavLink>
        </NavItem>
      </Nav>
    );
    navigationOptions = (
      <Nav className="mr-auto" navbar>
         <NavItem>
           <NavLink href="/dashboard">
          <p style = {{color: "black", fontWeight: "bold", fontSize: "20px",  marginTop: "-5px", marginLeft: "20px", marginRight: "20px"}}><FontAwesomeIcon icon={faChartLine} className="icon" />
          Virtual Dashboard</p>
          </NavLink>
        </NavItem>
        <NavItem>
          <p style = {{fontSize: "20px", marginTop: "5px", marginLeft: "20px", marginRight: "20px"}}>
          |</p>
        </NavItem>
        <NavItem>
          <NavLink href="/organisational_unit_home">Organisational Unit Home</NavLink>
        </NavItem>
        <NavItem>
          <NavLink href="/trade_listings">Trade Listings</NavLink>
        </NavItem>
        {adminPortal}
      </Nav>
    );
    accountSelector = (
      <Navbar color="light">
      <Nav>
        <NavItem className="account_button">
          <NavLink href="/my_account">
            My Account
          </NavLink>
        </NavItem>
      </Nav>
      </Navbar>
    );
    }

  return (
    <div>
      <Navbar className="justify-content-between bg-light">
        <NavbarBrand href="/dashboard"><img src="/logo_trade_project.png" width="300px" alt="logo" style={{ padding: "15px" }}></img></NavbarBrand>
          {userActions}
      </Navbar>
      <Navbar color="light" light expand="md">
        <NavbarToggler onClick={toggle} />
        <Collapse isOpen={isOpen} navbar>
          {navigationOptions}
          {accountSelector}
        </Collapse>
      </Navbar>
      <AlertDismissible orgName={user.orgName}/>
    </div>
  );
}

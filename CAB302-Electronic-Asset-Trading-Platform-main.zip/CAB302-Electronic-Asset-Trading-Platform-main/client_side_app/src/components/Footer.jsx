// author: Nicole Slabbert, n10476130

import React from "react";

// reusable sticky footer component
export default function Footer() {
  return (
    <footer className="footer center">
      <span>
        <img src="/logo_trade_project_footer.png" width="200px" alt="logo" style={{ paddingBottom: "15px" }}></img>
        <br />
        Copyright &copy; 2021
      </span>
    </footer>
  );
}

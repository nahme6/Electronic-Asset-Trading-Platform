// author: Nicole Slabbert, n10476130

import React, { useState, useEffect } from "react";
import "./App.css";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect,
} from "react-router-dom";
// bootstrap
import "bootstrap/dist/css/bootstrap.min.css";

// components
import Nav from "./components/Nav";
import Footer from "./components/Footer";

// jwt
import jwt from "jsonwebtoken";

// pages
import Login from "./pages/Login";
import Dashboard from "./pages/VirtualDashboard";
import Logout from "./pages/Logout";
import TradeListings from "./pages/TradeListings";
import TradeListing from "./pages/TradeListing";
import OrganisationalUnitHome from "./pages/OrganisationalUnitHome";
import MyAccount from "./pages/MyAccount";
import AdminPortal from "./pages/AdminPortal";

// 404 - page not found page
import PageNotFound from "./pages/PageNotFound";

//implemented config file
require('dotenv').config()

// API import from config file
const API_URL = `${process.env.REACT_APP_SERVER_URL}:${process.env.REACT_APP_SERVER_PORT}`;

// filter API call based on URL paramaters
function FetchUser(email) {
  const url = `${API_URL}/users/${email}`;

  return fetch(url).then((res) => res.json()).then((res) => res);
}

function App() {
  const [user, setUser] = useState({});

  // access user creditials if user is logged in - pass this data onto authenticated routes to indicated authentication
  // - adapated from Mosh React Masters Course
  useEffect(() => {
    (async () => {
      const token = localStorage.getItem("token");
      const decodedToken = jwt.decode(token);
      if (decodedToken === null) {
        return;
      }
      setUser(await FetchUser(decodedToken.sub));
    })().catch(console.error)
  }, []);

  return (
    <Router>
      <div className="mainApp">
        <Nav user={user} />

        <Switch>
          <Route exact path="/" component={Login}/>

          <Route
            path="/dashboard"
            render={(props) => {
              if (!user)
                return (
                  <Redirect
                    to={{
                      pathname: "/",
                      state: { from: props.location },
                    }}
                  />
                );
              return <Dashboard {...props} user={user}/>;
            }}
          />

          <Route path="/logout">
            <Logout />
          </Route>

          <Route path="/trade_listings">
            <TradeListings  user={user}/>
          </Route>

          <Route path="/trade_listing/:id">
            <TradeListing user={user} />
          </Route>

          <Route path="/organisational_unit_home">
            <OrganisationalUnitHome user={user} />
          </Route>

          <Route path="/my_account">
            <MyAccount user={user}/>
          </Route>

          <Route path="/admin_portal">
            <AdminPortal  user={user}/>
          </Route>

          <Route component={PageNotFound} />
        </Switch>
      </div>
      <Footer />
    </Router>
  );
}

export default App;

describe("Login redirect test", () => {
  it("Redirects after logging in", () => {
    const url =
      "http://localhost:3000/dashboard";
    cy.visit(url);

    cy.get("#exampleEmail").type("slabbertnicole@gmail.com");
    cy.get("#Password").type("123");
    cy.get("#submitLogin").click();

    cy.location().should((loc) => {
      expect(loc.toString()).to.eq(url);
    });

    cy.get(".quick-order").should('have.text', 'Quick Order');
  });
});
